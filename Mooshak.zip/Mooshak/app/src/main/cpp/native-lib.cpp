#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string>
#include "aes256.cpp"

using namespace std;

#define BUFFER_SIZE 1024*1024

extern "C"
{

JNIEXPORT jint  JNICALL
Java_com_nimashahbazi_mooshak_base_BaseFragment_encrypt(JNIEnv *env, jobject obj,
                                                        jstring encryptionKey,
                                                        jstring inputFile,
                                                        jstring outputFile);

JNIEXPORT jint  JNICALL
Java_com_nimashahbazi_mooshak_fragment_ReceiveFragment_decrypt(JNIEnv *env, jobject obj,
                                                               jstring encryptionKey,
                                                               jstring inputFile,
                                                               jstring outputFile);
}

JNIEXPORT jint  JNICALL
Java_com_nimashahbazi_mooshak_base_BaseFragment_encrypt(JNIEnv *env, jobject obj,
                                                        jstring encryptionKey,
                                                        jstring inputFile,
                                                        jstring outputFile) {

    const char *_encryptionKey = env->GetStringUTFChars(encryptionKey, NULL);
    const char *_inputFile = env->GetStringUTFChars(inputFile, NULL);
    const char *_outputFile = env->GetStringUTFChars(outputFile, NULL);

    ByteArray key, enc;
    size_t file_len;

    FILE *input, *output;

    srand(time(0));

    size_t key_len = 0;
    while (_encryptionKey[key_len] != 0)
        key.push_back(_encryptionKey[key_len++]);

    input = fopen(_inputFile, "rb");
    if (input == 0) {
        fprintf(stderr, "Cannot read file '%s'\n", _inputFile);
        return 1;
    }

    output = fopen(_outputFile, "wb");
    if (output == 0) {
        fprintf(stderr, "Cannot write file '%s'\n", _outputFile);
        return 1;
    }

    Aes256 aes(key);

    fseek(input, 0, SEEK_END);
    file_len = ftell(input);
    fseek(input, 0, SEEK_SET);
    printf("File is %zd bytes\n", file_len);

    enc.clear();
    aes.encrypt_start(file_len, enc);
    fwrite(enc.data(), enc.size(), 1, output);

    while (!feof(input)) {
        unsigned char buffer[BUFFER_SIZE];
        size_t buffer_len;

        buffer_len = fread(buffer, 1, BUFFER_SIZE, input);
        printf("Read %zd bytes\n", buffer_len);
        if (buffer_len > 0) {
            enc.clear();
            aes.encrypt_continue(buffer, buffer_len, enc);
            fwrite(enc.data(), enc.size(), 1, output);
        }
    }

    enc.clear();
    aes.encrypt_end(enc);
    fwrite(enc.data(), enc.size(), 1, output);

    fclose(input);
    fclose(output);

    return 0;
}


JNIEXPORT jint  JNICALL
Java_com_nimashahbazi_mooshak_fragment_ReceiveFragment_decrypt(JNIEnv *env, jobject obj,
                                                               jstring encryptionKey,
                                                               jstring inputFile,
                                                               jstring outputFile) {

    const char *_encryptionKey = env->GetStringUTFChars(encryptionKey, NULL);
    const char *_inputFile = env->GetStringUTFChars(inputFile, NULL);
    const char *_outputFile = env->GetStringUTFChars(outputFile, NULL);

    ByteArray key, dec;
    size_t file_len;

    FILE *input, *output;

    srand(time(0));

    size_t key_len = 0;
    while (_encryptionKey[key_len] != 0)
        key.push_back(_encryptionKey[key_len++]);

    input = fopen(_inputFile, "rb");
    if (input == 0) {
        fprintf(stderr, "Cannot read file '%s'\n", inputFile);
        return 1;
    }

    output = fopen(_outputFile, "wb");
    if (output == 0) {
        fprintf(stderr, "Cannot write file '%s'\n", outputFile);
        return 1;
    }

    Aes256 aes(key);

    fseek(input, 0, SEEK_END);
    file_len = ftell(input);
    fseek(input, 0, SEEK_SET);
    printf("File is %zd bytes\n", file_len);

    aes.decrypt_start(file_len);

    while (!feof(input)) {
        unsigned char buffer[BUFFER_SIZE];
        size_t buffer_len;

        buffer_len = fread(buffer, 1, BUFFER_SIZE, input);
        printf("Read %zd bytes\n", buffer_len);
        if (buffer_len > 0) {
            dec.clear();
            aes.decrypt_continue(buffer, buffer_len, dec);
            fwrite(dec.data(), dec.size(), 1, output);
        }
    }

    dec.clear();
    aes.decrypt_end(dec);
    fwrite(dec.data(), dec.size(), 1, output);

    fclose(input);
    fclose(output);

    return 0;
}

