package com.nimashahbazi.mooshak.base;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

public class BaseApplication extends Application {
    private static Context mContext;
    private static Thread mMainThread;
    private static long mMainTreadId;
    private static Looper mMainLooper;
    private static Handler mHandler;


    public static Handler getHandler() {
        return mHandler;
    }

    public static Context getContext() {
        return mContext;
    }

    public static Thread getMainThread() {
        return mMainThread;
    }

    public static long getMainTreadId() {
        return mMainTreadId;
    }

    public static Looper getMainThreadLooper() {
        return mMainLooper;
    }

    @Override
    public void onCreate() {

        mContext = getApplicationContext();
        mMainThread = Thread.currentThread();
        mMainTreadId = android.os.Process.myTid();
        mMainLooper = getMainLooper();
        mHandler = new Handler();

        super.onCreate();
    }
}
