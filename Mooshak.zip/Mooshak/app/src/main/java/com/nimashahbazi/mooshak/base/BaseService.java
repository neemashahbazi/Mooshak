package com.nimashahbazi.mooshak.base;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import com.nimashahbazi.mooshak.net.WifiAdmin;
import com.nimashahbazi.mooshak.utils.FileUtils;

import static com.nimashahbazi.mooshak.utils.UIUtils.getContext;

public class BaseService extends Service {
    private WifiAdmin mWifiAdmin;


    @Override
    public void onCreate() {
        super.onCreate();
        mWifiAdmin = new WifiAdmin(getContext());
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("MooshakService", "Service Started");
        mWifiAdmin.getDefaultAP();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("MooshakService", "Service Destroyed");
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Log.d("MooshakService", "Service Ended");
        if (mWifiAdmin.isWifiApOpen()) {
            mWifiAdmin.closeWifiAp();
        } else if (mWifiAdmin.isConnect()) {
            mWifiAdmin.disconnectFromNetwork();
        }
        mWifiAdmin.removeAllWifiConfiguration();
        mWifiAdmin.setDefaultAP();
        FileUtils.removeTemp();
        stopSelf();
    }

}
