package com.nimashahbazi.mooshak.net;

public class TransferSocket extends TransferBase {


    protected String mFileName;

    protected long mTransferLenght;

    protected long mFileLenght;

    protected long mCurrRate;

    protected boolean isEnd;

    protected byte[] data;

    protected int len;

    public TransferSocket() {
        // TODO Auto-generated constructor stub
    }

    public long getFileLenght() {
        return mFileLenght;
    }

    public boolean isEnd() {
        if (isEnd && mCurrRate == 0) {
            return true;
        }
        return false;
    }

    public String getFileName() {
        return mFileName;
    }

    public double getProgress() {
        if (mFileLenght == 0) {
            return 0.0;
        }
        return (double) mTransferLenght / (double) mFileLenght;
    }

    public long getRate() {
        return mCurrRate;
    }

}

