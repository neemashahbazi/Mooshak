package com.nimashahbazi.mooshak.control;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Binder;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

import com.nimashahbazi.mooshak.conf.Constants;
import com.nimashahbazi.mooshak.database.History;
import com.nimashahbazi.mooshak.database.HistoryDatabase;
import com.nimashahbazi.mooshak.net.ReceiveThread;
import com.nimashahbazi.mooshak.net.SendThread;
import com.nimashahbazi.mooshak.net.ServerThread;
import com.nimashahbazi.mooshak.utils.FileUtils;
import com.nimashahbazi.mooshak.utils.HistoryUtils;
import com.nimashahbazi.mooshak.utils.UIUtils;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;

public class TransferService extends Service {

    private Binder mBinder;
    private ServerThread mServerThread;
    private SendThread mSendThread;

    private HistoryDatabase database;

    private volatile boolean isTransfer;

    @Override
    public void onCreate() {
        super.onCreate();
        database = HistoryDatabase.getDatabase(getApplicationContext());

        init();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        mServerThread.close();
        super.onDestroy();
    }

    private void init() {

        isTransfer = false;

        mBinder = new ServerBinder();

        File mFileSavePath = new File(FileUtils.getFilePath() + "/" + "Mooshak");

        mServerThread = ServerThread.createServerThread(Constants.PORT, mFileSavePath.getAbsolutePath(), getLastHostName());

        MyReceiveOper mReceiveOper = new MyReceiveOper();

        mServerThread.registerReceiveOper(mReceiveOper);

        mServerThread.start();

        Intent intent = new Intent();
        intent.setAction(Constants.CHANGE_HOST_NAME);
        sendBroadcast(intent);

    }

    private String getLastHostName() {
        String hostName = android.os.Build.MODEL + "-" + android.os.Build.VERSION.RELEASE;
        try {
            SharedPreferences sp = getApplicationContext().getSharedPreferences(Constants.PROPERTIES_FILE_NAME, Context.MODE_PRIVATE);
            hostName = sp.getString("host_name", android.os.Build.MODEL + "-" + android.os.Build.VERSION.RELEASE);
        } catch (Exception e) {
        }
        return hostName;
    }

    public class MyReceiveOper implements ServerThread.ReceiveOper {
        @Override
        public void operate(final ReceiveThread receive) {

            while (isTransfer) {
                continue;
            }
            new Thread() {
                @Override
                public void run() {
                    super.run();

                    isTransfer = true;

                    Intent intent = new Intent();

                    if (receive.getFileNum() == 1) {
                        intent.setAction(Constants.FILE_RECEIVE_FIRST_START);
                        sendBroadcast(intent);

                        while (Constants.IS_FIRST_STATUS == Constants.IS_FIRST) {
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        if (Constants.IS_FIRST_STATUS == Constants.IS_CANCELED) {
                            receive.close();
                        }
                    }

                    if (Constants.IS_FIRST_STATUS != Constants.IS_CANCELED) {
                        intent.setAction(Constants.FILE_RECEIVE);
                        intent.putExtra("file_name", receive.getFileName());
                        intent.putExtra("file_num",String.valueOf(receive.getFileNum()));
                        intent.putExtra("total_num",String.valueOf(receive.getTotalNum()));
                        sendBroadcast(intent);

                        intent.setAction(Constants.FILE_RECEIVE_PEOGRESS);
                        database.historyDao().addHistory(new History(FileUtils.getIcons(new File(receive.getPath() + "/" + receive.getFileName())), receive.getFileName(), System.currentTimeMillis(), HistoryUtils.STATUS_RECEIVE));
                        receive.start();

                        while (true) {
                            try {
                                Thread.sleep(1000);

                            } catch (Exception e) {
                            }
                            Socket sc = new Socket();
                            try {
                                sc.connect(new InetSocketAddress(receive.getIP(), Constants.PORT), 1000);
                                if (!sc.getInetAddress().isReachable(500)) {
                                    Log.d("Sender", "Not Reachable!");
                                }
                                sc.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                                receive.close();
                                init();
                                try {
                                    sc.close();
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                            intent.putExtra("progress", (int) (receive.getProgress() * 100.0));
                            intent.putExtra("rate", receive.getRate());
                            sendBroadcast(intent);
                            if (receive.isEnd()) {
                                break;
                            }
                        }
                    }

                    if ((int) (receive.getProgress() * 100.0) == 100) {
                        intent.setAction(Constants.FILE_RECEIVE_END);
                        intent.putExtra("rate", 0);
                        intent.putExtra("progress", 100);
                        sendBroadcast(intent);
                    } else if ((int) (receive.getProgress() * 100.0) != 100) {
                        intent.setAction(Constants.FILE_RECEIVE_UNSUCCESSFUL);
                        sendBroadcast(intent);
                    }

                    if (((int) (receive.getProgress() * 100.0) == 100) && receive.getFileNum() == receive.getTotalNum()) {
                        intent.setAction(Constants.FILE_RECEIVE_LAST_END);
                        sendBroadcast(intent);
                    }

                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                    }
                    isTransfer = false;
                }
            }.start();
        }
    }

    public class ServerBinder extends Binder {

        public void sendFileList(final String ip, final int port, final ArrayList<String> file_paths) {
            if (isTransfer) {
                return;
            }

            try {
                new Thread() {
                    @Override
                    public void run() {
                        super.run();

                        isTransfer = true;

                        Intent intent = new Intent();
                        intent.setAction(Constants.FILE_SEND);
                        sendBroadcast(intent);

                        for (int i = 0; i < file_paths.size(); i++) {
                            File file = new File(file_paths.get(i));
                            if (!file.exists()) {
                                continue;
                            }
                            try {
                                mSendThread = new SendThread(ip, port, file, i + 1, file_paths.size());
                                intent.setAction(Constants.FILE_SEND_NAME);
                                intent.putExtra("file_name", file.getName());
                                intent.putExtra("file_num",String.valueOf(i+1));
                                intent.putExtra("total_num", String.valueOf(file_paths.size()));
                                sendBroadcast(intent);
                                //Writing Send Record to DB
                                database.historyDao().addHistory(new History(FileUtils.getIcons(file), file.getName(), System.currentTimeMillis(), HistoryUtils.STATUS_SEND));
                                mSendThread.start();

                            } catch (Exception e) {
                                continue;
                            }
                            intent.setAction(Constants.FILE_SEND_PEOGRESS);
                            while (true) {
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                Socket sc = new Socket();
                                try {
                                    sc.connect(new InetSocketAddress(mSendThread.getIP(), Constants.PORT), 1000);
                                    if (!sc.getInetAddress().isReachable(500)) {
                                        Log.d("Receiver", "Not Reachable!");
                                    }
                                    sc.close();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                    mSendThread.close();
                                    init();
                                    try {
                                        sc.close();
                                    } catch (IOException e1) {
                                        e1.printStackTrace();
                                    }
                                }
                                intent.putExtra("progress", (int) (mSendThread.getProgress() * 100.0));
                                long r = mSendThread.getRate();
                                intent.putExtra("rate", r);
                                sendBroadcast(intent);
                                if (mSendThread.isEnd()) {
                                    break;
                                }
                            }

                            if ((mSendThread.isEnd() && (int) (mSendThread.getProgress() * 100.0) != 100)) {
                                intent.setAction(Constants.FILE_SEND_UNSUCCESSFUL);
                                UIUtils.fileList.removeAll(UIUtils.fileList);
                                sendBroadcast(intent);
                                break;
                            }
                        }
                        intent.setAction(Constants.FILE_SEND_END);
                        sendBroadcast(intent);
                        mSendThread = null;
                        isTransfer = false;
                        UIUtils.fileList.removeAll(UIUtils.fileList);
                        FileUtils.removeTemp();
                    }
                }.start();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public String getHostName() {
            return mServerThread.getHostName();
        }

        public void setHostName(String hostName) {
            mServerThread.setHostName(hostName);

            try {
                SharedPreferences sp = getApplicationContext().getSharedPreferences(Constants.PROPERTIES_FILE_NAME, Context.MODE_PRIVATE);
                SharedPreferences.Editor edt = sp.edit();
                edt.putString("host_name", hostName);
                edt.commit();
            } catch (Exception e) {
            }

            Intent intent = new Intent();
            intent.setAction(Constants.CHANGE_HOST_NAME);
            sendBroadcast(intent);
        }

        public void stopSend() {
            if (mSendThread != null) {
                mSendThread.close();
            }
        }
    }
}
