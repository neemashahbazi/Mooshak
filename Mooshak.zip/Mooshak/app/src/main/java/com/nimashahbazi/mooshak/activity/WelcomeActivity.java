package com.nimashahbazi.mooshak.activity;

import android.Manifest;
import android.app.ActivityManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import com.nimashahbazi.mooshak.MainActivity;
import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.base.BaseService;

import java.io.File;

public class WelcomeActivity extends AppCompatActivity {
    final int PERMISSION_ALL = 1;
    final int LOCATION_SERVICE = 2;
    SharedPreferences sharedPreferences;
    Typeface iranYekanBold;
    String[] PERMISSIONS = {Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.ACCESS_COARSE_LOCATION};
    private String passwordRequest;
    private String password;

    public static boolean hasPermissions(Context context, String... permissions) {
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        TextView appName = (TextView) findViewById(R.id.app_name);
        TextView appSlogan = (TextView) findViewById(R.id.app_slogan);
        TextView appVersion = (TextView) findViewById(R.id.app_version);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        passwordRequest = sharedPreferences.getString("passwordRequest", "");
        password = sharedPreferences.getString("password", "");

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isSecure", false);
        editor.commit();

        if (!(Environment.getExternalStoragePublicDirectory("Android/data/" + getApplicationContext().getPackageName() + "/Files/Encrypted")).exists()) {
            File directory = new File((Environment.getExternalStoragePublicDirectory("Android/data/" + getApplicationContext().getPackageName() + "/Files/Encrypted").toString()));
            directory.mkdirs();
            Log.d("Mooshak", "Encrypted Dir Doesn't Exist!");
        } else {
            Log.d("Mooshak", "Encrypted Dir Exists!");
        }

        if (!(Environment.getExternalStoragePublicDirectory("Android/data/" + getApplicationContext().getPackageName() + "/Files/Compressed")).exists()) {
            File directory = new File((Environment.getExternalStoragePublicDirectory("Android/data/" + getApplicationContext().getPackageName() + "/Files/Compressed").toString()));
            directory.mkdirs();
            Log.d("Mooshak", "Compressed Dir Doesn't Exist!");
        } else {
            Log.d("Mooshak", "Compressed Dir Exists!");
        }

        iranYekanBold = Typeface.createFromAsset(getAssets(), "fonts/iranyekanwebbold.ttf");
        appName.setTypeface(iranYekanBold);
        appSlogan.setTypeface(iranYekanBold);
        appVersion.setTypeface(iranYekanBold);


        if (!hasPermissions(this, PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        } else {
            if (Build.VERSION.SDK_INT >= 23) {
                checkLocationAccess();

            } else {
                beginApp();
            }
        }
        if (!isMyServiceRunning(BaseService.class)) {
            startService(new Intent(getBaseContext(), BaseService.class));
        } else {
            Log.d("MooshakService", "Already Running!");
        }
    }

    public void beginApp() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (passwordRequest.equals("1")) {
                    if (password.isEmpty()) {
                        Intent mainIntent = new Intent(WelcomeActivity.this, PasswordActivity.class);
                        WelcomeActivity.this.startActivity(mainIntent);
                        WelcomeActivity.this.finish();
                    } else {
                        Intent mainIntent = new Intent(WelcomeActivity.this, LoginActivity.class);
                        WelcomeActivity.this.startActivity(mainIntent);
                        WelcomeActivity.this.finish();
                    }
                } else {
                    Intent mainIntent = new Intent(WelcomeActivity.this, MainActivity.class);
                    WelcomeActivity.this.startActivity(mainIntent);
                    WelcomeActivity.this.finish();
                }
            }
        }, 2000);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_ALL: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (checkLocationAccess()) {
                        beginApp();
                    }
                } else {

                    AlertDialog dialog = new AlertDialog.Builder(this, R.style.AppCompatAlertDialogStyle).setMessage("برنامه در صورت عدم اخذ دسترسی‌ها قادر به اجرا نخواهد بود!").setPositiveButton("مشاهده‌ی دسترسی‌ها", new DialogInterface.OnClickListener() {
                        public void onClick(final DialogInterface dialog, final int id) {
                            ActivityCompat.requestPermissions(WelcomeActivity.this, PERMISSIONS, PERMISSION_ALL);
                            dialog.dismiss();

                        }
                    })
                            .setNegativeButton("خروج", new DialogInterface.OnClickListener() {
                                public void onClick(final DialogInterface dialog, final int id) {
                                    finish();
                                    dialog.cancel();
                                }
                            }).show();
                    TextView tv = (TextView) dialog.findViewById(android.R.id.message);
                    Button button1 = (Button) dialog.getWindow().findViewById(android.R.id.button1);
                    Button button2 = (Button) dialog.getWindow().findViewById(android.R.id.button2);

                    tv.setTypeface(iranYekanBold);
                    button1.setTypeface(iranYekanBold);
                    button2.setTypeface(iranYekanBold);

                    Log.d("Mooshak", "All Permissions not granted!!!");
                }
                return;
            }
        }
    }

    public void onBackPressed() {
        WelcomeActivity.this.finish();
    }

    private boolean checkLocationAccess() {
        final LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Log.e("Mooshak", "GPS not enabled..");
            buildAlertMessageNoGps();
            return false;
        }
        beginApp();
        return true;
    }

    private void buildAlertMessageNoGps() {
        AlertDialog dialog = new AlertDialog.Builder(this, R.style.AppCompatAlertDialogStyle).setMessage("سرویس مکان‌یابی شما غیر فعال است، آیا مایل به فعال کردن این سرویس جهت ادامه اشتراک‌گذاری هستید؟").setPositiveButton("بله", new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialog, final int id) {
                startActivityForResult(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS), LOCATION_SERVICE);
                dialog.dismiss();
            }
        })
                .setNegativeButton("خیر", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        finish();
                        dialog.cancel();
                    }
                }).show();
        TextView tv = (TextView) dialog.findViewById(android.R.id.message);
        Button button1 = (Button) dialog.getWindow().findViewById(android.R.id.button1);
        Button button2 = (Button) dialog.getWindow().findViewById(android.R.id.button2);

        tv.setTypeface(iranYekanBold);
        button1.setTypeface(iranYekanBold);
        button2.setTypeface(iranYekanBold);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == LOCATION_SERVICE) {
            if (resultCode == RESULT_OK) {
                beginApp();

            } else {
                checkLocationAccess();
            }
        }
    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
}
