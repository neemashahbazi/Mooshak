package com.nimashahbazi.mooshak.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.SupplicantState;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.util.Log;

import com.nimashahbazi.mooshak.conf.Constants;
import com.nimashahbazi.mooshak.net.WifiAdmin;
import com.nimashahbazi.mooshak.utils.TransferUtils;

import static com.nimashahbazi.mooshak.utils.UIUtils.getContext;

public class WifiStatusReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        WifiAdmin mWifiAdmin = new WifiAdmin(getContext());
        String action = intent.getAction();
        if (action.equals(WifiManager.SUPPLICANT_STATE_CHANGED_ACTION)) {
            SupplicantState supl_state = ((SupplicantState) intent.getParcelableExtra(WifiManager.EXTRA_NEW_STATE));
            switch (supl_state) {
                case ASSOCIATED:
                    Log.i("WifiState", "Associated");
                    break;
                case ASSOCIATING:
                    Log.i("WifiState", "Associating");
                    break;
                case AUTHENTICATING:
                    Log.i("WifiState", "Authenticating...");
                    break;
                case COMPLETED:
                    Log.i("WifiState", "Connected");
                    WifiManager wifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    WifiInfo wifiInfo = null;
                    if (wifiManager != null) {
                        wifiInfo = wifiManager.getConnectionInfo();
                    }
                    String ssid = wifiInfo.getSSID();
                    String origin = TransferUtils.restore(ssid.substring(1, ssid.length() - 1));
                    if (origin.startsWith(Constants.WIFI_AP_NAME)) {
                        Intent mIntent = new Intent();
                        mIntent.setAction(Constants.STATUS_CONNECT);
                        mIntent.putExtra("ssid", ssid.substring(1, ssid.length() - 1));
                        context.sendBroadcast(mIntent);
                    }

                    break;
                case DISCONNECTED:
                    Log.i("WifiState", "Disconnected");
                    mWifiAdmin.removeAllWifiConfiguration();
                    Intent mintent = new Intent();
                    mintent.setAction(Constants.STATUS_DISCONNECT);
                    context.sendBroadcast(mintent);
                    break;
                case DORMANT:
                    Log.i("WifiState", "Dormant");
                    break;
                case FOUR_WAY_HANDSHAKE:
                    Log.i("WifiState", "Four Way Handshake");
                    break;
                case GROUP_HANDSHAKE:
                    Log.i("WifiState", "Group Handshake");
                    break;
                case INACTIVE:
                    Log.i("WifiState", "Inactive");
                    break;
                case INTERFACE_DISABLED:
                    Log.i("WifiState", "Interface Disabled");
                    break;
                case INVALID:
                    Log.i("WifiState", "Invalid");
                    break;
                case SCANNING:
                    Log.i("WifiState", "Scanning");
                    //Disconnect Alert Not Broadcasted On Kitkat
                    if (android.os.Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
                        mWifiAdmin.removeAllWifiConfiguration();
                        Intent nintent = new Intent();
                        nintent.setAction(Constants.STATUS_DISCONNECT);
                        context.sendBroadcast(nintent);
                    }
                    break;
                case UNINITIALIZED:
                    Log.i("WifiState", "Uninitialized");
                    break;
                default:
                    Log.i("WifiState", "Unknown");
                    break;
            }
        }

        int supl_error = intent.getIntExtra(WifiManager.EXTRA_SUPPLICANT_ERROR, -1);
        if (supl_error == WifiManager.ERROR_AUTHENTICATING) {
            Intent mintent = new Intent();
            mintent.setAction(Constants.STATUS_AUTH_ERROR);
            context.sendBroadcast(mintent);
        }
    }
}
