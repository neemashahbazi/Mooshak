package com.nimashahbazi.mooshak.fragment;

import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.GravityEnum;
import com.afollestad.materialdialogs.MaterialDialog;
import com.afollestad.materialdialogs.Theme;
import com.afollestad.materialdialogs.internal.MDTintHelper;
import com.afollestad.materialdialogs.internal.ThemeSingleton;
import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.base.BaseFragment;
import com.nimashahbazi.mooshak.net.WifiAdmin;
import com.nimashahbazi.mooshak.utils.FileUtils;
import com.nimashahbazi.mooshak.utils.LogUtils;
import com.nimashahbazi.mooshak.utils.TypefaceUtil;
import com.nimashahbazi.mooshak.utils.UIUtils;
import com.rockaport.alice.Alice;
import com.rockaport.alice.AliceContext;
import com.rockaport.alice.AliceContextBuilder;

import org.apache.commons.io.FilenameUtils;
import org.zeroturnaround.zip.ZipUtil;

import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReceiveFragment extends BaseFragment {

    private static long exitTime = 0;
    private static ArrayList<File> mFileList;
    private static GridView mGridView;
    private static File mParentFile;
    private static File[] mChildFiles;
    private static String receivePath;
    private static SimpleAdapter simpleAdapter;
    static private TextView mFile;
    private static WifiAdmin mWifiAdmin;


    static {

        try {
            System.loadLibrary("Mooshak");

        } catch (UnsatisfiedLinkError use) {
            Log.e("JNI", "WARNING: Could not load native library");
        }
    }

    Alice alice;
    Typeface iranYekanBold;
    String input;
    String output;
    String key;
    EditText passwordInput;
    String name;
    String path;
    private View positiveAction;
    private EditText etRename;

    private static void initGridView() {

        mChildFiles = mParentFile.listFiles();

        Arrays.sort( mChildFiles, new Comparator()
        {
            public int compare(Object o1, Object o2) {

                if (((File)o1).lastModified() > ((File)o2).lastModified()) {
                    return -1;
                } else if (((File)o1).lastModified() < ((File)o2).lastModified()) {
                    return +1;
                } else {
                    return 0;
                }
            }
        });

        mFileList.removeAll(mFileList);

        mFileList.addAll(Arrays.asList(mChildFiles));

        mFileList.toArray(mChildFiles);

        List<Map<String, Object>> listItems
                = new ArrayList<Map<String, Object>>();
        Map<String, Object> listItem;
        for (File mChildFile : mChildFiles) {
            listItem = new HashMap<String, Object>();
            listItem.put("file_icon", FileUtils.Icons[FileUtils.getIcons(mChildFile)]);
            listItem.put("file_name", mChildFile.getName());
            listItems.add(listItem);
        }




        simpleAdapter = new SimpleAdapter(UIUtils.getContext()
                , listItems
                , R.layout.gridview_info
                , new String[]{"file_icon", "file_name"}
                , new int[]{R.id.iv_icon_name, R.id.tv_file_name});

        mGridView.setAdapter(simpleAdapter);
        mGridView.setEmptyView(mFile);

    }

    public static boolean onKeyUp(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {

            if (receivePath.equals(mParentFile.getPath())) {

                if ((System.currentTimeMillis() - exitTime) > 2000) {
                    Toast toast = Toast.makeText(UIUtils.getContext(), "جهت خروج، مجددا دکمه‌ی «بازگشت» را لمس کنید...", Toast.LENGTH_SHORT);
                    if (toast.getView() instanceof LinearLayout) {
                        LinearLayout toastLayout = (LinearLayout) toast.getView();
                        TextView toastTV = (TextView) toastLayout.getChildAt(0);
                        Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");
                        toastTV.setTypeface(iranYekanBold);
                        toastTV.setTextSize(12);
                    } else if (toast.getView() instanceof RelativeLayout) {
                        RelativeLayout toastLayout = (RelativeLayout) toast.getView();
                        TextView toastTV = (TextView) toastLayout.getChildAt(0);
                        Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");
                        toastTV.setTypeface(iranYekanBold);
                        toastTV.setTextSize(12);
                    }
                    toast.show();
                    exitTime = System.currentTimeMillis();
                    return false;
                } else {
                    if (mWifiAdmin.isWifiApOpen()) {
                        mWifiAdmin.closeWifiAp();
                    } else if (mWifiAdmin.isConnect()) {
                        mWifiAdmin.disconnectFromNetwork();
                    }
                    mWifiAdmin.removeAllWifiConfiguration();
                    mWifiAdmin.setDefaultAP();
                    FileUtils.removeTemp();
                    return true;
                }
            }
            mParentFile = mParentFile.getParentFile();
            initGridView();


            return false;
        } else {
            return false;
        }


    }

    public static String getExtension(String fileName) {
        return fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length()).toLowerCase();
    }

    @Override
    public View initView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_receive, container, false);
        iranYekanBold = Typeface.createFromAsset(getActivity().getAssets(), "fonts/iranyekanwebbold.ttf");

        mGridView = (GridView) view.findViewById(R.id.gv_receive);
        mFile = (TextView) view.findViewById(R.id.tv_no_file);
        mFile.setTypeface(iranYekanBold);

        return view;
    }

    @Override
    public void init() {
        super.init();

    }

    @Override
    public void initData() {
        super.initData();
        TypefaceUtil.overrideFont(getActivity().getApplicationContext(), "SERIF", "fonts/iranyekanwebbold.ttf");

        mWifiAdmin = new WifiAdmin(getContext());

        receivePath = FileUtils.getFilePath() + "/" + "Mooshak";

        mFileList = new ArrayList<>();

        mParentFile = new File(FileUtils.getFilePath() + "/" + "Mooshak");

        mChildFiles = mParentFile.listFiles();
        if (mChildFiles == null) {

            getActivity().runOnUiThread(new Runnable() {
                public void run() {
                    mFile.setVisibility(View.VISIBLE);
                }
            });
        } else {

            getActivity().runOnUiThread(new Runnable() {
                public void run() {
                    mFile.setVisibility(View.GONE);
                }
            });
            mFileList.addAll(Arrays.asList(mChildFiles));

            initGridView();
        }

        AliceContext aliceContext = new AliceContextBuilder()
                .setAlgorithm(AliceContext.Algorithm.AES)
                .setMode(AliceContext.Mode.CTR)
                .setIvLength(16)
                .setPbkdf(AliceContext.Pbkdf.NONE)
                .build();
        alice = new Alice(aliceContext);

    }

    @Override
    public void initListener() {
        super.initListener();

        mGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                final File file_Clicked = mChildFiles[position];

                if (file_Clicked.exists() && file_Clicked.canRead()) {
                    if (file_Clicked.isDirectory()) {
                        mParentFile = file_Clicked;
                        mChildFiles = file_Clicked.listFiles();
                        initGridView();
                    } else if (getExtension(file_Clicked.getName()).equals("encr")) {

                        MaterialDialog d =
                                new MaterialDialog.Builder(getActivity()).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf")
                                        .title("کلید رمزگشایی فایل").titleGravity(GravityEnum.CENTER).theme(Theme.LIGHT).titleColor(getResources().getColor(R.color.colorPrimary)).positiveColor(getResources().getColor(R.color.colorPrimary)).negativeColor(getResources().getColor(R.color.colorPrimary))
                                        .customView(R.layout.dialog_decrypting_key, true)
                                        .positiveText(R.string.btn_apply)
                                        .negativeText(R.string.cancel_button_label)
                                        .onPositive(new MaterialDialog.SingleButtonCallback() {
                                            @Override
                                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                key = passwordInput.getText().toString();
                                                input = file_Clicked.getPath();
                                                if (input.indexOf(".") > 0) {
                                                    output = input.substring(0, input.lastIndexOf("."));
                                                    Log.d("output", output);

                                                    int i = 0;
                                                    int firstIndex = input.lastIndexOf(".");
                                                    String middlePath = input.substring(0, firstIndex);
                                                    String secondExtension = FilenameUtils.getExtension(middlePath);
                                                    int secondIndex = middlePath.lastIndexOf(".");
                                                    String path = input.substring(0, secondIndex);

                                                    while (new File(output).exists()) {
                                                        i++;
                                                        output = path + "_" + i + "." + secondExtension;
                                                    }
                                                }
                                                new AsyncDecrypting().execute();

                                            }
                                        })
                                        .onNegative(new MaterialDialog.SingleButtonCallback() {
                                            @Override
                                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                dialog.cancel();
                                            }
                                        })
                                        .build();

                        positiveAction = d.getActionButton(DialogAction.POSITIVE);
                        passwordInput = (EditText) d.getCustomView().findViewById(R.id.password);
                        passwordInput.addTextChangedListener(
                                new TextWatcher() {
                                    @Override
                                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                                    }

                                    @Override
                                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                                        positiveAction.setEnabled(s.toString().trim().length() > 0);
                                    }

                                    @Override
                                    public void afterTextChanged(Editable s) {
                                    }
                                });
                        CheckBox checkbox = (CheckBox) d.getCustomView().findViewById(R.id.showPassword);
                        checkbox.setTypeface(iranYekanBold);
                        checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                passwordInput.setInputType(
                                        !isChecked ? InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_CLASS_TEXT);
                                passwordInput.setTransformationMethod(
                                        !isChecked ? PasswordTransformationMethod.getInstance() : null);
                            }
                        });

                        TextView passwordLabel = (TextView) d.getCustomView().findViewById(R.id.passwordLabel);
                        passwordLabel.setTypeface(iranYekanBold);

                        int widgetColor = ThemeSingleton.get().widgetColor;
                        MDTintHelper.setTint(
                                checkbox, widgetColor == 0 ? ContextCompat.getColor(UIUtils.getContext(), R.color.colorPrimary) : widgetColor);

                        MDTintHelper.setTint(
                                passwordInput,
                                widgetColor == 0 ? ContextCompat.getColor(UIUtils.getContext(), R.color.colorPrimary) : widgetColor);

                        d.show();
                        positiveAction.setEnabled(false);
                    } else if (getExtension(file_Clicked.getName()).equals("dir")) {

                        try {
                            name = file_Clicked.getName();
                            path = file_Clicked.getPath();
                            new AsyncZipDecrypting().execute();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else if (getExtension(file_Clicked.getName()).equals("zip")) {

                        try {
                            name = file_Clicked.getName();
                            path = file_Clicked.getPath();
                            new AsyncZipDecrypting().execute();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } else {
                        try {
                            FileUtils.openFile(file_Clicked);
                        } catch (Exception e) {
                            Snackbar snackbar = Snackbar.make(getActivity().findViewById(android.R.id.content), "امکان باز کردن فایل وجود ندارد!", Snackbar.LENGTH_SHORT);
                            View sbView = snackbar.getView();
                            sbView.setBackgroundColor(Color.RED);
                            TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                            tv.setTypeface(iranYekanBold);
                            snackbar.show();
                        }
                    }
                } else {
                    Snackbar snackbar = Snackbar.make(getActivity().findViewById(android.R.id.content), " اجازه دسترسی به این فایل وجود ندارد!", Snackbar.LENGTH_SHORT);
                    View sbView = snackbar.getView();
                    sbView.setBackgroundColor(Color.RED);
                    TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                    tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                    tv.setTypeface(iranYekanBold);
                    snackbar.show();
                }
            }
        });

        mGridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                final File file_Long_Clicked = mChildFiles[position];
                DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == FileUtils.OPEN_FILE) {
                            if (file_Long_Clicked.exists() && file_Long_Clicked.canRead()) {
                                if (file_Long_Clicked.isDirectory()) {
                                    mParentFile = file_Long_Clicked;
                                    mChildFiles = file_Long_Clicked.listFiles();
                                    initGridView();
                                } else if (getExtension(file_Long_Clicked.getName()).equals("encr")) {

                                    MaterialDialog d =
                                            new MaterialDialog.Builder(getActivity()).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf")
                                                    .title("کلید رمزگشایی فایل").titleGravity(GravityEnum.CENTER).theme(Theme.LIGHT).titleColor(getResources().getColor(R.color.colorPrimary)).positiveColor(getResources().getColor(R.color.colorPrimary)).negativeColor(getResources().getColor(R.color.colorPrimary))
                                                    .customView(R.layout.dialog_decrypting_key, true)
                                                    .positiveText(R.string.btn_apply)
                                                    .negativeText(R.string.cancel_button_label)
                                                    .onPositive(new MaterialDialog.SingleButtonCallback() {
                                                        @Override
                                                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                            key = passwordInput.getText().toString();
                                                            input = file_Long_Clicked.getPath();
                                                            if (input.indexOf(".") > 0) {
                                                                output = input.substring(0, input.lastIndexOf("."));
                                                                Log.d("output", output);

                                                                int i = 0;
                                                                int firstIndex = input.lastIndexOf(".");
                                                                String middlePath = input.substring(0, firstIndex);
                                                                String secondExtension = FilenameUtils.getExtension(middlePath);
                                                                int secondIndex = middlePath.lastIndexOf(".");
                                                                String path = input.substring(0, secondIndex);

                                                                while (new File(output).exists()) {
                                                                    i++;
                                                                    output = path + "_" + i + "." + secondExtension;
                                                                }
                                                            }
                                                            new AsyncDecrypting().execute();

                                                        }
                                                    })
                                                    .onNegative(new MaterialDialog.SingleButtonCallback() {
                                                        @Override
                                                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                            dialog.cancel();
                                                        }
                                                    })
                                                    .build();

                                    positiveAction = d.getActionButton(DialogAction.POSITIVE);
                                    passwordInput = (EditText) d.getCustomView().findViewById(R.id.password);
                                    passwordInput.addTextChangedListener(
                                            new TextWatcher() {
                                                @Override
                                                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                                                }

                                                @Override
                                                public void onTextChanged(CharSequence s, int start, int before, int count) {
                                                    positiveAction.setEnabled(s.toString().trim().length() > 0);
                                                }

                                                @Override
                                                public void afterTextChanged(Editable s) {
                                                }
                                            });
                                    CheckBox checkbox = (CheckBox) d.getCustomView().findViewById(R.id.showPassword);
                                    checkbox.setTypeface(iranYekanBold);
                                    checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                            passwordInput.setInputType(
                                                    !isChecked ? InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_CLASS_TEXT);
                                            passwordInput.setTransformationMethod(
                                                    !isChecked ? PasswordTransformationMethod.getInstance() : null);
                                        }
                                    });

                                    TextView passwordLabel = (TextView) d.getCustomView().findViewById(R.id.passwordLabel);
                                    passwordLabel.setTypeface(iranYekanBold);

                                    int widgetColor = ThemeSingleton.get().widgetColor;
                                    MDTintHelper.setTint(
                                            checkbox, widgetColor == 0 ? ContextCompat.getColor(UIUtils.getContext(), R.color.colorPrimary) : widgetColor);

                                    MDTintHelper.setTint(
                                            passwordInput,
                                            widgetColor == 0 ? ContextCompat.getColor(UIUtils.getContext(), R.color.colorPrimary) : widgetColor);

                                    d.show();
                                    positiveAction.setEnabled(false);
                                } else if (getExtension(file_Long_Clicked.getName()).equals("dir")) {

                                    try {
                                        name = file_Long_Clicked.getName();
                                        path = file_Long_Clicked.getPath();
                                        new AsyncZipDecrypting().execute();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                } else if (getExtension(file_Long_Clicked.getName()).equals("zip")) {

                                    try {
                                        name = file_Long_Clicked.getName();
                                        path = file_Long_Clicked.getPath();
                                        new AsyncZipDecrypting().execute();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                } else {
                                    try {
                                        FileUtils.openFile(file_Long_Clicked);
                                    } catch (Exception e) {
                                        Snackbar snackbar = Snackbar.make(getActivity().findViewById(android.R.id.content), "امکان باز کردن فایل وجود ندارد!", Snackbar.LENGTH_SHORT);
                                        View sbView = snackbar.getView();
                                        sbView.setBackgroundColor(Color.RED);
                                        TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                                        tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                                        tv.setTypeface(iranYekanBold);
                                        snackbar.show();
                                    }
                                }
                            } else {
                                Toast.makeText(UIUtils.getContext(), "Permission denied", Toast.LENGTH_SHORT).show();
                            }
                        } else if (which == FileUtils.CHANGE_FILE_NAME) {
                            initChangeFileName(file_Long_Clicked);
                        } else if (which == FileUtils.DELETE_FILE) {
                            initDeleteFile(file_Long_Clicked);
                        } else if (which == FileUtils.FILE_INFO) {
                            initFileInfo(file_Long_Clicked);
                        }
                    }
                };

                String[] menu = {"باز کردن", "تغییر نام", "حذف ", "مشخصات فایل"};
                AlertDialog alertDialog = new AlertDialog.Builder(getContext(), R.style.AppCompatAlertDialogStyle)
                        .setItems(menu, listener)
                        .setPositiveButton("لغو", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        }).create();
                alertDialog.show();

                Button button1 = (Button) alertDialog.getWindow().findViewById(android.R.id.button1);
                button1.setTypeface(iranYekanBold);
                button1.setTextColor(getResources().getColor(R.color.colorPrimary));


                return true;
            }
        });
    }

    private void initChangeFileName(final File file_Long_Clicked) {

        MaterialDialog dialog = new MaterialDialog.Builder(getActivity()).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf").theme(Theme.LIGHT)
                .title("تغییر نام کاربری").titleGravity(GravityEnum.CENTER).titleColor(getResources().getColor(R.color.colorPrimary)).positiveColor(getResources().getColor(R.color.colorPrimary)).negativeColor(getResources().getColor(R.color.colorPrimary))
                .customView(R.layout.dialog_rename_file, true)
                .positiveText(R.string.btn_apply)
                .negativeText(R.string.cancel_button_label)
                .onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        LogUtils.s("fileName=" + etRename.getText().toString());
                        String modifyName = etRename.getText().toString();
                        final String fpath = file_Long_Clicked.getParentFile().getPath();
                        final File newFile = new File(fpath + "/" + modifyName);
                        if (newFile.exists()) {
                            if (!modifyName.equals(file_Long_Clicked.getName())) {

                                MaterialDialog dialog_ = new MaterialDialog.Builder(getActivity()).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf").theme(Theme.LIGHT)
                                        .title("توجه!").titleGravity(GravityEnum.CENTER).titleColor(getResources().getColor(R.color.colorPrimary)).positiveColor(getResources().getColor(R.color.colorPrimary)).negativeColor(getResources().getColor(R.color.colorPrimary))
                                        .content("این فایل در حال حاضر وجود دارد! آیا مایل به بازنویسی آن هستید؟").contentGravity(GravityEnum.CENTER).cancelable(false)
                                        .positiveText(R.string.btn_apply)
                                        .negativeText(R.string.cancel_button_label)
                                        .onPositive(new MaterialDialog.SingleButtonCallback() {
                                            @Override
                                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                if (file_Long_Clicked.renameTo(newFile)) {
                                                    mParentFile = file_Long_Clicked.getParentFile();
                                                    mChildFiles = mParentFile.listFiles();
                                                    initGridView();
                                                    LogUtils.s("##-------Renamed Successfully!");
                                                } else {
                                                    LogUtils.s("##-------Renamed Failed!");
                                                }
                                            }
                                        })
                                        .onNegative(new MaterialDialog.SingleButtonCallback() {
                                            @Override
                                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                dialog.dismiss();
                                            }
                                        }).build();

                                dialog_.show();

                            }
                        } else {
                            if (file_Long_Clicked.renameTo(newFile)) {
                                mParentFile = file_Long_Clicked.getParentFile();
                                mChildFiles = mParentFile.listFiles();
                                initGridView();
                                LogUtils.s("##-------Renamed Successfully!");
                            } else {
                                LogUtils.s("##-------Renamed Failed!");
                            }
                        }

                    }
                })
                .onNegative(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.cancel();
                    }
                })
                .build();

        positiveAction = dialog.getActionButton(DialogAction.POSITIVE);
        etRename = (EditText) dialog.getCustomView().findViewById(R.id.et_rename);
        etRename.setText(file_Long_Clicked.getName());
        etRename.addTextChangedListener(
                new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        positiveAction.setEnabled(s.toString().trim().length() > 0);
                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                    }
                });

        TextView renameLable = (TextView) dialog.getCustomView().findViewById(R.id.renameLabel);
        renameLable.setTypeface(iranYekanBold);

        int widgetColor = ThemeSingleton.get().widgetColor;

        MDTintHelper.setTint(
                etRename,
                widgetColor == 0 ? ContextCompat.getColor(getActivity(), R.color.colorPrimary) : widgetColor);

        dialog.show();
        positiveAction.setEnabled(false); // disabled by default
    }

    private void initDeleteFile(final File file_Long_Clicked) {
        new MaterialDialog.Builder(getActivity()).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf").theme(Theme.LIGHT)
                .title("توجه!").titleGravity(GravityEnum.CENTER).titleColor(getResources().getColor(R.color.colorPrimary)).positiveColor(getResources().getColor(R.color.colorPrimary)).negativeColor(getResources().getColor(R.color.colorPrimary))
                .content("آیا از پاک کردن این فایل مطمئن هستید؟").contentGravity(GravityEnum.CENTER)
                .positiveText("بله")
                .negativeText("خیر")
                .onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        boolean isDelete = FileUtils.deleteFile(file_Long_Clicked);

                        LogUtils.s("-------Delete the Folder-------" + isDelete);
                        mParentFile = file_Long_Clicked.getParentFile();
                        mChildFiles = mParentFile.listFiles();
                        initGridView();
                    }
                }).onNegative(new MaterialDialog.SingleButtonCallback() {
            @Override
            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                dialog.cancel();

            }
        }).build().show();

    }

    private void initFileInfo(File file_Long_Clicked) {

        AlertDialog.Builder ab = new AlertDialog.Builder(getContext());
        LinearLayout linearLayout = (LinearLayout) getActivity().getLayoutInflater().inflate(R.layout.dialog_file_info, null);


        FileUtils.setDialogFileInfo(linearLayout, file_Long_Clicked);

        ab.setView(linearLayout).setTitle("Properties").setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        ab.create().show();
    }

    public native int decrypt(String encryptionKey, String inputFile, String outputFile);

    public String removeExtension(String name) {
        if (name.indexOf(".") > 0)
            name = name.substring(0, name.lastIndexOf("."));
        return name;
    }

    public void refresh() {
        if (simpleAdapter != null) {
            simpleAdapter.notifyDataSetChanged();
            initGridView();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        refresh();
    }

    private class AsyncDecrypting extends AsyncTask<Void, Void, Void> {
        MaterialDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new MaterialDialog.Builder(getActivity()).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf").titleGravity(GravityEnum.CENTER).theme(Theme.LIGHT).titleColor(getResources().getColor(R.color.colorPrimary))
                    .title("در حال رمزگشایی فایل")
                    .content("لطفا منتظر بمانید...")
                    .progress(true, 0)
                    .show();
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                alice.decrypt(new File(input), new File(output), key.toCharArray());
            } catch (GeneralSecurityException | IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            if (pd != null) {
                pd.dismiss();
            }
            FileUtils.deleteFile(new File(input));
            initGridView();
            Snackbar snackbar = Snackbar.make(getActivity().findViewById(android.R.id.content), "فایل با موفقیت رمزگشایی شد!", Snackbar.LENGTH_SHORT);
            View sbView = snackbar.getView();
            sbView.setBackgroundColor(Color.parseColor("#a4c639"));
            TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            tv.setTypeface(iranYekanBold);
            snackbar.show();
        }
    }

    private class AsyncZipDecrypting extends AsyncTask<Void, Void, Void> {

        MaterialDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new MaterialDialog.Builder(getActivity()).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf").titleGravity(GravityEnum.CENTER).theme(Theme.LIGHT).titleColor(getResources().getColor(R.color.colorPrimary)).positiveColor(getResources().getColor(R.color.colorPrimary)).negativeColor(getResources().getColor(R.color.colorPrimary))
                    .title("در حال استخراج فایل")
                    .content("لطفا منتظر بمانید...")
                    .progress(true, 0)
                    .show();
        }

        @Override
        protected Void doInBackground(Void... params) {
            String output = Environment.getExternalStoragePublicDirectory("Mooshak").toString() + "/" + removeExtension(name);
            if (!new File(output).exists()) {
                ZipUtil.unpack(new File(path), new File(output));

            } else {
                int i = 0;
                int index = path.lastIndexOf(".");
                String middlePath = path.substring(0, index);
                String extension = FilenameUtils.getExtension(middlePath);
                while (new File(output).exists()) {
                    i++;
                    output = middlePath + "_" + i + "." + extension;
                }
                ZipUtil.unpack(new File(path), new File(output));
            }

            ZipUtil.unpack(new File(path), new File(output));
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            FileUtils.deleteFile(new File(path));
            if (pd != null) {
                pd.dismiss();
                initGridView();
            }
        }
    }
}
