package com.nimashahbazi.mooshak.fragment;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.Snackbar;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.adapter.VideoAdapter;
import com.nimashahbazi.mooshak.base.BaseFragment;
import com.nimashahbazi.mooshak.entity.VideoInfo;
import com.nimashahbazi.mooshak.net.WifiAdmin;
import com.nimashahbazi.mooshak.utils.FileUtils;
import com.nimashahbazi.mooshak.utils.UIUtils;
import com.nimashahbazi.mooshak.utils.VideoUtils;

import java.io.File;
import java.util.ArrayList;

public class VideoFragment extends BaseFragment {

    private static WifiAdmin mWifiAdmin;
    private static long exitTime = 0;
    VideoAdapter videoAdapter;
    private TextView mFile;
    private ListView listView;
    private ProgressBar progressBar;
    private ArrayList<VideoInfo> mVideoInfoList;
    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 0x177: {
                    if (getActivity() != null) {
                        videoAdapter = new VideoAdapter(getActivity(), mVideoInfoList);
                        listView.setAdapter(videoAdapter);
                        listView.setEmptyView(mFile);
                        progressBar.setVisibility(View.GONE);
                    }
                    break;
                }
            }

        }


    };

    public static boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0 && ((System.currentTimeMillis() - exitTime) > 2000)) {

            Toast toast = Toast.makeText(UIUtils.getContext(), "جهت خروج، مجددا دکمه‌ی «بازگشت» را لمس کنید...", Toast.LENGTH_SHORT);
            if (toast.getView() instanceof LinearLayout) {
                LinearLayout toastLayout = (LinearLayout) toast.getView();
                TextView toastTV = (TextView) toastLayout.getChildAt(0);
                Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");
                toastTV.setTypeface(iranYekanBold);
                toastTV.setTextSize(12);
            } else if (toast.getView() instanceof RelativeLayout) {
                RelativeLayout toastLayout = (RelativeLayout) toast.getView();
                TextView toastTV = (TextView) toastLayout.getChildAt(0);
                Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");
                toastTV.setTypeface(iranYekanBold);
                toastTV.setTextSize(12);
            }
            toast.show();
            exitTime = System.currentTimeMillis();

            return false;
        } else {
            if (mWifiAdmin.isWifiApOpen()) {
                mWifiAdmin.closeWifiAp();
            } else if (mWifiAdmin.isConnect()) {
                mWifiAdmin.disconnectFromNetwork();
            }
            mWifiAdmin.removeAllWifiConfiguration();
            mWifiAdmin.setDefaultAP();
            FileUtils.removeTemp();
            return true;
        }
    }

    @Override
    public View initView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_video, container, false);
        listView = (ListView) view.findViewById(R.id.list_video);
        progressBar = (ProgressBar) view.findViewById(R.id.loading_video);
        Typeface iranYekanBold = Typeface.createFromAsset(getActivity().getAssets(), "fonts/iranyekanwebbold.ttf");
        mFile = (TextView) view.findViewById(R.id.tv_no_file);
        mFile.setTypeface(iranYekanBold);
        return view;
    }

    @Override
    public void init() {
        super.init();
    }

    @Override
    public void initData() {
        super.initData();
        new Thread(new Runnable() {
            @Override
            public void run() {
                mVideoInfoList = (ArrayList<VideoInfo>) VideoUtils.getVideoInfos(getContext());

                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if (mVideoInfoList != null) {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {
                                mFile.setVisibility(View.GONE);
                            }
                        });
                    }
                    Message msg = new Message();
                    msg.what = 0x177;
                    mHandler.sendMessage(msg);
                } else {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {
                                mFile.setVisibility(View.VISIBLE);
                            }
                        });
                    }
                }

            }
        }).start();

        mWifiAdmin = new WifiAdmin(getContext());

    }

    @Override
    public void initListener() {
        super.initListener();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                RelativeLayout videoItem = (RelativeLayout) view;
                CheckBox musicSelect = (CheckBox) view.findViewById(R.id.cx_video_select);

                if (!UIUtils.fileList.contains(VideoUtils.getVideoInfos(UIUtils.getContext()).get(position).getPath())) {
                    videoItem.setBackgroundResource(R.color.CheckedItemColor);
                    musicSelect.setChecked(true);

                } else {
                    videoItem.setBackgroundResource(R.color.BackgroundColor);
                    musicSelect.setChecked(false);
                }
            }
        });


        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                File file = new File(mVideoInfoList.get(position).getPath());
                try {
                    FileUtils.openFile(file);
                } catch (Exception e) {
                    Snackbar snackbar = Snackbar.make(getActivity().findViewById(android.R.id.content), "امکان باز کردن فایل وجود ندارد!", Snackbar.LENGTH_SHORT);
                    View sbView = snackbar.getView();
                    sbView.setBackgroundColor(Color.RED);
                    TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                    tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                    tv.setTypeface(iranYekanBold);
                    snackbar.show();
                }
                return true;
            }
        });
    }

    public void refresh() {
        videoAdapter.notifyDataSetChanged();
    }
}
