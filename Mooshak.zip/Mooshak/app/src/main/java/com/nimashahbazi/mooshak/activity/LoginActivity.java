package com.nimashahbazi.mooshak.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.nimashahbazi.mooshak.MainActivity;
import com.nimashahbazi.mooshak.R;


public class LoginActivity extends AppCompatActivity {
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        TextView appName = (TextView) findViewById(R.id.app_name);
        TextView appSlogan = (TextView) findViewById(R.id.app_slogan);
        TextView btnEnter = (TextView) findViewById(R.id.btn_enter);
        final EditText etPassword = (EditText) findViewById(R.id.et_password);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        final String password = sharedPreferences.getString("password", "");

        final Typeface iranYekanBold = Typeface.createFromAsset(getAssets(), "fonts/iranyekanwebbold.ttf");
        appName.setTypeface(iranYekanBold);
        appSlogan.setTypeface(iranYekanBold);
        btnEnter.setTypeface(iranYekanBold);
        etPassword.setTypeface(iranYekanBold);

        btnEnter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (etPassword.getText().toString().equals(password)) {

                    Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "ورود موفق! خوش آمدید!", Snackbar.LENGTH_SHORT);
                    View sbView = snackbar.getView();
                    sbView.setBackgroundColor(Color.parseColor("#a4c639"));
                    TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                    tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                    tv.setTypeface(iranYekanBold);
                    snackbar.show();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Intent mainIntent = new Intent(LoginActivity.this, MainActivity.class);
                            LoginActivity.this.startActivity(mainIntent);
                            LoginActivity.this.finish();
                        }
                    }, 500);


                } else {
                    Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "رمز ورود اشتباه است!", Snackbar.LENGTH_SHORT);
                    View sbView = snackbar.getView();
                    sbView.setBackgroundColor(Color.RED);
                    TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                    tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                    tv.setTypeface(iranYekanBold);
                    snackbar.show();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                }
            }
        });
    }

    public void onBackPressed() {
        LoginActivity.this.finish();
    }
}
