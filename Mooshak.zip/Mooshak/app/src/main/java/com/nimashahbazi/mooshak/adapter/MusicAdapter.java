package com.nimashahbazi.mooshak.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nimashahbazi.mooshak.MainActivity;
import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.entity.Mp3Info;
import com.nimashahbazi.mooshak.utils.MusicUtils;
import com.nimashahbazi.mooshak.utils.UIUtils;

import java.util.ArrayList;
import java.util.List;

public class MusicAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater inflater;
    private ArrayList<Mp3Info> infoList;

    public MusicAdapter(Context context, List<Mp3Info> infoList) {
        this.context = context;
        this.infoList = (ArrayList) infoList;
        this.inflater =
                (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return this.infoList.size();
    }

    @Override
    public Object getItem(int position) {
        return this.infoList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        final ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.music_item, parent, false);
            holder.musicImg = (ImageView) convertView.findViewById(R.id.iv_music_item);
            holder.musicTitle = (TextView) convertView.findViewById(R.id.tv_music_item);
            holder.musicAlbum = (TextView) convertView.findViewById(R.id.tv_music_album);
            holder.musicDuration = (TextView) convertView.findViewById(R.id.tv_music_duration);
            holder.musicSize = (TextView) convertView.findViewById(R.id.tv_music_size);
            holder.musicSelect = (CheckBox) convertView.findViewById(R.id.rb_music_select);
            holder.musicItem = (RelativeLayout) convertView.findViewById(R.id.music_item);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
            holder.musicSelect.setOnCheckedChangeListener(null);

        }

        Bitmap bitmap = MusicUtils.getArtwork(context, infoList.get(position).getId(), infoList.get(position).getAlbumId(), false);

        if (bitmap != null) {
            holder.musicImg.setImageBitmap(bitmap);
        }
        holder.musicDuration.setText(MusicUtils.formatTime(infoList.get(position).getDuration()) + "");

        holder.musicSize.setText(MusicUtils.getMp3Size(infoList.get(position).getSize()));

        holder.musicTitle.setText(infoList.get(position).getTitle());

        holder.musicAlbum.setText(infoList.get(position).getAlbum());


        holder.musicSelect.setFocusable(false);

        if (UIUtils.fileList.contains(this.infoList.get(position).getUrl())) {
            holder.musicItem.setBackgroundResource(R.color.CheckedItemColor);
            holder.musicSelect.setChecked(true);
            notifyDataSetChanged();

        } else {
            holder.musicItem.setBackgroundResource(R.color.BackgroundColor);
            holder.musicSelect.setChecked(false);
            notifyDataSetChanged();

        }


        final int mPosition = position;

        holder.musicSelect.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    UIUtils.fileList.add(MusicUtils.getMp3Infos(UIUtils.getContext()).get(mPosition).getUrl());
                    holder.musicItem.setBackgroundResource(R.color.CheckedItemColor);
                    ((MainActivity) context).updateBadge();


                } else {
                    UIUtils.fileList.remove(MusicUtils.getMp3Infos(UIUtils.getContext()).get(mPosition).getUrl());
                    holder.musicItem.setBackgroundResource(R.color.BackgroundColor);
                    ((MainActivity) context).updateBadge();


                }
            }
        });

        return convertView;
    }

    class ViewHolder {
        public ImageView musicImg;
        public TextView musicTitle;
        public TextView musicAlbum;
        public TextView musicDuration;
        public TextView musicSize;
        public CheckBox musicSelect;
        public RelativeLayout musicItem;

    }

}