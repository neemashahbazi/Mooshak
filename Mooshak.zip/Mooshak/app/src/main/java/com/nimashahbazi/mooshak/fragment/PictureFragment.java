package com.nimashahbazi.mooshak.fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.activity.PictureActivity;
import com.nimashahbazi.mooshak.adapter.PictureAdapter;
import com.nimashahbazi.mooshak.base.BaseFragment;
import com.nimashahbazi.mooshak.entity.ImageInfo;
import com.nimashahbazi.mooshak.net.WifiAdmin;
import com.nimashahbazi.mooshak.utils.FileUtils;
import com.nimashahbazi.mooshak.utils.PictureUtils;
import com.nimashahbazi.mooshak.utils.UIUtils;

import java.util.ArrayList;

public class PictureFragment extends BaseFragment {


    private static WifiAdmin mWifiAdmin;
    private static long exitTime = 0;
    PictureAdapter pictureAdapter;
    private TextView mFile;
    private ProgressBar progressBar;
    private GridView mGridView;
    private ArrayList<ImageInfo> mImgList;
    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 0x137: {
                    if (getActivity() != null) {
                        pictureAdapter = new PictureAdapter(getActivity(), mImgList);
                        mGridView.setAdapter(pictureAdapter);
                        mGridView.setEmptyView(mFile);
                        progressBar.setVisibility(View.GONE);
                    }
                    break;
                }
            }
        }


    };

    public static boolean onKeyUp(int keyCode, KeyEvent event) {


        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0 && ((System.currentTimeMillis() - exitTime) > 2000)) {

            Toast toast = Toast.makeText(UIUtils.getContext(), "جهت خروج، مجددا دکمه‌ی «بازگشت» را لمس کنید...", Toast.LENGTH_SHORT);
            if (toast.getView() instanceof LinearLayout) {
                LinearLayout toastLayout = (LinearLayout) toast.getView();
                TextView toastTV = (TextView) toastLayout.getChildAt(0);
                Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");
                toastTV.setTypeface(iranYekanBold);
                toastTV.setTextSize(12);
            } else if (toast.getView() instanceof RelativeLayout) {
                RelativeLayout toastLayout = (RelativeLayout) toast.getView();
                TextView toastTV = (TextView) toastLayout.getChildAt(0);
                Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");
                toastTV.setTypeface(iranYekanBold);
                toastTV.setTextSize(12);
            }
            toast.show();
            exitTime = System.currentTimeMillis();

            return false;
        } else {
            if (mWifiAdmin.isWifiApOpen()) {
                mWifiAdmin.closeWifiAp();
            } else if (mWifiAdmin.isConnect()) {
                mWifiAdmin.disconnectFromNetwork();
            }
            mWifiAdmin.removeAllWifiConfiguration();
            mWifiAdmin.setDefaultAP();
            FileUtils.removeTemp();
            return true;
        }
    }

    @Override
    public View initView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_picture, container, false);

        mGridView = (GridView) view.findViewById(R.id.gv_picture);
        progressBar = (ProgressBar) view.findViewById(R.id.loading);
        Typeface iranYekanBold = Typeface.createFromAsset(getActivity().getAssets(), "fonts/iranyekanwebbold.ttf");
        mFile = (TextView) view.findViewById(R.id.tv_no_file);
        mFile.setTypeface(iranYekanBold);

        return view;
    }

    @Override
    public void init() {
        super.init();
    }

    @Override
    public void initData() {
        super.initData();
        new Thread(new Runnable() {
            @Override
            public void run() {
                mImgList = (ArrayList<ImageInfo>) PictureUtils.getPictureInfos(getContext());

                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if (mImgList != null) {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {
                                mFile.setVisibility(View.GONE);
                            }
                        });
                    }
                    Message msg = new Message();
                    msg.what = 0x137;
                    mHandler.sendMessage(msg);
                } else {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {
                                mFile.setVisibility(View.VISIBLE);
                            }
                        });
                    }
                }

            }
        }).start();

        mWifiAdmin = new WifiAdmin(getContext());
    }

    @Override
    public void initListener() {
        super.initListener();

        mGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                CheckBox picSelect = (CheckBox) view.findViewById(R.id.rb_pictrue_select);

                if (!UIUtils.fileList.contains(PictureUtils.getPictureInfos(UIUtils.getContext()).get(position).getPath())) {
                    picSelect.setChecked(true);

                } else {
                    picSelect.setChecked(false);
                }
            }
        });


        mGridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent();
                intent.putExtra("PicturePath", mImgList.get(position).getPath());
                intent.setClass(getContext(), PictureActivity.class);
                startActivity(intent);
                return true;
            }
        });

    }

    public void refresh() {
        pictureAdapter.notifyDataSetChanged();
    }
}