package com.nimashahbazi.mooshak.net;

import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.conf.Constants;
import com.nimashahbazi.mooshak.database.History;
import com.nimashahbazi.mooshak.database.HistoryDatabase;
import com.nimashahbazi.mooshak.utils.HistoryUtils;
import com.nimashahbazi.mooshak.utils.LogUtils;
import com.nimashahbazi.mooshak.utils.UIUtils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class WifiAdmin {

    public final static int NO_PASSWORD = 1;
    public final static int WPA_PASSWORD = 2;
    private final static String WIFI_LOCK_TAG = "LOCK";
    public WifiManager mWifiManager;
    SharedPreferences sharedPreferences;
    private HistoryDatabase database;
    private Context mContext;
    private WifiManager.WifiLock mWifiLock;
    private WifiConfiguration mWifiConfig;
    private List<ScanResult> mHotPot;


    public WifiAdmin(Context context) {
        mContext = context;
        mWifiManager = (WifiManager) mContext.getSystemService(Context.WIFI_SERVICE);
        mWifiLock = mWifiManager.createWifiLock(WIFI_LOCK_TAG);
        database = HistoryDatabase.getDatabase(UIUtils.getContext().getApplicationContext());
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);

    }

    private static void setHotspotName(String newName, Context context) {
        try {
            WifiManager wifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            Method getConfigMethod = null;
            if (wifiManager != null) {
                getConfigMethod = wifiManager.getClass().getMethod("getWifiApConfiguration");
            }
            WifiConfiguration wifiConfig = null;
            if (getConfigMethod != null) {
                wifiConfig = (WifiConfiguration) getConfigMethod.invoke(wifiManager);
            }

            if (wifiConfig != null) {
                wifiConfig.SSID = newName;
            }

            Method setConfigMethod = null;
            if (wifiManager != null) {
                setConfigMethod = wifiManager.getClass().getMethod("setWifiApConfiguration", WifiConfiguration.class);
            }
            if (setConfigMethod != null) {
                setConfigMethod.invoke(wifiManager, wifiConfig);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean isWifiOpen() {
        return mWifiManager.isWifiEnabled();
    }

    public void openWifi() {
        if (isWifiApOpen()) {
            closeWifiAp();
        }

        if (!isWifiOpen()) {
            mWifiManager.setWifiEnabled(true);
        }
    }

    public void closeWifi() {
        if (mWifiManager.isWifiEnabled()) {
            mWifiManager.setWifiEnabled(false);
        }
    }

    public int getWifiState() {
        return mWifiManager.getWifiState();
    }

    public int getCurrNetworkId() {
        WifiInfo info = mWifiManager.getConnectionInfo();
        return info.getNetworkId();
    }

    public void ScanWifiAp() {
        mWifiManager.startScan();

    }

    public List<WifiConfiguration> getWifiConfigList() {
        return mWifiManager.getConfiguredNetworks();
    }

    public List<ScanResult> getWifiScanList() {
        Log.d("Wifi List", mWifiManager.getScanResults().size() + "");
        for (int i = 0; i < mWifiManager.getScanResults().size(); i++) {
            Log.d("Wifi " + i, mWifiManager.getScanResults().get(i).SSID);
        }
        return mWifiManager.getScanResults();
    }

    public WifiInfo getCurrWifiInfo() {
        return mWifiManager.getConnectionInfo();
    }

    public String getSSID() {
        WifiInfo info = mWifiManager.getConnectionInfo();

        if (info == null) {
            return "The line is disconnected";
        } else {
            return info.getSSID();
        }
    }

    public int getLevel() {
        WifiInfo info = mWifiManager.getConnectionInfo();
        if (info == null) {
            return 0;
        } else {
            return info.getRssi();
        }
    }

    public int isExist(String SSID) {

        Iterator<WifiConfiguration> it = mWifiManager.getConfiguredNetworks().iterator();

        WifiConfiguration config;

        while (it.hasNext()) {
            config = (WifiConfiguration) it.next();
            if (config.SSID.equals("\"" + SSID + "\"")) {
                return config.networkId;
            }
        }

        return -1;
    }

    public void removeWifiConfiguration(WifiConfiguration config) {
        mWifiManager.removeNetwork(config.networkId);
    }

    public void disconnectFromNetwork() {

        List<WifiConfiguration> list = mWifiManager.getConfiguredNetworks();
        for (WifiConfiguration i : list) {
            mWifiManager.disableNetwork(i.networkId);
        }
    }

    public void removeAllWifiConfiguration() {
        List<WifiConfiguration> list = getWifiConfigList();
        if (list == null) {
            return;
        }
        for (WifiConfiguration config : list) {
            mWifiManager.removeNetwork(config.networkId);
        }
        mWifiManager.saveConfiguration();
    }

    public boolean addWifi(WifiConfiguration config) {

        int i = mWifiManager.addNetwork(config);
        if (i == -1) {
            Log.d("NetID", "-1");
            i = isExist(config.SSID);
        }
        if (connectionWifi(i)) {
            return true;
        }
        mWifiManager.removeNetwork(i);
        return false;
    }

    public boolean isConnect() {
        ConnectivityManager conManager = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = conManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (netInfo != null && netInfo.isConnected()) {
            return true;
        } else {
            return false;
        }
    }

    public boolean connectionWifi(int ID) {

        return mWifiManager.enableNetwork(ID, true);
    }

    public void acquireWifiLock() {
        mWifiLock.acquire();
    }

    public void releaseWifiLock() {
        if (isHeld()) {
            mWifiLock.release();
        }
    }

    public boolean isHeld() {
        return mWifiLock.isHeld();
    }

    public boolean isWifiApOpen() {
        try {
            return (Boolean) WifiManager.class.getMethod("isWifiApEnabled").invoke(mWifiManager);
        } catch (Exception e) {
            return false;
        }
    }

    public void openWifiAp(WifiConfiguration config, View view) {

        if (isWifiOpen()) {
            closeWifi();
        }
        if (isWifiApOpen()) {
            closeWifiAp();
        }

        try {
            Method setApMethod = WifiManager.class.getMethod("setWifiApEnabled", WifiConfiguration.class, boolean.class);
            setApMethod.invoke(mWifiManager, config, true);

            Snackbar snackbar = Snackbar.make(view, "شبکه با موفقیت ایجاد شد!\n" + " لطفا به دستگاه " + android.os.Build.MODEL + " متصل شوید.", Snackbar.LENGTH_LONG);
            View sbView = snackbar.getView();
            sbView.setBackgroundColor(Color.parseColor("#a4c639"));
            TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");
            tv.setTypeface(iranYekanBold);
            snackbar.show();
            database.historyDao().addHistory(new History(R.mipmap.wireless, android.os.Build.MODEL, System.currentTimeMillis(), HistoryUtils.STATUS_CREATE_NETWORK));

        } catch (Exception e) {

            Snackbar snackbar = Snackbar.make(view, "در حال حاضر امکان ایجاد هات اسپات وجود ندارد!", Snackbar.LENGTH_LONG).setAction("تنظیمات", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    gotoHotspotSettings();
                }
            });
            View sbView = snackbar.getView();
            sbView.setBackgroundColor(Color.RED);
            TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");
            tv.setTypeface(iranYekanBold);
            TextView btn = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_action);
            btn.setTypeface(iranYekanBold);
            btn.setTextColor(Color.parseColor("#f8a0a0"));
            btn.setTextSize(14);
            snackbar.show();
        }
    }

    public void gotoHotspotSettings() {
        try {
            final ComponentName cn = new ComponentName("com.android.settings", "com.android.settings.TetherSettings");
            UIUtils.getContext().startActivity(new Intent().setComponent(cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (ActivityNotFoundException anf) {
            Toast.makeText(UIUtils.getContext(), "No Hotspot listings feature found on this device", Toast.LENGTH_SHORT).show();
        }
    }

    public boolean isApEncrypted() {
        try {
            Method getConfigMethod = WifiManager.class.getMethod("getWifiApConfiguration");
            WifiConfiguration config = (WifiConfiguration) getConfigMethod.invoke(mWifiManager);
            if (config.preSharedKey != null)
                return true;
            else return false;

        } catch (Exception e) {
            return false;
        }
    }

    public void closeWifiAp() {
        if (!isWifiApOpen()) {
            return;
        }
        try {
            Method getConfigMethod = WifiManager.class.getMethod("getWifiApConfiguration");
            getConfigMethod.setAccessible(true);
            WifiConfiguration config = (WifiConfiguration) getConfigMethod.invoke(mWifiManager);
            getConfigMethod.setAccessible(false);
            Method setApMethod = WifiManager.class.getMethod("setWifiApEnabled", WifiConfiguration.class, boolean.class);
            setApMethod.invoke(mWifiManager, config, false);
        } catch (Exception e) {
        }
    }

    public String getApSSID() {
        try {
            Method getConfigMethod = WifiManager.class.getMethod("getWifiApConfiguration");
            WifiConfiguration config = (WifiConfiguration) getConfigMethod.invoke(mWifiManager);
            return config.SSID;

        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        return null;
    }

    public WifiConfiguration setConfigWifiAp(String ssid, String passwd, int type) {

        mWifiConfig = new WifiConfiguration();
        mWifiConfig.allowedAuthAlgorithms.clear();
        mWifiConfig.allowedGroupCiphers.clear();
        mWifiConfig.allowedKeyManagement.clear();
        mWifiConfig.allowedPairwiseCiphers.clear();
        mWifiConfig.allowedProtocols.clear();

        mWifiConfig.SSID = ssid;
        Log.i("======================", mWifiConfig.SSID);

        mWifiConfig.wepTxKeyIndex = 0;
        if (type == NO_PASSWORD) {
            //mWifiConfig.wepKeys[0] = "";
            mWifiConfig.allowedKeyManagement.set(0);
            //mWifiConfig.wepTxKeyIndex = 0;
        } else if (type == WPA_PASSWORD) {
            mWifiConfig.preSharedKey = passwd;
            mWifiConfig.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.OPEN);
            mWifiConfig.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
        }

        return mWifiConfig;
    }

    public String getWifiApSSID() {
        String ApSSID = "";
        try {
            Method getConfigMethod = WifiManager.class.getMethod("getWifiApConfiguration");
            getConfigMethod.setAccessible(true);
            WifiConfiguration config = (WifiConfiguration) getConfigMethod.invoke(mWifiManager);
            ApSSID = config.SSID;
        } catch (Exception e) {
            return "";
        }
        return ApSSID;
    }

    public String getWifiApPassword() {
        String apPassWord = "";
        try {
            Method getConfigMethod = WifiManager.class.getMethod("getWifiApConfiguration");
            getConfigMethod.setAccessible(true);
            WifiConfiguration config = (WifiConfiguration) getConfigMethod.invoke(mWifiManager);
            apPassWord = config.preSharedKey;
        } catch (Exception e) {
            return "";
        }
        return apPassWord;
    }

    public void autoConnect(List<ScanResult> wifiList) {
        mHotPot = new ArrayList<ScanResult>();
        for (ScanResult result : wifiList) {
            LogUtils.s("当前在列表内的ssid：" + result.SSID);
            if ((result.SSID).contains(Constants.WIFI_AP_NAME))
                mHotPot.add(result);
        }
        connectToHotspot();
    }

    public void connectToHotspot() {
        if (mHotPot == null || mHotPot.size() == 0)
            return;
        WifiConfiguration config = this.setConfigWifiAp("\"" + mHotPot.get(0).SSID + "\"", "\"" + Constants.WIFI_AP_PSWD + "\"", WifiAdmin.WPA_PASSWORD);
        LogUtils.s(" Hotspot name: " + mHotPot.get(0));
        if (this.addWifi(config)) {
            Toast.makeText(UIUtils.getContext(), "connection succeeded！", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(UIUtils.getContext(), "Connection failed！", Toast.LENGTH_SHORT).show();
        }
    }

    public void connectToSSID(String ssid, View view) {
        WifiConfiguration config = this.setConfigWifiAp("\"" + ssid + "\"", "\"" + Constants.WIFI_AP_PSWD + "\"", WifiAdmin.NO_PASSWORD);
        Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");

        if (this.addWifi(config)) {

        } else {
            Snackbar snackbar = Snackbar.make(view, "خطا در اتصال به شبکه!", Snackbar.LENGTH_LONG).setAction("تنظیمات", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    gotoWifiSettings();
                }
            });
            View sbView = snackbar.getView();
            sbView.setBackgroundColor(Color.RED);
            TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            tv.setTypeface(iranYekanBold);
            TextView btn = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_action);
            btn.setTypeface(iranYekanBold);
            btn.setTextColor(Color.parseColor("#f8a0a0"));
            btn.setTextSize(14);
            snackbar.show();
        }
    }

    public void connectToSSID(String ssid, String password, View view) {
        WifiConfiguration config = this.setConfigWifiAp("\"" + ssid + "\"", "\"" + password + "\"", WifiAdmin.WPA_PASSWORD);
        Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");

        if (this.addWifi(config)) {
        } else {
            Snackbar snackbar = Snackbar.make(view, "خطا در اتصال به شبکه!", Snackbar.LENGTH_LONG).setAction("تنظیمات", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    gotoWifiSettings();
                }
            });
            View sbView = snackbar.getView();
            sbView.setBackgroundColor(Color.RED);
            TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            tv.setTypeface(iranYekanBold);
            TextView btn = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_action);
            btn.setTypeface(iranYekanBold);
            btn.setTextColor(Color.parseColor("#f8a0a0"));
            btn.setTextSize(14);
            snackbar.show();
        }
    }

    public ArrayList<String> getConnectedIP() {
        ArrayList<String> connectedIP = new ArrayList<String>();
        try {
            BufferedReader br = new BufferedReader(new FileReader(
                    "/proc/net/arp"));
            String line;
            while ((line = br.readLine()) != null) {
                String[] splitted = line.split(" +");
                if (splitted != null && splitted.length >= 4) {
                    String ip = splitted[0];
                    connectedIP.add(ip);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return connectedIP;
    }

    public void openHotspotActivity(String ssid) {
        try {
            setHotspotName(ssid, mContext);
            final Intent intent = new Intent(Intent.ACTION_MAIN, null);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            final ComponentName cn = new ComponentName("com.android.settings", "com.android.settings.TetherSettings");
            intent.setComponent(cn);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            mContext.startActivity(intent);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getDefaultAP() {
        try {
            Method getConfigMethod = mWifiManager.getClass().getMethod("getWifiApConfiguration");
            WifiConfiguration wifiConfig = (WifiConfiguration) getConfigMethod.invoke(mWifiManager);

            if (wifiConfig != null) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("APName", wifiConfig.SSID);
                editor.putString("APPassword", wifiConfig.preSharedKey);
                editor.commit();
                Log.d("getDefaultAP", "SSID:" + wifiConfig.SSID + "        " + "Password:" + wifiConfig.preSharedKey);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setDefaultAP() {
        try {
            String ssid = sharedPreferences.getString("APName", "");
            String password = sharedPreferences.getString("APPassword", "");

            Method setConfigMethod = mWifiManager.getClass().getMethod("setWifiApConfiguration", WifiConfiguration.class);
            if (password.equals(""))
                setConfigMethod.invoke(mWifiManager, this.setConfigWifiAp(ssid, password, NO_PASSWORD));
            else
                setConfigMethod.invoke(mWifiManager, this.setConfigWifiAp(ssid, password, WPA_PASSWORD));

            Log.d("setDefaultAP", "SSID:" + ssid + "        " + "Password:" + password);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void gotoWifiSettings() {
        try {
            mContext.startActivity(new Intent(
                    Settings.ACTION_WIFI_SETTINGS));
        } catch (ActivityNotFoundException anf) {
            Toast.makeText(mContext, "No Wifi listings feature found on this device", Toast.LENGTH_SHORT).show();
        }
    }


    public WifiConfiguration getWifiApConfiguration() {
        try {
            Method method = mWifiManager.getClass().getMethod("getWifiApConfiguration");
            return (WifiConfiguration) method.invoke(mWifiManager);
        } catch (Exception e) {
            Log.e(this.getClass().toString(), "", e);
            return null;
        }
    }

}
