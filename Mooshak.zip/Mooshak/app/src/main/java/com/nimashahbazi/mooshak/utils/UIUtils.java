package com.nimashahbazi.mooshak.utils;

import android.content.Context;
import android.content.res.Resources;
import android.os.Handler;

import com.nimashahbazi.mooshak.base.BaseApplication;

import java.util.ArrayList;


public class UIUtils {

    public static ArrayList<String> fileList = new ArrayList<>();

    public static Context getContext() {
        return BaseApplication.getContext();
    }

    public static Resources getResource() {
        return getContext().getResources();
    }

    public static String getString(int resId) {
        return getResource().getString(resId);
    }

    public static String[] getStringArr(int resId) {
        return getResource().getStringArray(resId);
    }

    public static int getColor(int colorId) {
        return getResource().getColor(colorId);
    }

    public static String getPackageName() {
        return getContext().getPackageName();
    }

    public static long getMainThreadid() {
        return BaseApplication.getMainTreadId();
    }

    public static Handler getMainThreadHandler() {
        return BaseApplication.getHandler();
    }

    public static void postTaskSafely(Runnable task) {
        int curThreadId = android.os.Process.myTid();

        if (curThreadId == getMainThreadid()) {
            task.run();
        } else {
            getMainThreadHandler().post(task);
        }

    }

}
