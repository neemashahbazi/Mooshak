package com.nimashahbazi.mooshak.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nimashahbazi.mooshak.MainActivity;
import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.entity.AppInfo;
import com.nimashahbazi.mooshak.utils.AppUtils;
import com.nimashahbazi.mooshak.utils.UIUtils;

import java.io.File;
import java.util.ArrayList;

public class AppAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater inflater;
    private ArrayList<AppInfo> infoList;


    public AppAdapter(Context context, ArrayList<AppInfo> infoList) {
        this.context = context;
        this.infoList = infoList;
        this.inflater =
                (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public static long getFolderSize(File f) {
        long size = 0;
        if (f.isDirectory()) {
            for (File file : f.listFiles()) {
                size += getFolderSize(file);
            }
        } else {
            size = f.length();
        }
        return size;
    }

    @Override
    public int getCount() {
        return this.infoList.size();
    }

    @Override
    public Object getItem(int position) {
        return this.infoList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        final ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.app_item, parent, false);
            holder.appItem = (RelativeLayout) convertView.findViewById(R.id.app_item);
            holder.appImg = (ImageView) convertView.findViewById(R.id.img_app_icon);
            holder.appTitle = (TextView) convertView.findViewById(R.id.txt_app_name);
            holder.appSize = (TextView) convertView.findViewById(R.id.tv_app_size);
            holder.appSelect = (CheckBox) convertView.findViewById(R.id.cx_app_select);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
            holder.appSelect.setOnCheckedChangeListener(null);
        }

        holder.appSelect.setFocusable(false);

        if (UIUtils.fileList.contains(this.infoList.get(position).getPath())) {
            holder.appItem.setBackgroundResource(R.color.CheckedItemColor);
            holder.appSelect.setChecked(true);
            notifyDataSetChanged();

        } else {
            holder.appItem.setBackgroundResource(R.color.BackgroundColor);
            holder.appSelect.setChecked(false);
            notifyDataSetChanged();
        }

        holder.appImg.setImageDrawable(this.infoList.get(position).getIcon());
        holder.appTitle.setText(this.infoList.get(position).getTitle());

        File file = new File(this.infoList.get(position).getPath());
        String value = null;
        long Filesize = getFolderSize(file) / 1024;
        if (Filesize >= 1024)
            value = Filesize / 1024 + " Mb";
        else
            value = Filesize + " Kb";
        holder.appSize.setText(value);

        final int mPosition = position;

        holder.appSelect.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    UIUtils.fileList.add(AppUtils.getAppInfos(UIUtils.getContext()).get(mPosition).getPath());
                    holder.appItem.setBackgroundResource(R.color.CheckedItemColor);
                    ((MainActivity) context).updateBadge();

                } else {
                    UIUtils.fileList.remove(AppUtils.getAppInfos(UIUtils.getContext()).get(mPosition).getPath());
                    holder.appItem.setBackgroundResource(R.color.BackgroundColor);
                    ((MainActivity) context).updateBadge();
                }
            }
        });

        return convertView;
    }

    class ViewHolder {
        public ImageView appImg;
        public TextView appTitle;
        public TextView appSize;
        public CheckBox appSelect;
        public RelativeLayout appItem;

    }

}
