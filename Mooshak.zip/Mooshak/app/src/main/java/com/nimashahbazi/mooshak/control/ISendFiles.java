package com.nimashahbazi.mooshak.control;

import java.util.ArrayList;


public interface ISendFiles {
    public void sendFileList(ArrayList<String> fileList);
}
