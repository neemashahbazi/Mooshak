package com.nimashahbazi.mooshak.net;

public class TransferBase {

    protected String mIp;

    protected int mPort;

    protected String mHostName;

    protected Thread mThread;

    public TransferBase() {
        // TODO Auto-generated constructor stub
    }

    public void start() {
        mThread.start();
    }

    public boolean isAlive() {
        return mThread.isAlive();
    }

    public String getIP() {
        return mIp;
    }

    public int getPort() {
        return mPort;
    }

    public String getHostName() {
        return mHostName;
    }

    public void setHostName(String hostName) {
        this.mHostName = hostName;
    }

}




































