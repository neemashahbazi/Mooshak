package com.nimashahbazi.mooshak.activity;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.github.chrisbanes.photoview.PhotoView;
import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.base.BaseActivity;

import java.io.File;

public class PictureActivity extends BaseActivity {

    private Toolbar mToolbar;

    private ImageView mImageView;

    @Override
    public void initView() {
        setContentView(R.layout.activity_picture);
    }

    @Override
    protected void initActionBar() {
        super.initActionBar();
        Typeface iranYekanBold = Typeface.createFromAsset(getAssets(), "fonts/iranyekanwebbold.ttf");

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        mToolbar.setTitle("عکس");
        setSupportActionBar(mToolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TextView mTitle = (TextView) mToolbar.findViewById(R.id.toolbar_title);
        mTitle.setTypeface(iranYekanBold);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
    }


    @Override
    protected void initData() {
        super.initData();

        Intent intent = getIntent();

        String picturePath = intent.getStringExtra("PicturePath");

        File pictureFile = new File(picturePath);

        mImageView = (PhotoView) findViewById(R.id.iv_picture_watch);

        Glide.with(this).load(pictureFile).into(mImageView);


    }

    @Override
    protected void initListener() {
        super.initListener();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;

            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
