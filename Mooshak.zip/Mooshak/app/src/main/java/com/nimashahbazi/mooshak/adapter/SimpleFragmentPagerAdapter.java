package com.nimashahbazi.mooshak.adapter;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;

import com.nimashahbazi.mooshak.fragment.FragmentFactory;
import com.nimashahbazi.mooshak.utils.LogUtils;

public class SimpleFragmentPagerAdapter extends android.support.v4.app.FragmentPagerAdapter {

    final int PAGE_COUNT = 6;
    private String tabTitles[] = new String[]{"پوشه‌", "برنامه", "عکس", "موسیقی", "ویدئو", "فایل‌های دریافتی"};
    private Context context;


    public SimpleFragmentPagerAdapter(FragmentManager fm, Context context) {
        super(fm);
        this.context = context;
    }

    @Override
    public Fragment getItem(int position) {
        LogUtils.s("current position------：" + position);
        LogUtils.s("current position------：" + position);

        return FragmentFactory.getFragment(position);
    }

    @Override
    public int getCount() {
        return PAGE_COUNT;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return tabTitles[position];
    }

}
