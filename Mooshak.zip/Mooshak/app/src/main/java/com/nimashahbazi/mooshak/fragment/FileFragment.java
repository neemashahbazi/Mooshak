package com.nimashahbazi.mooshak.fragment;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.adapter.FileAdapter;
import com.nimashahbazi.mooshak.base.BaseFragment;
import com.nimashahbazi.mooshak.net.WifiAdmin;
import com.nimashahbazi.mooshak.utils.FileUtils;
import com.nimashahbazi.mooshak.utils.UIUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FileFragment extends BaseFragment {

    private static WifiAdmin mWifiAdmin;

    private static long exitTime = 0;

    private static GridView mGridView;

    private static File mParentFile;

    private static File[] mChildFiles;

    private static ArrayList<File> mFileList;

    static private TextView mFile;

    static private TextView currentPath;

    private ImageView memory;

    private int memoryType = FileUtils.TYPE_PHONE_MEMORY;


    private static void initGridView() {

        mChildFiles = mParentFile.listFiles();
        mFileList.removeAll(mFileList);
        mFileList.addAll(Arrays.asList(mChildFiles));
        Collections.sort(mFileList, new FileUtils.FileComparer());
        mFileList.toArray(mChildFiles);
        currentPath.setText(mParentFile.getPath());

        List<Map<String, Object>> listItems
                = new ArrayList<Map<String, Object>>();
        Map<String, Object> listItem;
        for (int i = 0; i < mChildFiles.length; i++) {
            listItem = new HashMap<String, Object>();
            listItem.put("file_icon", FileUtils.Icons[FileUtils.getIcons(mChildFiles[i])]);
            listItem.put("file_name", mChildFiles[i].getName());
            listItem.put("file_path", mChildFiles[i].getPath());
            listItems.add(listItem);
        }

        FileAdapter fileAdapter = new FileAdapter(UIUtils.getContext(), listItems);
        mGridView.setAdapter(fileAdapter);
        mGridView.setEmptyView(mFile);

    }

    public static boolean onKeyUp(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {

            if (FileUtils.getFilePath().getPath().equals(mParentFile.getPath())) {
                if ((System.currentTimeMillis() - exitTime) > 2000) {
                    Toast toast = Toast.makeText(UIUtils.getContext(), "جهت خروج، مجددا دکمه‌ی «بازگشت» را لمس کنید...", Toast.LENGTH_SHORT);
                    if (toast.getView() instanceof LinearLayout) {
                        LinearLayout toastLayout = (LinearLayout) toast.getView();
                        TextView toastTV = (TextView) toastLayout.getChildAt(0);
                        Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");
                        toastTV.setTypeface(iranYekanBold);
                        toastTV.setTextSize(12);
                    } else if (toast.getView() instanceof RelativeLayout) {
                        RelativeLayout toastLayout = (RelativeLayout) toast.getView();
                        TextView toastTV = (TextView) toastLayout.getChildAt(0);
                        Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");
                        toastTV.setTypeface(iranYekanBold);
                        toastTV.setTextSize(12);
                    }
                    toast.show();
                    exitTime = System.currentTimeMillis();
                    return false;
                } else {
                    if (mWifiAdmin.isWifiApOpen()) {
                        mWifiAdmin.closeWifiAp();
                    } else if (mWifiAdmin.isConnect()) {
                        mWifiAdmin.disconnectFromNetwork();
                    }
                    mWifiAdmin.removeAllWifiConfiguration();
                    mWifiAdmin.setDefaultAP();
                    FileUtils.removeTemp();
                    return true;
                }
            } else if (FileUtils.getExternalStorageDirectories().length != 0 && FileUtils.getExternalStorageDirectories()[0].equals(mParentFile.getPath())) {

                return true;
            }
            mParentFile = mParentFile.getParentFile();
            initGridView();
            return false;
        } else {

            return false;
        }
    }

    @Override
    public View initView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_file, container, false);
        mGridView = (GridView) view.findViewById(R.id.gv_file);
        Typeface iranYekanBold = Typeface.createFromAsset(getActivity().getAssets(), "fonts/iranyekanwebbold.ttf");
        mFile = (TextView) view.findViewById(R.id.tv_no_file);
        mFile.setTypeface(iranYekanBold);
        currentPath = (TextView) view.findViewById(R.id.current_path);
        currentPath.setTypeface(iranYekanBold);
        memory = (ImageView) view.findViewById(R.id.memory);

        return view;
    }

    @Override
    public void init() {
        super.init();

    }

    @Override
    public void initData() {
        super.initData();

        mWifiAdmin = new WifiAdmin(getContext());

        mFileList = new ArrayList<>();

        File path = FileUtils.getFilePath();

        if (path.exists()) {
            if (mParentFile == null) {
                mParentFile = path;
            }
            mChildFiles = mParentFile.listFiles();
            if (mChildFiles == null) {

                if (getActivity() != null) {
                    getActivity().runOnUiThread(new Runnable() {
                        public void run() {
                            mFile.setVisibility(View.VISIBLE);
                        }
                    });
                }
            } else {

                if (getActivity() != null) {
                    getActivity().runOnUiThread(new Runnable() {
                        public void run() {
                            mFile.setVisibility(View.GONE);
                        }
                    });
                }
            }
            initGridView();
        }
    }

    @Override
    public void initListener() {
        super.initListener();

        mGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                File file_Clicked = mChildFiles[position];

                if (file_Clicked.exists() && file_Clicked.canRead()) {
                    if (file_Clicked.isDirectory()) {
                        mParentFile = file_Clicked;
                        mChildFiles = file_Clicked.listFiles();
                        initGridView();
                    } else {
                        RelativeLayout appItem = (RelativeLayout) view;
                        ImageView fileSelect = (ImageView) view.findViewById(R.id.file_select);

                        if (!UIUtils.fileList.contains(file_Clicked.getPath())) {
                            UIUtils.fileList.add(file_Clicked.getPath());
                            Log.d("File Added to List", file_Clicked.getPath());
                            appItem.setBackgroundResource(R.color.CheckedItemColor);
                            fileSelect.setVisibility(View.VISIBLE);
                            FileFragment.this.updateBadge();


                        } else {
                            UIUtils.fileList.remove(file_Clicked.getPath());
                            Log.d("File Removed from List", file_Clicked.getPath());
                            appItem.setBackgroundResource(R.color.BackgroundColor);
                            fileSelect.setVisibility(View.GONE);
                            FileFragment.this.updateBadge();
                        }
                    }
                } else {
                    Toast.makeText(UIUtils.getContext(), "Permission denied", Toast.LENGTH_SHORT).show();
                }
            }
        });

        mGridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                final File file_Long_Clicked = mChildFiles[position];
                if (file_Long_Clicked.isDirectory()) {

                    if (file_Long_Clicked.listFiles().length != 0) {
                        RelativeLayout appItem = (RelativeLayout) view;
                        ImageView fileSelect = (ImageView) view.findViewById(R.id.file_select);

                        if (!UIUtils.fileList.contains(file_Long_Clicked.getPath())) {
                            UIUtils.fileList.add(file_Long_Clicked.getPath());
                            Log.d("File Added to List", file_Long_Clicked.getPath());
                            appItem.setBackgroundResource(R.color.CheckedItemColor);
                            fileSelect.setVisibility(View.VISIBLE);
                            FileFragment.this.updateBadge();


                        } else {
                            UIUtils.fileList.remove(file_Long_Clicked.getPath());
                            Log.d("File Removed from List", file_Long_Clicked.getPath());
                            appItem.setBackgroundResource(R.color.BackgroundColor);
                            fileSelect.setVisibility(View.GONE);
                            FileFragment.this.updateBadge();

                        }
                    } else {
                        Snackbar snackbar = Snackbar.make(view, "فولدر انتخابی نمی‌تواند خالی باشد!", Snackbar.LENGTH_SHORT);
                        View sbView = snackbar.getView();
                        sbView.setBackgroundColor(Color.RED);
                        TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                        tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                        tv.setTypeface(iranYekanBold);
                        snackbar.show();
                    }
                } else {
                    FileUtils.openFile(file_Long_Clicked);
                }
                return true;
            }
        });

        memory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (FileUtils.getExternalStorageDirectories().length != 0) {
                    if (memoryType == FileUtils.TYPE_PHONE_MEMORY) {
                        mParentFile = new File(FileUtils.getExternalStorageDirectories()[0]);
                        memory.setImageResource(R.drawable.memory);
                        memoryType = FileUtils.TYPE_SD;
                        initGridView();
                    } else if (memoryType == FileUtils.TYPE_SD) {
                        mParentFile = FileUtils.getFilePath();
                        memoryType = FileUtils.TYPE_PHONE_MEMORY;
                        memory.setImageResource(R.drawable.smartphone);
                        initGridView();
                    }
                }
            }
        });

    }

    @Override
    public void onPause() {
        super.onPause();
    }

    public void refresh() {
        initGridView();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (FileUtils.getExternalStorageDirectories().length != 0) {

            if (memoryType == FileUtils.TYPE_PHONE_MEMORY) {
                memory.setImageResource(R.drawable.smartphone);
            } else if (memoryType == FileUtils.TYPE_SD) {
                memory.setImageResource(R.drawable.memory);
            }
        }
        initGridView();
    }
}
