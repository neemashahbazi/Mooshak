package com.nimashahbazi.mooshak.entity;

/**
 * Created by nimashahbazi on 11/8/17.
 */

public class HistoryItem {

    private int imageId;
    private String title;
    private long timestamp;
    private int status;

    public HistoryItem(int imageId, String title, long timestamp, int status) {
        this.imageId = imageId;
        this.title = title;
        this.timestamp = timestamp;
        this.status = status;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long subtitle) {
        this.timestamp = timestamp;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }


}
