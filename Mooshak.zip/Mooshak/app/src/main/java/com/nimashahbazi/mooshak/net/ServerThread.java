package com.nimashahbazi.mooshak.net;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;


public class ServerThread extends TransferBase implements Runnable {

    private static ServerThread mServerThread;
    private ServerSocket mServerSocket;
    private String mFileSavePath;
    private ReceiveOper mReceiveOper;

    private ServerThread(String ip, int mPort, String path) {
        // TODO Auto-generated constructor stub
        this.mIp = ip;
        this.mPort = mPort;
        this.mFileSavePath = path;
        this.mThread = new Thread(this);
        this.mHostName = "";
        init();
    }

    private ServerThread(String ip, int mPort, String path, String hostName) {
        // TODO Auto-generated constructor stub
        this.mHostName = hostName;
        this.mIp = ip;
        this.mPort = mPort;
        this.mFileSavePath = path;
        this.mThread = new Thread(this);
        init();
    }

    private ServerThread(int mPort, String path) {
        // TODO Auto-generated constructor stub
        this.mIp = null;
        this.mPort = mPort;
        this.mFileSavePath = path;
        this.mThread = new Thread(this);
        this.mHostName = "";
        init();
    }

    private ServerThread(int mPort, String path, String hostName) {
        // TODO Auto-generated constructor stub
        this.mHostName = hostName;
        this.mIp = null;
        this.mPort = mPort;
        this.mFileSavePath = path;
        this.mThread = new Thread(this);
        this.mHostName = hostName;
        init();
    }

    public static synchronized ServerThread createServerThread(String ip, int port, String path) {
        if (mServerThread != null) {
            mServerThread.close();
            mServerThread = null;
        }
        mServerThread = new ServerThread(ip, port, path);
        return mServerThread;
    }

    public static synchronized ServerThread createServerThread(String ip, int port, String path, String hostName) {
        if (mServerThread != null) {
            mServerThread.close();
            mServerThread = null;
        }
        mServerThread = new ServerThread(ip, port, path, hostName);
        return mServerThread;
    }

    public static synchronized ServerThread createServerThread(int port, String path) {
        if (mServerThread != null) {
            mServerThread.close();
            mServerThread = null;
        }
        mServerThread = new ServerThread(port, path);
        return mServerThread;
    }

    public static synchronized ServerThread createServerThread(int port, String path, String hostName) {
        if (mServerThread != null) {
            mServerThread.close();
            mServerThread = null;
        }
        mServerThread = new ServerThread(port, path, hostName);
        return mServerThread;
    }

    private void init() {
        if (mHostName == null || mHostName.equals("")) {
            mHostName = android.os.Build.MODEL + "-"
                    + android.os.Build.VERSION.RELEASE;
        }
        mReceiveOper = new ReceiveOper() {
            @Override
            public void operate(ReceiveThread receive) {
                receive.start();
            }
        };
    }

    public void registerReceiveOper(ReceiveOper mReceiveOper) {

        this.mReceiveOper = mReceiveOper;

    }

    @Override
    public void run() {
        // TODO Auto-generated method stub
        try {
            while (true) {
                try {
                    if (mServerSocket == null || mServerSocket.isClosed()) {
                        mServerSocket = openServerSocket();
                        continue;
                    }
                    Socket sc = mServerSocket.accept();
                    mReceiveOper.operate(new ReceiveThread(sc, mFileSavePath, getHostName()));
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                }
            }

        } catch (Exception e) {
            mServerThread = null;
        } finally {
            try {
                if (mServerSocket != null)
                    mServerSocket.close();
            } catch (IOException e) {

            }
            mServerThread = null;
        }
    }

    private ServerSocket openServerSocket() {
        ServerSocket ssc = null;
        while (true) {
            try {
                if (mIp == null || !mIp.matches("\\d{1,3}((.\\d{1,3}){3})")) {
                    ssc = new ServerSocket(mPort);
                } else {
                    ssc = new ServerSocket(mPort, 0,
                            InetAddress.getByName(mIp));
                }
                break;
            } catch (Exception e) {
                // TODO Auto-generated catch block
                mPort++;
            }
        }
        return ssc;
    }

    public String getFileSavePath() {
        return mFileSavePath;
    }

    public void setFileSavePath(String FileSavePath) {
        this.mFileSavePath = FileSavePath;
    }

    public void interrupt() {
        mThread.interrupt();
    }

    public boolean isInterrupted() {
        return mThread.isInterrupted();
    }

    public boolean close() {
        // TODO Auto-generated method stub
        try {
            if (mServerSocket != null) {
                mServerSocket.close();
                return true;
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
        }
        return false;
    }

    public interface ReceiveOper {
        public void operate(ReceiveThread receive);
    }

}









































