package com.nimashahbazi.mooshak.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.utils.UIUtils;

import java.io.File;
import java.util.List;
import java.util.Map;

public class FileAdapter extends BaseAdapter {

    private Context context;

    private List<Map<String, Object>> mDatas;

    private LayoutInflater inflater;

    public FileAdapter(Context context, List<Map<String, Object>> Datas) {
        this.context = context;
        this.mDatas = Datas;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return mDatas.size();
    }

    @Override
    public Object getItem(int position) {
        return mDatas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.gridview_info, parent, false);
            holder.img = (ImageView) convertView.findViewById(R.id.iv_icon_name);
            holder.name = (TextView) convertView.findViewById(R.id.tv_file_name);
            holder.fileItem = (RelativeLayout) convertView.findViewById(R.id.file_item);
            holder.fileSelect = (ImageView) convertView.findViewById(R.id.file_select);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.name.setText(mDatas.get(position).get("file_name").toString());
        holder.img.setImageResource((int) mDatas.get(position).get("file_icon"));

        File file = new File(mDatas.get(position).get("file_path").toString());

        if (UIUtils.fileList.contains(file.getPath())) {
            holder.fileItem.setBackgroundResource(R.color.CheckedItemColor);
            holder.fileSelect.setVisibility(View.VISIBLE);
        } else {
            holder.fileItem.setBackgroundResource(R.color.BackgroundColor);
            holder.fileSelect.setVisibility(View.GONE);
        }

        final int mPosition = position;

        return convertView;
    }

    class ViewHolder {
        public ImageView img;
        public TextView name;
        RelativeLayout fileItem;
        ImageView fileSelect;

    }
}
