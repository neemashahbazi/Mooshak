package com.nimashahbazi.mooshak.entity;

import android.graphics.drawable.Drawable;

/**
 * Created by nimashahbazi on 10/26/17.
 */

public class AppInfo {
    private String title;
    private String path;
    private String size;
    private Drawable icon;
    private String packageName;

    public AppInfo() {
        super();
    }

    public AppInfo(String title, String path, String size, Drawable icon, String packageName) {
        super();
        this.title = title;
        this.path = path;
        this.size = size;
        this.icon = icon;
        this.packageName = packageName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public Drawable getIcon() {
        return icon;
    }

    public void setIcon(Drawable icon) {
        this.icon = icon;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

}
