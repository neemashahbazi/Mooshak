package com.nimashahbazi.mooshak.base;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.nimashahbazi.mooshak.control.TransferService;

public abstract class BaseActivity extends AppCompatActivity {
    public TransferService.ServerBinder mBinder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initView();
        initActionBar();
        initData();
        initListener();
        initFragment();
    }

    protected abstract void initView();

    protected void initActionBar() {
    }

    protected void initData() {
    }

    protected void initListener() {
    }

    protected void initFragment() {
    }


}
