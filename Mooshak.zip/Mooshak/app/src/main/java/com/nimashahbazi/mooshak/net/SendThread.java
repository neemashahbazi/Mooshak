package com.nimashahbazi.mooshak.net;

import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;


public class SendThread extends TransferSocket implements Runnable {

    private Socket mSocket;
    private DataInputStream mDis;
    private DataOutputStream mDos;
    private DataInputStream mFis;
    private File mFile;
    private int mFileNum;
    private int mTotalNum;

    public SendThread(String iP, int port, File file, int num, int totalNum) throws NoSuchFieldException {
        super();
        this.mIp = iP;
        this.mPort = port;
        this.mFile = file;
        this.mFileNum = num;
        this.mTotalNum = totalNum;

        if (!file.exists()) {
            throw new NoSuchFieldException("file does not exist");
        }
        init();
    }

    private void init() {
        mCurrRate = 0;
        mTransferLenght = 0;
        mFileLenght = mFile.length();
        mFileName = mFile.getName();
        isEnd = false;
        mThread = new Thread(this);
        data = new byte[8192];
        len = 0;
    }

    private void initRun() throws IOException {

        mSocket = new Socket();
        mSocket.connect(new InetSocketAddress(mIp, mPort), 5000);

        mDis = new DataInputStream(new BufferedInputStream(mSocket.getInputStream()));
        mDos = new DataOutputStream(new BufferedOutputStream(mSocket.getOutputStream()));
        mFis = new DataInputStream(new BufferedInputStream(new FileInputStream(mFile)));
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub

        try {

            initRun();

            len = mDis.read(data);
            mHostName = new String(data, 0, len, "UTF-8");

            mDos.writeInt(mFileNum);
            mDos.flush();

            mDos.writeInt(mTotalNum);
            mDos.flush();

            mDos.writeLong(mFileLenght);
            mDos.flush();
            mDos.write(mFileName.getBytes("UTF-8"));
            mDos.flush();
            mDis.read();

            new CountRate().start();

            len = 0;
            while ((len = mFis.read(data)) != -1) {
                mDos.write(data, 0, len);
                mTransferLenght += len;
            }

            mDos.flush();

        } catch (IOException e) {
            isEnd = true;
            mCurrRate = 0;
        } finally {
            try {
                if (mSocket != null) {
                    mSocket.close();
                }
                if (mFis != null) {
                    mFis.close();
                }
                isEnd = true;
            } catch (IOException e) {

            }
        }

    }

    public void close() {
        try {
            this.mSocket.close();
        } catch (IOException e) {
        }
    }

    public long getSendRate() {
        return getRate();
    }

    private class CountRate extends Thread {

        public CountRate() {
            // TODO Auto-generated constructor stub
        }

        @Override
        public void run() {
            // TODO Auto-generated method stub
            super.run();

            long preTime;
            long currTime;
            long timeDiff;
            long preLenght;
            long currLenght;

            preLenght = mTransferLenght;
            preTime = System.currentTimeMillis();
            while (mTransferLenght < mFileLenght && !isEnd) {
                currTime = System.currentTimeMillis();
                currLenght = mTransferLenght;
                timeDiff = currTime - preTime;
                if (timeDiff != 0) {
                    mCurrRate = (long) ((double) (mTransferLenght - preLenght) * 1000.0 / (double) timeDiff);
                } else {
                    mCurrRate = 0;
                }
                preLenght = currLenght;
                preTime = currTime;
                try {
                    Thread.sleep(500);
                } catch (Exception e) {
                }
            }
            mCurrRate = 0;

        }

    }

}













































