package com.nimashahbazi.mooshak.activity;

import android.graphics.Typeface;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;

import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.base.BaseActivity;


public class AboutActivity extends BaseActivity {
    Typeface iranYekanBold;
    private Toolbar mToolbar;

    @Override
    public void initView() {
        setContentView(R.layout.activity_about);
        iranYekanBold = Typeface.createFromAsset(getAssets(), "fonts/iranyekanwebbold.ttf");
        TextView about = (TextView) findViewById(R.id.about);
        about.setTypeface(iranYekanBold);


    }

    @Override
    protected void initActionBar() {
        super.initActionBar();

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        mToolbar.setTitle("درباره‌ی ما");
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TextView mTitle = (TextView) mToolbar.findViewById(R.id.toolbar_title);
        mTitle.setTypeface(iranYekanBold);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

    }

    @Override
    protected void initData() {
        super.initData();
    }

    @Override
    protected void initListener() {
        super.initListener();
    }

    @Override
    protected void initFragment() {
        super.initFragment();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;

            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
