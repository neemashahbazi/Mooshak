package com.nimashahbazi.mooshak.utils;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.support.v4.os.EnvironmentCompat;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nimashahbazi.mooshak.R;

import java.io.File;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class FileUtils {

    public static final int OPEN_FILE = 0;
    public static final int CHANGE_FILE_NAME = 1;
    public static final int DELETE_FILE = 2;
    public static final int FILE_INFO = 3;
    final public static int TYPE_FOLDER = 0;
    final public static int TYPE_MUSIC = 1;
    final public static int TYPE_MEDIA = 2;
    final public static int TYPE_PICTURE = 3;
    final public static int TYPE_APK = 4;
    final public static int TYPE_ZIP = 5;
    final public static int TYPE_UNKOWN = 6;
    final public static int TYPE_DOUCMENT_EXCEL = 7;
    final public static int TYPE_DOUCMENT_PDF = 8;
    final public static int TYPE_DOUCMENT_PPT = 9;
    final public static int TYPE_DOUCMENT_TEXT = 10;
    final public static int TYPE_DOUCMENT_WORD = 11;
    final public static int TYPE_ENCRYPTED = 12;

    final public static int TYPE_PHONE_MEMORY = 101;
    final public static int TYPE_SD = 102;


    public final static String[] MUSIC = {"wav", "mp3", "flac", "wma", "ape"};
    public final static String[] VIDEO = {"rm", "rmvb", "wmv", "avi", "mp4", "3gp", "mkv", "mov"};
    public final static String[] DOCUMENT = {"txt", "doc", "excel", "ppt", "pdf"};
    public final static String[] BITMAP = {"bmp", "gif", "jpg", "pic", "png", "tif"};
    public final static String APK = "apk";
    public final static String ENCR = "encr";
    public final static String DIR = "dir";


    public final static String[] RAR = {"rar", "zip", "7z"};
    public static int[] Icons = new int[]{
            R.mipmap.ic_folder, R.mipmap.ic_music,
            R.mipmap.ic_media, R.mipmap.ic_picture,
            R.mipmap.ic_apk, R.mipmap.ic_zip,
            R.mipmap.ic_unkown, R.mipmap.ic_excel,
            R.mipmap.ic_pdf, R.mipmap.ic_ppt,
            R.mipmap.ic_text, R.mipmap.ic_word,
            R.mipmap.ic_encr
    };
    public static int count;
    public static Long size;
    public static DecimalFormat decimalFormat = new DecimalFormat("0.00");
    public static DecimalFormat decimalFormat_b = new DecimalFormat("0.000");
    public static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");


    public static String getFileName(File file) {
        return file.getName();
    }

    public static String getFileType(File file) {
        if (file.isDirectory())
            return "folder";
        String string = file.getName();
        int i;
        for (i = string.length() - 1; i != -1; i--)
            if (string.charAt(i) == '.')
                break;

        return string.substring(i + 1) + "format";
    }

    public static String getFileSize(File file) {
        if (file.isFile()) {
            if (file.length() / (1024 * 1024) > 1024)
                return (decimalFormat.format(file.length() / 1024.0 / 1024.0 / 1024.0)) + " GB";
            else if (file.length() / 1024 > 1024)
                return (decimalFormat.format(file.length() / 1024.0 / 1024.0)) + " MB";
            else if (file.length() > 1024)
                return (decimalFormat.format(file.length() / 1024.0)) + " KB";
            else
                return file.length() + " B";
        } else {
            count = 0;
            size = 0l;
            dfs(file);

            if (count == 0)
                return "Empty folder";
            else if (size / (1024 * 1024) > 1024)
                return (decimalFormat.format(size / 1024.0 / 1024.0 / 1024.0)) + " GB  " + "(" + count + "File)";
            else if (size / 1024 > 1024)
                return (decimalFormat.format(size / 1024.0 / 1024.0)) + " MB  " + "(" + count + "File)";
            else if (size > 1024)
                return (decimalFormat.format(size / 1024.0)) + " KB  " + "(" + count + "File)";
            else
                return size + " B" + "(" + count + "File)";
        }
    }


    private static void dfs(File f) {
        if (f.isFile()) {
            count++;
            size += f.length();
        } else {
            File[] files = f.listFiles();
            for (File file : files)
                dfs(file);
        }
    }


    public static String getPermission(File file) {
        return "\nReadable:\t\t\t\t\t" + (file.canRead() ? "Yes" : "No") + "\n\nWritable:\t\t\t\t\t" + (file.canWrite() ? "Yes" : "No") + "\n\nHidden:\t\t\t\t\t" + (file.isHidden() ? "Yes" : "No");
    }


    public static String getlastModified(File file) {
        Date data = new Date(file.lastModified());
        return simpleDateFormat.format(data);
    }


    public static File getFilePath() {
        return Environment.getExternalStorageDirectory();
    }

    public static File[] filtration(File[] files) {

        boolean[] f = new boolean[files.length];
        int size = 0;

        for (int i = 0; i < files.length; i++) {
            if (!files[i].getName().startsWith(".") && !files[i].getName().startsWith("com.") && !files[i].getName().startsWith("cn.")) {
                f[i] = true;
                size++;
            }
        }

        int n = 0;
        File[] res = new File[size];
        for (int i = 0; i < files.length; i++) {
            if (f[i]) {
                res[n++] = files[i];
            }
        }
        return res;
    }

    public static boolean deleteFile(File file) {
        if (file.isFile()) {
            return file.delete();
        }
        if (file.isDirectory()) {
            File[] childFile = file.listFiles();
            if (childFile == null || childFile.length == 0) {
                return file.delete();
            }
            for (File f : childFile) {
                deleteFile(f);
            }
            file.delete();
        }
        return true;
    }

    public static int getIcons(File file) {
        int type = TYPE_UNKOWN;

        if (file.isDirectory()) {
            return TYPE_FOLDER;
        }

        String fileName = file.getName();

        String fileNameEnd = fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length()).toLowerCase();

        if (fileNameEnd.equals(DOCUMENT[0])) {
            return TYPE_DOUCMENT_TEXT;
        }

        if (fileNameEnd.equals(DOCUMENT[1])) {
            return TYPE_DOUCMENT_WORD;
        }

        if (fileNameEnd.equals(DOCUMENT[2])) {
            return TYPE_DOUCMENT_EXCEL;
        }

        if (fileNameEnd.equals(DOCUMENT[3])) {
            return TYPE_DOUCMENT_PPT;
        }

        if (fileNameEnd.equals(DOCUMENT[4])) {
            return TYPE_DOUCMENT_PDF;
        }

        for (String string : MUSIC) {
            if (fileNameEnd.equals(string)) {
                return TYPE_MUSIC;
            }
        }

        for (String string : MUSIC) {
            if (fileNameEnd.equals(string)) {
                return TYPE_MUSIC;
            }
        }

        for (String string : VIDEO) {
            if (fileNameEnd.equals(string)) {
                return TYPE_MEDIA;
            }
        }

        for (String string : BITMAP) {
            if (fileNameEnd.equals(string)) {
                return TYPE_PICTURE;
            }
        }

        if (fileNameEnd.equals(APK)) {
            return TYPE_APK;
        }

        if (fileNameEnd.equals(ENCR)) {
            return TYPE_ENCRYPTED;
        }

        if (fileNameEnd.equals(DIR)) {
            return TYPE_FOLDER;
        }

        for (String string : RAR) {
            if (fileNameEnd.equals(string)) {
                return TYPE_ZIP;
            }
        }

        return type;
    }


    public static String getMIMEType(File file) {
        String type = "";
        String name = file.getName();
        String end = name.substring(name.lastIndexOf(".") + 1, name.length()).toLowerCase();
        if (end.equals("m4a") || end.equals("mp3") || end.equals("wav")) {
            type = "audio";
        } else if (end.equals("mp4") || end.equals("3gp")) {
            type = "video";
        } else if (end.equals("jpg") || end.equals("png") || end.equals("jpeg") || end.equals("bmp") || end.equals("gif")) {
            type = "image";
        } else {

            type = "*";
        }
        type += "/*";
        return type;
    }

    public static void openFile(File file) {
        Intent intent = new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setAction(Intent.ACTION_VIEW);
        String type = FileUtils.getMIMEType(file);
        intent.setDataAndType(Uri.fromFile(file), type);
        UIUtils.getContext().startActivity(intent);
    }


    public static void setDialogFileInfo(LinearLayout linearLayout, File file) {

        ImageView icon_file_info = (ImageView) linearLayout.findViewById(R.id.dialog_icon_file_info);
        TextView name_file_info = (TextView) linearLayout.findViewById(R.id.dialog_name_file_info);
        TextView type_file_info = (TextView) linearLayout.findViewById(R.id.dialog_type_file_info);
        TextView path_file_info = (TextView) linearLayout.findViewById(R.id.dialog_path_file_info);
        final TextView size_file_info = (TextView) linearLayout.findViewById(R.id.dialog_size_file_info);
        TextView updatetime_file_info = (TextView) linearLayout.findViewById(R.id.dialog_updatetime_file_info);
        TextView permission_file_info = (TextView) linearLayout.findViewById(R.id.dialog_premission_file_info);

        icon_file_info.setImageResource(FileUtils.Icons[FileUtils.getIcons(file)]);
        name_file_info.setText(FileUtils.getFileName(file));
        type_file_info.setText("Type:\t\t\t" + FileUtils.getFileType(file));
        path_file_info.setText("Path:\t\t\t" + file.getPath().substring(FileUtils.getFilePath().getPath().length()));


        size_file_info.setText("Size:\t\t\t" + FileUtils.getFileSize(file));


        updatetime_file_info.setText("Created at:\t\t\t" + FileUtils.getlastModified(file));
        permission_file_info.setText("Authority:\n" + FileUtils.getPermission(file));
    }

    public static String[] getExternalStorageDirectories() {

        List<String> results = new ArrayList<>();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) { //Method 1 for KitKat & above
            File[] externalDirs = UIUtils.getContext().getExternalFilesDirs(null);

            for (File file : externalDirs) {
                String path = file.getPath().split("/Android")[0];

                boolean addPath = false;

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    addPath = Environment.isExternalStorageRemovable(file);
                } else {
                    addPath = Environment.MEDIA_MOUNTED.equals(EnvironmentCompat.getStorageState(file));
                }

                if (addPath) {
                    results.add(path);
                }
            }
        }

        if (results.isEmpty()) {
            String output = "";
            try {
                final Process process = new ProcessBuilder().command("mount | grep /dev/block/vold")
                        .redirectErrorStream(true).start();
                process.waitFor();
                final InputStream is = process.getInputStream();
                final byte[] buffer = new byte[1024];
                while (is.read(buffer) != -1) {
                    output = output + new String(buffer);
                }
                is.close();
            } catch (final Exception e) {
            }
            if (!output.trim().isEmpty()) {
                String devicePoints[] = output.split("\n");
                for (String voldPoint : devicePoints) {
                    results.add(voldPoint.split(" ")[2]);
                }
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            for (int i = 0; i < results.size(); i++) {
                if (!results.get(i).toLowerCase().matches(".*[0-9a-f]{4}[-][0-9a-f]{4}")) {
                    Log.d("TAG", results.get(i) + " might not be extSDcard");
                    results.remove(i--);
                }
            }
        } else {
            for (int i = 0; i < results.size(); i++) {
                if (!results.get(i).toLowerCase().contains("ext") && !results.get(i).toLowerCase().contains("sdcard")) {
                    Log.d("TAG", results.get(i) + " might not be extSDcard");
                    results.remove(i--);
                }
            }
        }

        String[] storageDirectories = new String[results.size()];
        for (int i = 0; i < results.size(); ++i) storageDirectories[i] = results.get(i);

        return storageDirectories;
    }

    public static void removeTemp() {
        final File dirEncrypted = new File(Environment.getExternalStoragePublicDirectory("Android/data/" + UIUtils.getPackageName() + "/Files/Encrypted").toString());
        File[] fileListEncrypted = dirEncrypted.listFiles();
        for (int i = 0; i < fileListEncrypted.length; i++) {
            deleteFile(fileListEncrypted[i]);
        }
        final File dirCompressed = new File(Environment.getExternalStoragePublicDirectory("Android/data/" + UIUtils.getPackageName() + "/Files/Compressed").toString());
        File[] fileListCompressed = dirCompressed.listFiles();
        for (int i = 0; i < fileListCompressed.length; i++) {
            deleteFile(fileListCompressed[i]);
        }
    }

    public static class FileComparer implements Comparator<File> {
        @Override
        public int compare(File lhs, File rhs) {

            int i = 0;
            char o1_i;
            char o2_i;

            String o1 = lhs.getName();
            String o2 = rhs.getName();

            if ((lhs.isDirectory() && rhs.isDirectory()) || (lhs.isFile() && rhs.isFile())) {
                i = lhs.getName().compareToIgnoreCase(rhs.getName());
                return i;
            }

            if (lhs.isDirectory()) {
                i = -1;
                return i;
            }
            if (rhs.isDirectory()) {
                i = 1;
                return i;
            }

            while (true) {

                if (o1.charAt(i) >= 65 && o1.charAt(i) <= 90)
                    o1_i = (char) (o1.charAt(i) + 32);
                else
                    o1_i = o1.charAt(i);


                if (o2.charAt(i) >= 65 && o2.charAt(i) <= 90)
                    o2_i = (char) (o2.charAt(i) + 32);
                else
                    o2_i = o2.charAt(i);

                if (o1_i == o2_i && i < o1.length() - 1 && i < o2.length() - 1) {
                    i++;
                } else
                    break;
            }

            return o1_i - o2_i;
        }
    }

}
