package com.nimashahbazi.mooshak.fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.adapter.AppAdapter;
import com.nimashahbazi.mooshak.base.BaseFragment;
import com.nimashahbazi.mooshak.entity.AppInfo;
import com.nimashahbazi.mooshak.net.WifiAdmin;
import com.nimashahbazi.mooshak.utils.AppUtils;
import com.nimashahbazi.mooshak.utils.FileUtils;
import com.nimashahbazi.mooshak.utils.UIUtils;

import java.util.ArrayList;

import static android.widget.AdapterView.OnItemClickListener;
import static android.widget.AdapterView.OnItemLongClickListener;

public class AppFragment extends BaseFragment {

    private static WifiAdmin mWifiAdmin;
    private static long exitTime = 0;
    AppAdapter appAdapter;
    private TextView mFile;
    private ListView listView;
    private ArrayList<AppInfo> mAppInfoList;
    private ProgressBar progressBar;
    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 0x127: {
                    if (getActivity() != null) {
                        appAdapter = new AppAdapter(getActivity(), mAppInfoList);
                        listView.setAdapter(appAdapter);
                        listView.setEmptyView(mFile);
                        progressBar.setVisibility(View.GONE);
                    }
                    break;
                }
            }
        }
    };

    public static boolean onKeyUp(int keyCode, KeyEvent event) {


        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0 && ((System.currentTimeMillis() - exitTime) > 2000)) {

            Toast toast = Toast.makeText(UIUtils.getContext(), "جهت خروج، مجددا دکمه‌ی «بازگشت» را لمس کنید...", Toast.LENGTH_SHORT);
            if (toast.getView() instanceof LinearLayout) {
                LinearLayout toastLayout = (LinearLayout) toast.getView();
                TextView toastTV = (TextView) toastLayout.getChildAt(0);
                Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");
                toastTV.setTypeface(iranYekanBold);
                toastTV.setTextSize(12);
            } else if (toast.getView() instanceof RelativeLayout) {
                RelativeLayout toastLayout = (RelativeLayout) toast.getView();
                TextView toastTV = (TextView) toastLayout.getChildAt(0);
                Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");
                toastTV.setTypeface(iranYekanBold);
                toastTV.setTextSize(12);
            }
            toast.show();
            exitTime = System.currentTimeMillis();

            return false;
        } else {
            if (mWifiAdmin.isWifiApOpen()) {
                mWifiAdmin.closeWifiAp();
            } else if (mWifiAdmin.isConnect()) {
                mWifiAdmin.disconnectFromNetwork();
            }
            mWifiAdmin.removeAllWifiConfiguration();
            mWifiAdmin.setDefaultAP();
            FileUtils.removeTemp();
            return true;
        }

    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View initView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_app, container, false);
        listView = (ListView) view.findViewById(R.id.list_app);
        progressBar = (ProgressBar) view.findViewById(R.id.loading_app);
        Typeface iranYekanBold = Typeface.createFromAsset(getActivity().getAssets(), "fonts/iranyekanwebbold.ttf");
        mFile = (TextView) view.findViewById(R.id.tv_no_file);
        mFile.setTypeface(iranYekanBold);
        return view;
    }

    @Override
    public void init() {
        super.init();
    }

    @Override
    public void initData() {
        super.initData();
        new Thread(new Runnable() {
            @Override
            public void run() {
                mAppInfoList = (ArrayList<AppInfo>) AppUtils.getAppInfos(getContext());

                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if (mAppInfoList != null) {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {
                                mFile.setVisibility(View.GONE);
                            }
                        });
                    }
                    Message msg = new Message();
                    msg.what = 0x127;
                    mHandler.sendMessage(msg);
                } else {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {
                                mFile.setVisibility(View.VISIBLE);
                            }
                        });
                    }
                }

            }
        }).start();

        mWifiAdmin = new WifiAdmin(getContext());

    }

    @Override
    public void initListener() {
        super.initListener();

        this.listView.setOnItemClickListener(new ListItemClick());
        this.listView.setOnItemLongClickListener(new ListItemLongClick());
    }

    public void refresh() {
        appAdapter.notifyDataSetChanged();
    }

    private class ListItemLongClick implements OnItemLongClickListener {

        private static final String SCHEME = "package:";

        public boolean onItemLongClick(AdapterView<?> parent, View view, int position,
                                       long id) {
            Uri packageURI = Uri.parse(SCHEME + mAppInfoList.get(position).getPackageName());
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, packageURI);
            startActivity(intent);
            return true;

        }
    }

    private class ListItemClick implements OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            RelativeLayout appItem = (RelativeLayout) view;
            CheckBox appSelect = (CheckBox) view.findViewById(R.id.cx_app_select);


            if (!UIUtils.fileList.contains(AppUtils.getAppInfos(UIUtils.getContext()).get(position).getPath())) {
                appItem.setBackgroundResource(R.color.CheckedItemColor);
                appSelect.setChecked(true);

            } else {
                appItem.setBackgroundResource(R.color.BackgroundColor);
                appSelect.setChecked(false);
            }
        }
    }

}
