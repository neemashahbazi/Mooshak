package com.nimashahbazi.mooshak.utils;

import android.content.Context;
import android.database.Cursor;
import android.provider.MediaStore;

import com.nimashahbazi.mooshak.entity.VideoInfo;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class VideoUtils {

    public static DecimalFormat decimalFormat = new DecimalFormat("0.00");

    public static List<VideoInfo> getVideoInfos(Context context) {

        List<VideoInfo> videoInfos = new ArrayList<VideoInfo>();

        VideoInfo videoInfo = null;

        Cursor cursor = context.getContentResolver().query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, null, null,
                null, null);
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID));

            String title = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE));


            String album = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.ALBUM));

            String artist = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.ARTIST));

            String displayName = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME));

            String mimeType = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE));

            String path = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA));

            long duration = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION));

            long size = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE));


            videoInfo = new VideoInfo(id, title, album, artist, displayName, mimeType, path, size, duration);

            videoInfos.add(videoInfo);

        }

        cursor.close();

        return videoInfos;

    }

    public static String getVideoSize(long size) {

        if (size / (1024 * 1024) > 1024)
            return (decimalFormat.format(size / 1024.0 / 1024.0 / 1024.0)) + " GB";
        else if (size / 1024 > 1024)
            return (decimalFormat.format(size / 1024.0 / 1024.0)) + " MB";
        else if (size > 1024)
            return (decimalFormat.format(size / 1024.0)) + " KB";
        else
            return size + " B";

    }

}
