package com.nimashahbazi.mooshak.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.utils.UIUtils;

import java.util.ArrayList;

/**
 * Created by nimashahbazi on 12/4/17.
 */

public class ClientAdapter extends BaseAdapter {

    Context context;
    private ArrayList<String> items;
    private LayoutInflater inflater;

    public ClientAdapter(Context context, int resourceId, ArrayList<String> items) {
        this.context = context;
        this.items = items;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return this.items.size();
    }

    @Override
    public Object getItem(int position) {
        return this.items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");

        final ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.client_item, parent, false);
            holder.clientTitle = (TextView) convertView.findViewById(R.id.title);
            holder.clientTitle.setTypeface(iranYekanBold);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.clientTitle.setText(items.get(position));

        return convertView;
    }

    class ViewHolder {
        public TextView clientTitle;

    }
}
