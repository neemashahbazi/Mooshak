package com.nimashahbazi.mooshak.activity;

import android.graphics.Typeface;
import android.os.Build;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;

import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.base.BaseActivity;

public class HelpActivity extends BaseActivity {

    Typeface iranYekanBold;
    private Toolbar mToolbar;

    @Override
    public void initView() {
        setContentView(R.layout.activity_help);
        iranYekanBold = Typeface.createFromAsset(getAssets(), "fonts/iranyekanwebbold.ttf");
        TextView hint1 = (TextView) findViewById(R.id.hint_1);
        hint1.setTypeface(iranYekanBold);
        TextView hint2 = (TextView) findViewById(R.id.hint_2);
        hint2.setTypeface(iranYekanBold);
        TextView hint3 = (TextView) findViewById(R.id.hint_3);
        hint3.setTypeface(iranYekanBold);
        TextView hint4 = (TextView) findViewById(R.id.hint_4);
        hint4.setTypeface(iranYekanBold);

        if (android.os.Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            hint2.setText("با استفاده از دکمه‌ی موشک یکی از طرفین از طریق دکمه‌ی «ایجاد شبکه‌ی معمولی» هات‌اسپات ایجاد کرده و طرف دیگر با استفاده از دکمه‌ی «اتصال به شبکه» شبکه را مشاهده کرده و به آن متصل می‌شود. در صورت تمایل کاربران به برقراری اتصال امن لازم است طرف سازنده‌ی شبکه یک «کلید اتصال و رمزنگاری» در تنظیمات برنامه تعریف کرده و سپس با استفاده از دکمه‌ی «ایجاد شبکه‌ی امن» اقدام به برقراری یک شبکه‌ی محافظت شده کند.");
        } else {
            hint2.setText("با استفاده از دکمه‌ی موشک یکی از طرفین از طریق دکمه‌ی «ایجاد شبکه» به صفحه‌ی مربوط به تنظیمات هات‌اسپات دستگاه هدایت شده و با فعال کردن آن اقدام به ایجاد هات‌اسپات کرده و طرف دیگر با استفاده از دکمه‌ی «اتصال به شبکه» شبکه را مشاهده کرده و به آن متصل می‌شود. در صورت تمایل کاربران به برقراری اتصال امن لازم است طرف سازنده‌ی شبکه در صفحه‌ی مربوط به تنظیمات هات‌اسپات نوع رمزنگاری شبکه را به WPA PSK تبدیل و یک رمز عبور برای آن در نظر بگیرد.");

        }

    }

    @Override
    protected void initActionBar() {
        super.initActionBar();

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        mToolbar.setTitle("Help");
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TextView mTitle = (TextView) mToolbar.findViewById(R.id.toolbar_title);
        mTitle.setTypeface(iranYekanBold);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

    }


    @Override
    protected void initData() {
        super.initData();
    }

    @Override
    protected void initListener() {
        super.initListener();
    }

    @Override
    protected void initFragment() {
        super.initFragment();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;

            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
