package com.nimashahbazi.mooshak.activity;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.nimashahbazi.mooshak.R;


public class PasswordActivity extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    Typeface iranYekanBold;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);
        TextView appName = (TextView) findViewById(R.id.app_name);
        TextView appSlogan = (TextView) findViewById(R.id.app_slogan);
        TextView btnContinue = (TextView) findViewById(R.id.btn_continue);
        final EditText etPassword = (EditText) findViewById(R.id.et_password);
        final EditText etRePassword = (EditText) findViewById(R.id.et_re_password);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());


        iranYekanBold = Typeface.createFromAsset(getAssets(), "fonts/iranyekanwebbold.ttf");
        appName.setTypeface(iranYekanBold);
        appSlogan.setTypeface(iranYekanBold);
        btnContinue.setTypeface(iranYekanBold);
        etPassword.setTypeface(iranYekanBold);
        etRePassword.setTypeface(iranYekanBold);

        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                String password;
                password = etPassword.getText().toString();
                if (!password.isEmpty()) {
                    if (password.equals(etRePassword.getText().toString())) {
                        editor.putString("password", password);
                        editor.putString("passwordRequest", "1");
                        editor.commit();
                        PasswordActivity.this.finish();
                    } else {
                        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "رمز عبور و تکرار آن با هم مطابقت ندارند!", Snackbar.LENGTH_SHORT);
                        View sbView = snackbar.getView();
                        sbView.setBackgroundColor(Color.RED);
                        TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                        tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                        tv.setTypeface(iranYekanBold);
                        snackbar.show();
                    }
                } else {
                    Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "رمز عبور نباید خالی باشد!", Snackbar.LENGTH_SHORT);
                    View sbView = snackbar.getView();
                    sbView.setBackgroundColor(Color.RED);
                    TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                    tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                    tv.setTypeface(iranYekanBold);
                    snackbar.show();
                }
            }
        });

    }

    public void onBackPressed() {
        PasswordActivity.this.finish();
    }
}
