package com.nimashahbazi.mooshak.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.entity.HistoryItem;
import com.nimashahbazi.mooshak.utils.FileUtils;
import com.nimashahbazi.mooshak.utils.HistoryUtils;
import com.nimashahbazi.mooshak.utils.UIUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class HistoryAdapter extends BaseAdapter {

    Context context;
    private ArrayList<HistoryItem> items;
    private LayoutInflater inflater;


    public HistoryAdapter(Context context, int resourceId, ArrayList<HistoryItem> items) {
        this.context = context;
        this.items = items;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return this.items.size();
    }

    @Override
    public Object getItem(int position) {
        return this.items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");

        final ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.history_item, parent, false);
            holder.historyIcon = (ImageView) convertView.findViewById(R.id.icon);
            holder.historyTitle = (TextView) convertView.findViewById(R.id.title);
            holder.historyTitle.setTypeface(iranYekanBold);
            holder.historySubtitle = (TextView) convertView.findViewById(R.id.subtitle);
            holder.status = (ImageView) convertView.findViewById(R.id.status);
            holder.historySubtitle.setTypeface(iranYekanBold);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }


        long timestamp = items.get(position).getTimestamp();
        Date date = new Date(timestamp);
        DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm");
        String dateFormatted = formatter.format(date);

        String sendSubtitle = "ارسال شده در " + dateFormatted;
        String receiveSubtitle = "دریافت شده در " + dateFormatted;
        String createdNetworkSubtitle = dateFormatted;
        String joinedNetworkSubtitle = dateFormatted;


        if (items.get(position).getStatus() == HistoryUtils.STATUS_RECEIVE) {
            holder.status.setImageResource(R.drawable.received);
            holder.historySubtitle.setText(receiveSubtitle);
            holder.historyTitle.setText(items.get(position).getTitle());
            holder.historyIcon.setImageResource(FileUtils.Icons[items.get(position).getImageId()]);


        } else if (items.get(position).getStatus() == HistoryUtils.STATUS_SEND) {
            holder.status.setImageResource(R.drawable.sent);
            holder.historySubtitle.setText(sendSubtitle);
            holder.historyTitle.setText(items.get(position).getTitle());
            holder.historyIcon.setImageResource(FileUtils.Icons[items.get(position).getImageId()]);

        } else if (items.get(position).getStatus() == HistoryUtils.STATUS_CREATE_NETWORK) {
            holder.historySubtitle.setText(createdNetworkSubtitle);
            holder.historyTitle.setText("شبکه‌ی " + items.get(position).getTitle() + " ایجاد شد!");
            holder.historyIcon.setImageResource(items.get(position).getImageId());
            holder.status.setImageResource(0);

        } else if (items.get(position).getStatus() == HistoryUtils.STATUS_CONNECTED_TO_NETWORK) {
            holder.historySubtitle.setText(joinedNetworkSubtitle);
            holder.historyIcon.setImageResource(items.get(position).getImageId());
            holder.historyTitle.setText("اتصال به شبکه‌ی " + items.get(position).getTitle() + " برقرار شد!");
            holder.status.setImageResource(0);
        }

        return convertView;
    }

    class ViewHolder {
        public ImageView historyIcon;
        public TextView historyTitle;
        public TextView historySubtitle;
        public ImageView status;
    }
}
