package com.nimashahbazi.mooshak.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.entity.RowItem;
import com.nimashahbazi.mooshak.utils.UIUtils;

import org.apache.commons.io.FilenameUtils;

import java.util.List;


public class DraftAdapter extends ArrayAdapter<RowItem> {


    Context context;
    private List<RowItem> items;

    public DraftAdapter(Context context, int resourceId,
                        List<RowItem> items) {
        super(context, resourceId, items);
        this.context = context;
        this.items = items;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        DraftAdapter.ViewHolder holder = null;
        final RowItem rowItem = getItem(position);
        Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");

        LayoutInflater mInflater = (LayoutInflater) context
                .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.draft_item, parent, false);
            holder = new ViewHolder();
            holder.txtTitle = (TextView) convertView.findViewById(R.id.title);
            holder.txtTitle.setTypeface(iranYekanBold);
            holder.remove = (ImageView) convertView.findViewById(R.id.remove);
            holder.imageView = (ImageView) convertView.findViewById(R.id.icon);
            convertView.setTag(holder);
        } else
            holder = (ViewHolder) convertView.getTag();
        if (FilenameUtils.getExtension(rowItem.getTitle()).equals("apk")) {
            PackageManager pm = (PackageManager) UIUtils.getContext().getPackageManager();
            PackageInfo info = pm.getPackageArchiveInfo(rowItem.getTitle(), PackageManager.GET_ACTIVITIES);
            ApplicationInfo appInfo = info.applicationInfo;
            holder.txtTitle.setText(pm.getApplicationLabel(appInfo));
        } else {
            holder.txtTitle.setText(FilenameUtils.getName(rowItem.getTitle()));
        }
        holder.imageView.setImageResource(rowItem.getImageId());
        holder.remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UIUtils.fileList.remove(rowItem.getTitle());
                items.remove(position);
                notifyDataSetChanged();
            }
        });
        return convertView;
    }

    private class ViewHolder {
        ImageView imageView;
        TextView txtTitle;
        ImageView remove;
    }
}
