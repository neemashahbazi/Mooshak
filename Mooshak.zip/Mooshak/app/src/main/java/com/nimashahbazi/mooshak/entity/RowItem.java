package com.nimashahbazi.mooshak.entity;

/**
 * Created by nimashahbazi on 11/4/17.
 */

public class RowItem {

    private int imageId;
    private String title;

    public RowItem(String title, int imageId) {
        this.imageId = imageId;
        this.title = title;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
