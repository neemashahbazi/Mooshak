package com.nimashahbazi.mooshak.utils;

/**
 * Created by nimashahbazi on 11/8/17.
 */

public class HistoryUtils {
    public static final int STATUS_SEND = 0;
    public static final int STATUS_RECEIVE = 1;
    public static final int STATUS_CREATE_NETWORK = 2;
    public static final int STATUS_CONNECTED_TO_NETWORK = 3;
}
