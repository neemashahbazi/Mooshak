package com.nimashahbazi.mooshak.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.nimashahbazi.mooshak.MainActivity;
import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.entity.ImageInfo;
import com.nimashahbazi.mooshak.utils.PictureUtils;
import com.nimashahbazi.mooshak.utils.UIUtils;

import java.io.File;
import java.util.ArrayList;


public class PictureAdapter extends BaseAdapter {

    private Context context;

    private ArrayList<ImageInfo> mDatas;

    private LayoutInflater inflater;

    public PictureAdapter(Context context, ArrayList<ImageInfo> Datas) {
        this.context = context;
        this.mDatas = Datas;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mDatas.size();
    }

    @Override
    public Object getItem(int position) {
        return mDatas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.picture_item, parent, false);
            holder.img = (ImageView) convertView.findViewById(R.id.iv_picture);
            holder.cx = (CheckBox) convertView.findViewById(R.id.rb_pictrue_select);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
            holder.cx.setOnCheckedChangeListener(null);
        }

        File picture = new File(mDatas.get(position).getPath());

        Glide.with(context).load(picture).into(holder.img);

        holder.img.setScaleType(ImageView.ScaleType.CENTER_CROP);

        if (UIUtils.fileList.contains(this.mDatas.get(position).getPath())) {
            holder.cx.setChecked(true);
        } else {
            holder.cx.setChecked(false);
        }

        final int mPosition = position;

        holder.cx.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    UIUtils.fileList.add(PictureUtils.getPictureInfos(UIUtils.getContext()).get(mPosition).getPath());
                    ((MainActivity) context).updateBadge();


                } else {
                    UIUtils.fileList.remove(PictureUtils.getPictureInfos(UIUtils.getContext()).get(mPosition).getPath());
                    ((MainActivity) context).updateBadge();
                }
            }
        });

        return convertView;
    }

    class ViewHolder {
        public ImageView img;
        public CheckBox cx;
    }
}
