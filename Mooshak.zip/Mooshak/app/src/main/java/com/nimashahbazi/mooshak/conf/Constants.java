package com.nimashahbazi.mooshak.conf;


import com.nimashahbazi.mooshak.utils.LogUtils;

public class Constants {
    public static final int DEBUGLEVEL = LogUtils.LEVEL_ALL;

    public static final int PORT = 6602;

    public static final String TEST_IP = "192.168.56.1";

    public static final int IS_FIRST = 0;
    public static final int IS_NOT_FIRST = 1;
    public static final int IS_CANCELED = 2;
    public static final String WIFI_AP_NAME = "Mshk";
    public static final String WIFI_AP_PSWD = "12345678";
    public static final String PROPERTIES_FILE_NAME = "properties";
    public static final String CHANGE_HOST_NAME = "com.nimashahbazi.mooshak.MainActivity.Broadcast.CHANGE_NAME";
    public static final String FILE_RECEIVE = "com.nimashahbazi.mooshak.MainActivity.Broadcast.FILE_RECEIVE";
    public static final String FILE_RECEIVE_PEOGRESS = "com.nimashahbazi.mooshak.MainActivity.Broadcast.FILE_RECEIVE_PEOGRESS";
    public static final String FILE_RECEIVE_END = "com.nimashahbazi.mooshak.MainActivity.Broadcast.FILE_RECEIVE_END";
    public static final String FILE_RECEIVE_UNSUCCESSFUL = "com.nimashahbazi.mooshak.MainActivity.Broadcast.FILE_RECEIVE_UNSUCCESSFUL";
    public static final String FILE_RECEIVE_FIRST_START = "com.nimashahbazi.mooshak.MainActivity.Broadcast.FILE_RECEIVE_FIRST_START";
    public static final String FILE_RECEIVE_LAST_END = "com.nimashahbazi.mooshak.MainActivity.Broadcast.FILE_RECEIVE_LAST_END";
    public static final String FILE_SEND = "com.nimashahbazi.mooshak.MainActivity.Broadcast.FILE_SEND";
    public static final String FILE_SEND_NAME = "com.nimashahbazi.mooshak.MainActivity.Broadcast.FILE_SEND_NAME";
    public static final String FILE_SEND_PEOGRESS = "com.nimashahbazi.mooshak.MainActivity.Broadcast.FILE_SEND_PEOGRESS";
    public static final String FILE_SEND_END = "com.nimashahbazi.mooshak.MainActivity.Broadcast.FILE_SEND_END";
    public static final String FILE_SEND_UNSUCCESSFUL = "com.nimashahbazi.mooshak.MainActivity.Broadcast.FILE_SEND_UNSUCCESSFUL";
    public static final String STATUS_CONNECT = "com.nimashahbazi.mooshak.MainActivity.Broadcast.STATUS_CONNECT";
    public static final String STATUS_DISCONNECT = "com.nimashahbazi.mooshak.MainActivity.Broadcast.STATUS_DISCONNECT";
    public static final String STATUS_AP_ON = "com.nimashahbazi.mooshak.MainActivity.Broadcast.STATUS_AP_ON";
    public static final String STATUS_AUTH_ERROR = "com.nimashahbazi.mooshak.MainActivity.Broadcast.STATUS_AUTH_ERROR";
    public static int IS_FIRST_STATUS = IS_FIRST;


}
