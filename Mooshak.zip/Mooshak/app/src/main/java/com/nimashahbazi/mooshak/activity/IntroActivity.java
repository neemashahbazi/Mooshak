package com.nimashahbazi.mooshak.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;

import com.github.paolorotolo.appintro.AppIntro;
import com.github.paolorotolo.appintro.AppIntroFragment;
import com.nimashahbazi.mooshak.R;

/**
 * Created by nimashahbazi on 12/3/17.
 */

public class IntroActivity extends AppIntro {
    SharedPreferences sharedPreferences;
    boolean firstTime;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        firstTime = sharedPreferences.getBoolean("isFirstTime", false);

        if (!firstTime) {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("isFirstTime", true);
            editor.commit();

            addSlide(AppIntroFragment.newInstance("ارسال و دریافت فایل", "fonts/iranyekanwebbold.ttf", "سهولت تبادل فایل میان کاربران بدون نیاز به وجود شبکه‌ی وای-فای از پیش موجود با سرعت و اطمینان بالا", "fonts/iranyekanwebbold.ttf", R.drawable.transfer, getResources().getColor(R.color.colorPrimary)));
            addSlide(AppIntroFragment.newInstance("قابلیت رمزنگاری فایل‌ها", "fonts/iranyekanwebbold.ttf", "تضمین امنیت اطلاعات ارسالی به واسطه رمزنگاری اطلاعات در فرستنده از طریق الگوریتم رمزنگاری پیشرفته با سایز کلید 256 بیتی و احراز هویت طرفین قبل از ارسال", "fonts/iranyekanwebbold.ttf", R.drawable.strongbox, getResources().getColor(R.color.color_20)));
            addSlide(AppIntroFragment.newInstance("مدیریت فایل جامع", "fonts/iranyekanwebbold.ttf", "سیستم مدیریت فایل کاربردی با قابلیت نمایش مجزای عکس، ویدیو، برنامه و موزیک در کنار دسترسی به تمامی حافظه", "fonts/iranyekanwebbold.ttf", R.drawable.file_manager, getResources().getColor(R.color.color_6)));

            showSkipButton(true);
            setProgressButtonEnabled(true);
            setSeparatorColor(getResources().getColor(R.color.color_1));

            setVibrate(true);
            setSkipText("پریدن");
            setSkipTextTypeface("fonts/iranyekanwebbold.ttf");
            setDoneText("شروع");
            setDoneTextTypeface("fonts/iranyekanwebbold.ttf");
            setVibrateIntensity(30);
        } else {
            Intent mainIntent = new Intent(IntroActivity.this, WelcomeActivity.class);
            IntroActivity.this.startActivity(mainIntent);
            IntroActivity.this.finish();
        }
    }

    @Override
    public void onSkipPressed(Fragment currentFragment) {
        super.onSkipPressed(currentFragment);
        Intent mainIntent = new Intent(IntroActivity.this, WelcomeActivity.class);
        IntroActivity.this.startActivity(mainIntent);
        IntroActivity.this.finish();
    }

    @Override
    public void onDonePressed(Fragment currentFragment) {
        super.onDonePressed(currentFragment);
        Intent mainIntent = new Intent(IntroActivity.this, WelcomeActivity.class);
        IntroActivity.this.startActivity(mainIntent);
        IntroActivity.this.finish();
    }

    @Override
    public void onSlideChanged(@Nullable Fragment oldFragment, @Nullable Fragment newFragment) {
        super.onSlideChanged(oldFragment, newFragment);
    }
}
