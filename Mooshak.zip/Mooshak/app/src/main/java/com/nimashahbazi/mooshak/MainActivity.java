package com.nimashahbazi.mooshak;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.net.wifi.ScanResult;
import android.net.wifi.SupplicantState;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.InputType;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.GravityEnum;
import com.afollestad.materialdialogs.MaterialDialog;
import com.afollestad.materialdialogs.Theme;
import com.afollestad.materialdialogs.internal.MDTintHelper;
import com.afollestad.materialdialogs.internal.ThemeSingleton;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;
import com.nimashahbazi.mooshak.activity.AboutActivity;
import com.nimashahbazi.mooshak.activity.HelpActivity;
import com.nimashahbazi.mooshak.activity.SettingActivity;
import com.nimashahbazi.mooshak.adapter.ClientAdapter;
import com.nimashahbazi.mooshak.adapter.CustomListviewAdapter;
import com.nimashahbazi.mooshak.adapter.DraftAdapter;
import com.nimashahbazi.mooshak.adapter.HistoryAdapter;
import com.nimashahbazi.mooshak.adapter.SimpleFragmentPagerAdapter;
import com.nimashahbazi.mooshak.base.BaseActivity;
import com.nimashahbazi.mooshak.base.BaseFragment;
import com.nimashahbazi.mooshak.conf.Constants;
import com.nimashahbazi.mooshak.control.ISendFiles;
import com.nimashahbazi.mooshak.control.TransferService;
import com.nimashahbazi.mooshak.database.History;
import com.nimashahbazi.mooshak.database.HistoryDatabase;
import com.nimashahbazi.mooshak.entity.HistoryItem;
import com.nimashahbazi.mooshak.entity.RowItem;
import com.nimashahbazi.mooshak.fragment.AppFragment;
import com.nimashahbazi.mooshak.fragment.FileFragment;
import com.nimashahbazi.mooshak.fragment.FragmentFactory;
import com.nimashahbazi.mooshak.fragment.MusicFragment;
import com.nimashahbazi.mooshak.fragment.PictureFragment;
import com.nimashahbazi.mooshak.fragment.ReceiveFragment;
import com.nimashahbazi.mooshak.fragment.VideoFragment;
import com.nimashahbazi.mooshak.net.WifiAdmin;
import com.nimashahbazi.mooshak.utils.CustomTypefaceSpan;
import com.nimashahbazi.mooshak.utils.FileUtils;
import com.nimashahbazi.mooshak.utils.HistoryUtils;
import com.nimashahbazi.mooshak.utils.LogUtils;
import com.nimashahbazi.mooshak.utils.RtlViewPager;
import com.nimashahbazi.mooshak.utils.TransferUtils;
import com.nimashahbazi.mooshak.utils.UIUtils;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.nimashahbazi.mooshak.utils.UIUtils.getContext;

public class MainActivity extends BaseActivity implements ISendFiles {
    Typeface iranYekanBold;
    TextView connectionStatusTitle;
    ImageView connectionStatusImage;
    TextView txtJoinNetwork;
    TextView txtCreateNormalNetwork;
    TextView txtCreateSecureNetwork;
    TextView txtDisconnectNetwork;
    RelativeLayout btnJoinNetwork;
    RelativeLayout btnCreateNormalNetwork;
    RelativeLayout btnCreateSecureNetwork;
    RelativeLayout btnDisconnectNetwork;
    RelativeLayout menuHolder;
    ClientAdapter clientAdapter;
    boolean isReturnedFromSetting = false;
    ImageView clientsStatus;
    private EditText passwordInput;
    private View positiveAction;
    private Toolbar mToolbar;
    private SimpleFragmentPagerAdapter mPagerAdapter;
    private RtlViewPager mViewPager;
    private TabLayout mTabLayout;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mDrawerToggle;
    private NavigationView mNavigationView;
    private TextView mUserName;
    private BaseFragment mFragmentSelected;
    private WifiAdmin mWifiAdmin;
    private WifiConfiguration mWifiConfiguration;
    private ServiceConnection mServiceConnection;
    private boolean isBound;
    private TransferReceiver mReceiver;
    private AlertDialog.Builder mSendDialog;
    private AlertDialog.Builder mReceiveDialog;
    private LinearLayout layoutSend;
    private LinearLayout layoutReceive;
    private ProgressBar pb;
    private TextView tx_rate;
    private AlertDialog alertDialog = null;
    private ArrayList SpeedList;
    private ArrayList<String> clientList;
    private CustomListviewAdapter customListviewAdapter;
    private HistoryDatabase database;
    private AHBottomNavigation bottomNavigation;
    private ImageView btnMooshakShow;
    private RelativeLayout btnMooshakHide;
    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            Bundle bl = msg.getData();
            switch (msg.what) {

                case 0x100: {
                    customListviewAdapter.notifyDataSetChanged();
                    break;
                }

                case 0x101: {
                    clientAdapter.notifyDataSetChanged();
                    break;
                }

                case 0x102: {
                    Log.d("Receive", "Start");

                    TextView title = new TextView(getContext());
                    title.setText("فرایند دریافت");
                    title.setGravity(Gravity.RIGHT);
                    title.setTypeface(iranYekanBold);
                    title.setTextColor(getResources().getColor(R.color.colorPrimary));
                    title.setTextSize(20);
                    title.setPadding(0, 10, 30, 0);
                    layoutReceive = (LinearLayout) MainActivity.this.getLayoutInflater().inflate(R.layout.dialog_receive, null);
                    pb = (ProgressBar) layoutReceive.findViewById(R.id.receive_progress);
                    tx_rate = (TextView) layoutReceive.findViewById(R.id.tv_rate);
                    pb.setProgress(0);
                    tx_rate.setText(getRateString(0) + "/s");
                    mReceiveDialog = new AlertDialog.Builder(new ContextThemeWrapper(MainActivity.this, R.style.AppCompatAlertDialogStyle));
                    mReceiveDialog.setCustomTitle(title);
                    mReceiveDialog.setView(layoutReceive);
                    TextView txv = (TextView) layoutReceive.findViewById(R.id.tx_receive_message);
                    txv.setText(bl.getString("file_name", "Receiving："));
                    TextView tx_number = (TextView) layoutReceive.findViewById(R.id.tx_receive_number);
                    tx_number.setText("دریافت فایل "+bl.getString("file_num","")+" از "+bl.getString("total_num",""));
                    tx_number.setTypeface(iranYekanBold);
                    mReceiveDialog.setPositiveButton("دریافت در زمینه", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    alertDialog = mReceiveDialog.create();
                    alertDialog.setCancelable(false);
                    alertDialog.show();
                    Button button1 = (Button) alertDialog.getWindow().findViewById(android.R.id.button1);
                    button1.setTypeface(iranYekanBold);
                    button1.setTextColor(getResources().getColor(R.color.colorPrimary));

                    break;
                }

                case 0x103: {
                    Log.d("Receive", "Progress");
                    pb.setProgress(bl.getInt("progress"));
                    tx_rate.setText(getRateString(bl.getLong("rate")) + "/s");

                    break;
                }

                case 0x104: {
                    Log.d("Receive", "End");
                    if (alertDialog != null) {
                        alertDialog.dismiss();
                        alertDialog = null;
                    }
                    Constants.IS_FIRST_STATUS = Constants.IS_FIRST;

                    break;
                }
                case 0x114: {
                    Log.d("Receive", "Unsuccessful");
                    if (alertDialog != null) {
                        alertDialog.dismiss();
                        alertDialog = null;
                    }
                    Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "دریافت فایل موفقیت‌آمیز نبود!", Snackbar.LENGTH_SHORT);
                    View sbView = snackbar.getView();
                    sbView.setBackgroundColor(Color.RED);
                    TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                    tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                    tv.setTypeface(iranYekanBold);
                    snackbar.show();
                    Constants.IS_FIRST_STATUS = Constants.IS_FIRST;
                    break;
                }
                case 0x116: {
                    MaterialDialog dialog =
                            new MaterialDialog.Builder(MainActivity.this).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf").theme(Theme.LIGHT)
                                    .title("آغاز دریافت فایل‌ها").titleGravity(GravityEnum.CENTER).titleColor(getResources().getColor(R.color.colorPrimary)).positiveColor(getResources().getColor(R.color.colorPrimary)).negativeColor(getResources().getColor(R.color.colorPrimary))
                                    .content("آیا مایل به آغاز دریافت فایل‌ها هستید؟").contentGravity(GravityEnum.CENTER).cancelable(false)
                                    .positiveText("بله")
                                    .negativeText("خیر")
                                    .onPositive(new MaterialDialog.SingleButtonCallback() {
                                        @Override
                                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                            Constants.IS_FIRST_STATUS = Constants.IS_NOT_FIRST;
                                        }
                                    }).onNegative(new MaterialDialog.SingleButtonCallback() {
                                @Override
                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                    Constants.IS_FIRST_STATUS = Constants.IS_CANCELED;
                                    dialog.cancel();

                                }
                            }).build();
                    dialog.show();

                    break;
                }
                case 0x117: {
                    goToReceivedFiles();
                    Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "دریافت فایل‌ها با موفقیت انجام شد! ", Snackbar.LENGTH_SHORT);
                    View sbView = snackbar.getView();
                    sbView.setBackgroundColor(Color.parseColor("#a4c639"));
                    TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                    tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                    tv.setTypeface(iranYekanBold);
                    snackbar.show();
                    break;
                }

                case 0x105: {
                    Log.d("Send", "Start");
                    TextView title = new TextView(getContext());
                    title.setText("فرایند ارسال");
                    title.setGravity(Gravity.RIGHT);
                    title.setTypeface(iranYekanBold);
                    title.setTextColor(getResources().getColor(R.color.colorPrimary));
                    title.setTextSize(20);
                    title.setPadding(0, 10, 30, 0);
                    layoutSend = (LinearLayout) MainActivity.this.getLayoutInflater().inflate(R.layout.send_file_progress_layout, null);
                    pb = (ProgressBar) layoutSend.findViewById(R.id.send_progress);
                    tx_rate = (TextView) layoutSend.findViewById(R.id.tv_rate);
                    pb.setProgress(0);
                    tx_rate.setText(getRateString(0) + "/s");
                    mSendDialog = new AlertDialog.Builder(new ContextThemeWrapper(MainActivity.this, R.style.AppCompatAlertDialogStyle));
                    mSendDialog.setCustomTitle(title);
                    mSendDialog.setView(layoutSend);
                    mSendDialog.setNegativeButton("لغو", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            mBinder.stopSend();
                        }
                    });
                    mSendDialog.setPositiveButton("ارسال در زمینه", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    alertDialog = mSendDialog.create();
                    alertDialog.setCancelable(false);
                    alertDialog.show();
                    Button button1 = (Button) alertDialog.getWindow().findViewById(android.R.id.button1);
                    Button button2 = (Button) alertDialog.getWindow().findViewById(android.R.id.button2);
                    button1.setTypeface(iranYekanBold);
                    button2.setTypeface(iranYekanBold);
                    button1.setTextColor(getResources().getColor(R.color.colorPrimary));
                    button2.setTextColor(getResources().getColor(R.color.colorPrimary));
                    break;
                }

                case 0x106: {
                    TextView txv = (TextView) layoutSend.findViewById(R.id.tx_send_message);
                    txv.setText(bl.getString("file_name"));
                    TextView tx_number = (TextView) layoutSend.findViewById(R.id.tx_send_number);
                    tx_number.setText("ارسال فایل "+bl.getString("file_num","")+" از "+bl.getString("total_num",""));
                    tx_number.setTypeface(iranYekanBold);
                    break;
                }

                case 0x107: {
                    Log.d("Send", "Progress");
                    int p = bl.getInt("progress");
                    pb.setProgress(p);
                    tx_rate.setText(getRateString(bl.getLong("rate")) + "/s");

                    if (bl.getLong("rate") != 0) {
                        SpeedList.add((bl.getLong("rate") / 1024));
                    }
                    break;
                }

                case 0x108: {
                    Log.d("Send", "End");

                    if (SpeedList.size() != 0) {
                        long Speed = 0;
                        long SpeedMax = (long) SpeedList.get(0);
                        long SpeedMin = (long) SpeedList.get(0);
                        for (int x = 0; x < SpeedList.size(); x++) {
                            Speed += (long) SpeedList.get(x);
                            if ((long) SpeedList.get(x) > SpeedMax) {
                                SpeedMax = (long) SpeedList.get(x);
                            }
                            if ((long) SpeedList.get(x) < SpeedMin) {
                                SpeedMin = (long) SpeedList.get(x);
                            }

                        }
                        Speed = Speed / SpeedList.size();
                        DecimalFormat df = new DecimalFormat("0.0");
                        LogUtils.s("###-------The actual throughput rate is：" + Speed + "KB/S" + "------The fastest transfer speed" + SpeedMax + "KB/S" + "------Slowest transfer speed" + SpeedMin + "KB/S");
                        LogUtils.s("###-------The actual throughput rate is：" + df.format((Speed / 1024.0)) + "MB/S" + "------The fastest transfer speed" + df.format((SpeedMax / 1024.0)) + "MB/S" + "------Slowest transfer speed" + df.format((SpeedMin / 1024.0)) + "MB/S");
                    } else {
                        LogUtils.s("#------No statistics");
                    }
                    if (alertDialog != null) {
                        alertDialog.dismiss();
                        alertDialog = null;
                    }
                    refreshFragments();
                    break;
                }

                case 0x115: {
                    Log.d("Send", "Unsuccessful");
                    if (alertDialog != null) {
                        alertDialog.dismiss();
                        alertDialog = null;
                    }
                    refreshFragments();
                    Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "ارسال فایل موفقیت‌آمیز نبود!", Snackbar.LENGTH_SHORT);
                    View sbView = snackbar.getView();
                    sbView.setBackgroundColor(Color.RED);
                    TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                    tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                    tv.setTypeface(iranYekanBold);
                    snackbar.show();

                    break;
                }

                case 0x109: {
                    mUserName.setText(mBinder.getHostName());
                    break;
                }

                case 0x110: {
                    Log.d("Status", "Connected to Hotspot!");
                    database.historyDao().addHistory(new History(R.mipmap.link, TransferUtils.restore(bl.getString("ssid")).substring(4), System.currentTimeMillis(), HistoryUtils.STATUS_CONNECTED_TO_NETWORK));
                    connectionStatusImage.setImageResource(R.drawable.wifi_on);
                    if (getCurrentNetworkCapabilities()) {
                        try {
                            connectionStatusTitle.setText("وضعیت اتصال: متصل به شبکه‌ی امن " + TransferUtils.restore(bl.getString("ssid")).substring(4));
                        } catch (Exception e) {
                        }

                    } else {
                        try {
                            connectionStatusTitle.setText("وضعیت اتصال: متصل به " + TransferUtils.restore(bl.getString("ssid")).substring(4));
                        } catch (Exception e) {
                        }
                    }
                    btnCreateNormalNetwork.setVisibility(View.GONE);
                    btnCreateSecureNetwork.setVisibility(View.GONE);
                    btnDisconnectNetwork.setVisibility(View.VISIBLE);
                    btnJoinNetwork.setVisibility(View.GONE);
                    break;
                }

                case 0x111: {

                    Log.d("Status", "No Connection!");

                    connectionStatusImage.setImageResource(R.drawable.wifi_off);
                    connectionStatusTitle.setText("وضعیت اتصال: اتصالی وجود ندارد.");
                    btnCreateNormalNetwork.setVisibility(View.VISIBLE);
                    if (android.os.Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                        btnCreateSecureNetwork.setVisibility(View.VISIBLE);
                    }
                    btnDisconnectNetwork.setVisibility(View.GONE);
                    btnJoinNetwork.setVisibility(View.VISIBLE);
                    clientsStatus.setVisibility(View.GONE);

                    break;

                }
                case 0x112: {
                    Log.d("Status", "Hotspot Created!");
                    if (!mWifiAdmin.isApEncrypted()) {
                        try {
                            connectionStatusImage.setImageResource(R.drawable.hotspot);
                            connectionStatusTitle.setText("وضعیت شبکه: " + TransferUtils.restore(bl.getString("ssid").substring(4)) + " برقرار است.");
                        } catch (Exception e) {

                        }

                    } else {
                        try {
                            connectionStatusImage.setImageResource(R.drawable.hotspot);
                            connectionStatusTitle.setText("وضعیت شبکه: " + TransferUtils.restore(bl.getString("ssid").substring(4)) + " در حالت امن برقرار است.");
                        } catch (Exception e) {
                        }

                    }
                    btnCreateNormalNetwork.setVisibility(View.GONE);
                    btnCreateSecureNetwork.setVisibility(View.GONE);
                    btnDisconnectNetwork.setVisibility(View.VISIBLE);
                    btnJoinNetwork.setVisibility(View.GONE);
                    clientsStatus.setVisibility(View.VISIBLE);

                    break;
                }

                case 0x113: {
                    Log.d("Status", "Wrong Password!");
                    connectionStatusImage.setImageResource(R.drawable.wifi_off);
                    connectionStatusTitle.setText("وضعیت اتصال: خطا در تصدیق رمز عبور. مجددا تلاش کنید!");
                    break;
                }
            }
        }
    };


    private void applyFontToMenuItem(MenuItem mi) {
        Typeface font = Typeface.createFromAsset(getAssets(), "fonts/iranyekanwebbold.ttf");
        SpannableString mNewTitle = new SpannableString(mi.getTitle());
        mNewTitle.setSpan(new CustomTypefaceSpan("", font), 0, mNewTitle.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
        mi.setTitle(mNewTitle);
    }


    @Override
    protected void initView() {
        setContentView(R.layout.activity_main);
        iranYekanBold = Typeface.createFromAsset(getAssets(), "fonts/iranyekanwebbold.ttf");

        clientsStatus = (ImageView) findViewById(R.id.status_clients);

        btnMooshakShow = (ImageView) findViewById(R.id.btn_mooshak);
        btnMooshakHide = (RelativeLayout) findViewById(R.id.hide_menu);

        ViewCompat.setElevation(btnMooshakShow, 100);

        txtCreateNormalNetwork = (TextView) findViewById(R.id.create_normal_network_text);
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            txtCreateNormalNetwork.setText("ایجاد شبکه");
        }

        txtCreateSecureNetwork = (TextView) findViewById(R.id.create_secure_network_text);
        txtDisconnectNetwork = (TextView) findViewById(R.id.disconnect_network_text);

        txtJoinNetwork = (TextView) findViewById(R.id.join_network_text);
        txtJoinNetwork.setTypeface(iranYekanBold);
        txtCreateSecureNetwork.setTypeface(iranYekanBold);
        txtCreateNormalNetwork.setTypeface(iranYekanBold);
        txtDisconnectNetwork.setTypeface(iranYekanBold);

        btnCreateNormalNetwork = (RelativeLayout) findViewById(R.id.create_normal_network);
        btnCreateSecureNetwork = (RelativeLayout) findViewById(R.id.create_secure_network);
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            btnCreateSecureNetwork.setVisibility(View.GONE);
        }

        btnDisconnectNetwork = (RelativeLayout) findViewById(R.id.disconnect_network);
        btnJoinNetwork = (RelativeLayout) findViewById(R.id.join_network);
        menuHolder = (RelativeLayout) findViewById(R.id.menu_holder);
        btnMooshakShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fadeIn();
            }
        });

        btnMooshakHide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fadeOut();

            }
        });

        connectionStatusTitle = (TextView) findViewById(R.id.status_title);
        connectionStatusImage = (ImageView) findViewById(R.id.status_image);
        connectionStatusTitle.setTypeface(iranYekanBold);

        bottomNavigation = (AHBottomNavigation) findViewById(R.id.bottom_navigation);

        AHBottomNavigationItem item1 = new AHBottomNavigationItem("پیش‌نویس", R.drawable.draft, R.color.color_tab_2);
        AHBottomNavigationItem item2 = new AHBottomNavigationItem("موشک", R.drawable.rocket, R.color.color_tab_3);
        AHBottomNavigationItem item3 = new AHBottomNavigationItem("تاریخچه", R.drawable.history, R.color.color_tab_3);

        bottomNavigation.addItem(item1);
        bottomNavigation.addItem(item2);
        bottomNavigation.addItem(item3);
        updateBadge();
        bottomNavigation.setBehaviorTranslationEnabled(false);
        bottomNavigation.setAccentColor(R.color.colorPrimary);
        bottomNavigation.setAccentColor(Color.parseColor("#747474"));
        bottomNavigation.setTitleState(AHBottomNavigation.TitleState.ALWAYS_SHOW);
        bottomNavigation.setTitleTypeface(iranYekanBold);
        bottomNavigation.setTitleTextSizeInSp(12, 12);
        bottomNavigation.setOnTabSelectedListener(new AHBottomNavigation.OnTabSelectedListener() {
            @Override
            public boolean onTabSelected(int position, boolean wasSelected) {
                if (position == 0) {

                    RelativeLayout layout = (RelativeLayout) getLayoutInflater().inflate(R.layout.dialog_draft, null);
                    final ListView listView = (ListView) layout.findViewById(R.id.list_draft);
                    final ArrayList<RowItem> draftArrayList = new ArrayList<RowItem>();
                    draftArrayList.clear();
                    for (int i = 0; i < UIUtils.fileList.size(); i++) {
                        draftArrayList.add(new RowItem(UIUtils.fileList.get(i), FileUtils.Icons[FileUtils.getIcons(new File(UIUtils.fileList.get(i)))]));
                    }
                    final DraftAdapter draftAdapter = new DraftAdapter(getContext(), R.layout.dialog_draft, draftArrayList);
                    listView.setAdapter(draftAdapter);
                    AlertDialog.Builder dialog = new AlertDialog.Builder(new ContextThemeWrapper(MainActivity.this, R.style.AppCompatAlertDialogStyle));
                    dialog.setView(layout);
                    dialog.setPositiveButton("لغو", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    TextView title = (TextView) layout.findViewById(R.id.dialog_draft_title);
                    TextView empty = (TextView) layout.findViewById(R.id.empty_list_item);
                    listView.setEmptyView(empty);
                    empty.setTypeface(iranYekanBold);
                    Button removeBtn = (Button) layout.findViewById(R.id.btn_remove_all);
                    title.setTypeface(iranYekanBold);
                    removeBtn.setTypeface(iranYekanBold);
                    final AlertDialog alertDialog = dialog.create();
                    alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
                        @Override
                        public void onShow(DialogInterface dialog) {
                            ((Button) alertDialog.getButton(Dialog.BUTTON_POSITIVE)).setTypeface(iranYekanBold, Typeface.NORMAL);

                        }
                    });
                    alertDialog.setCanceledOnTouchOutside(false);
                    alertDialog.show();
                    alertDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            refreshFragments();
                        }
                    });
                    removeBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            UIUtils.fileList.removeAll(UIUtils.fileList);
                            draftArrayList.removeAll(draftArrayList);
                            draftAdapter.notifyDataSetChanged();
                            updateBadge();
                        }
                    });

                } else if (position == 1) {
                    if (menuHolder.getVisibility() == View.GONE)
                        fadeIn();
                    else if (menuHolder.getVisibility() == View.VISIBLE)
                        fadeOut();
                } else if (position == 2) {
                    RelativeLayout layout = (RelativeLayout) getLayoutInflater().inflate(R.layout.dialog_history, null);
                    final ListView listView = (ListView) layout.findViewById(R.id.list_history);
                    final ArrayList<HistoryItem> historyList = new ArrayList<HistoryItem>();
                    List<History> histories = database.historyDao().getAllHistory();
                    for (int i = 0; i < histories.size(); i++) {
                        historyList.add(new HistoryItem(histories.get(i).getImageId(), histories.get(i).getTitle(), histories.get(i).getTimestamp(), histories.get(i).getStatus()));
                    }
                    final HistoryAdapter historyAdapter = new HistoryAdapter(getContext(), R.layout.history_item, historyList);
                    listView.setAdapter(historyAdapter);
                    final AlertDialog.Builder dialog = new AlertDialog.Builder(new ContextThemeWrapper(MainActivity.this, R.style.AppCompatAlertDialogStyle));
                    dialog.setView(layout);
                    dialog.setPositiveButton("لغو", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    TextView title = (TextView) layout.findViewById(R.id.dialog_history_title);
                    TextView empty = (TextView) layout.findViewById(R.id.empty_list_item);
                    listView.setEmptyView(empty);
                    empty.setTypeface(iranYekanBold);
                    Button removeBtn = (Button) layout.findViewById(R.id.btn_remove_all);
                    title.setTypeface(iranYekanBold);
                    removeBtn.setTypeface(iranYekanBold);
                    final AlertDialog alertDialog = dialog.create();
                    alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
                        @Override
                        public void onShow(DialogInterface dialog) {
                            ((Button) alertDialog.getButton(Dialog.BUTTON_POSITIVE)).setTypeface(iranYekanBold, Typeface.NORMAL);

                        }
                    });
                    alertDialog.setCanceledOnTouchOutside(false);
                    alertDialog.show();

                    removeBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            historyList.removeAll(historyList);
                            database.historyDao().removeAllHistory();
                            historyAdapter.notifyDataSetChanged();
                            updateBadge();
                        }
                    });
                }

                return true;
            }
        });

        mPagerAdapter = new SimpleFragmentPagerAdapter(getSupportFragmentManager(), this);

        mViewPager = (RtlViewPager) findViewById(R.id.viewpager);
        mViewPager.setAdapter(mPagerAdapter);

        mTabLayout = (TabLayout) findViewById(R.id.tabLayout);
        mTabLayout.setupWithViewPager(mViewPager);
        mTabLayout.setTabMode(TabLayout.MODE_SCROLLABLE);
        for (int i = 0; i < mTabLayout.getTabCount(); i++) {
            //noinspection ConstantConditions
            TextView tv = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
            tv.setTypeface(iranYekanBold);
            mTabLayout.getTabAt(i).setCustomView(tv);
        }

        mNavigationView = (NavigationView) findViewById(R.id.navigation_view);
        View headerLayout = mNavigationView.getHeaderView(0);

        Menu m = mNavigationView.getMenu();
        for (int i = 0; i < m.size(); i++) {
            MenuItem mi = m.getItem(i);
            SubMenu subMenu = mi.getSubMenu();
            if (subMenu != null && subMenu.size() > 0) {
                for (int j = 0; j < subMenu.size(); j++) {
                    MenuItem subMenuItem = subMenu.getItem(j);
                    applyFontToMenuItem(subMenuItem);
                }
            }
            applyFontToMenuItem(mi);
        }
        mUserName = (TextView) headerLayout.findViewById(R.id.user_name);
        clientsStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getClientList();
            }
        });
    }

    @Override
    protected void initActionBar() {
        super.initActionBar();

        mToolbar = (Toolbar) findViewById(R.id.toolBar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        TextView mTitle = (TextView) mToolbar.findViewById(R.id.toolbar_title);
        mTitle.setTypeface(iranYekanBold);

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar,
                R.string.drawer_open, R.string.drawer_close);
        mDrawerToggle.syncState();
        mDrawerLayout.setDrawerListener(mDrawerToggle);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_send:
                return false;

            case R.id.action_secure:
                return false;

            default:
                break;
        }

        return false;
    }


    @Override
    protected void initData() {

        super.initData();

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        database = HistoryDatabase.getDatabase(getApplicationContext());

        mWifiAdmin = new WifiAdmin(getContext());

        SpeedList = new ArrayList<Long>();

        clientList = new ArrayList<String>();


        isBound = false;

        mServiceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                mBinder = (TransferService.ServerBinder) service;
                isBound = true;
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                isBound = false;
            }
        };

        mReceiver = new TransferReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Constants.FILE_RECEIVE);
        intentFilter.addAction(Constants.FILE_RECEIVE_FIRST_START);
        intentFilter.addAction(Constants.FILE_RECEIVE_LAST_END);
        intentFilter.addAction(Constants.FILE_RECEIVE_PEOGRESS);
        intentFilter.addAction(Constants.FILE_RECEIVE_END);
        intentFilter.addAction(Constants.FILE_RECEIVE_UNSUCCESSFUL);
        intentFilter.addAction(Constants.FILE_SEND);
        intentFilter.addAction(Constants.FILE_SEND_NAME);
        intentFilter.addAction(Constants.FILE_SEND_PEOGRESS);
        intentFilter.addAction(Constants.FILE_SEND_END);
        intentFilter.addAction(Constants.FILE_SEND_UNSUCCESSFUL);
        intentFilter.addAction(Constants.CHANGE_HOST_NAME);
        intentFilter.addAction(Constants.STATUS_CONNECT);
        intentFilter.addAction(Constants.STATUS_DISCONNECT);
        intentFilter.addAction(Constants.STATUS_AP_ON);
        intentFilter.addAction(Constants.STATUS_AUTH_ERROR);
        registerReceiver(mReceiver, intentFilter);

        Intent intent = new Intent(this, TransferService.class);
        bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);
        isBound = true;
        connectionStatusOnStart();
    }

    @Override
    public void onDestroy() {
        if (isBound) {
            unbindService(mServiceConnection);
        }
        unregisterReceiver(mReceiver);
        super.onDestroy();
    }

    @Override
    protected void initListener() {
        super.initListener();

        btnJoinNetwork.setOnClickListener(new MainClickEvent());
        btnCreateSecureNetwork.setOnClickListener(new MainClickEvent());
        btnCreateNormalNetwork.setOnClickListener(new MainClickEvent());
        btnDisconnectNetwork.setOnClickListener(new MainClickEvent());


        mNavigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                Intent intent;
                switch (menuItem.getItemId()) {
                    case R.id.navigation_item_help:
                        intent = new Intent(getContext(), HelpActivity.class);
                        startActivity(intent);
                        break;
                    case R.id.navigation_item_info:
                        intent = new Intent(getContext(), AboutActivity.class);
                        startActivity(intent);
                        break;
                    case R.id.navigation_item_setting:
                        intent = new Intent(getContext(), SettingActivity.class);
                        startActivity(intent);
                        break;
                    case R.id.navigation_item_share:
                        try {
                            PackageManager pm = getPackageManager();
                            ApplicationInfo ai = pm.getApplicationInfo(getPackageName(), 0);
                            File srcFile = new File(ai.publicSourceDir);
                            Intent share = new Intent();
                            share.setAction(Intent.ACTION_SEND);
                            share.setType("application/vnd.android.package-archive");
                            share.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(srcFile));
                            startActivity(Intent.createChooser(share, "Share Mooshak via..."));
                        } catch (Exception e) {
                            Log.e("Mooshak", e.getMessage());
                        }
                        break;
                }

                mDrawerLayout.closeDrawers();
                return true;
            }
        });

        mFragmentSelected = (BaseFragment) mPagerAdapter.getItem(0);

        mTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                mViewPager.setCurrentItem(tab.getPosition());
                mFragmentSelected = (BaseFragment) mPagerAdapter.getItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    @Override
    protected void initFragment() {
        super.initFragment();
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {

        if (menuHolder.getVisibility() == View.VISIBLE) {
            fadeOut();
            return false;
        } else if (mFragmentSelected instanceof FileFragment) {
            if (FileFragment.onKeyUp(keyCode, event)) {
                return super.onKeyUp(keyCode, event);
            } else {
                return false;
            }
        } else if (mFragmentSelected instanceof AppFragment) {
            if (AppFragment.onKeyUp(keyCode, event)) {
                return super.onKeyUp(keyCode, event);
            } else {
                return false;
            }
        } else if (mFragmentSelected instanceof MusicFragment) {
            if (MusicFragment.onKeyUp(keyCode, event)) {
                return super.onKeyUp(keyCode, event);
            } else {
                return false;
            }
        } else if (mFragmentSelected instanceof PictureFragment) {
            if (PictureFragment.onKeyUp(keyCode, event)) {
                return super.onKeyUp(keyCode, event);
            } else {
                return false;
            }
        } else if (mFragmentSelected instanceof VideoFragment) {
            if (PictureFragment.onKeyUp(keyCode, event)) {
                return super.onKeyUp(keyCode, event);
            } else {
                return false;
            }
        } else if (mFragmentSelected instanceof ReceiveFragment) {
            if (ReceiveFragment.onKeyUp(keyCode, event)) {
                return super.onKeyUp(keyCode, event);
            } else {
                return false;
            }
        } else {
            return super.onKeyUp(keyCode, event);
        }
    }

    @Override
    public void sendFileList(final ArrayList<String> fileList) {

        final MaterialDialog pd = new MaterialDialog.Builder(this).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf").titleGravity(GravityEnum.CENTER).theme(Theme.LIGHT).titleColor(getResources().getColor(R.color.colorPrimary))
                .title("جستجو برای دریافت کننده‌ها")
                .content("لطفا منتظر بمانید...")
                .progress(true, 0).cancelable(false)
                .show();

        new Thread(new Runnable() {
            @Override
            public void run() {
                scanClients();
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        pd.dismiss();
                        Log.d("Client List Size", clientList.size() + "");
                        if (clientList.size() == 0) {
                            Snackbar snackbar = Snackbar.make(MainActivity.this.findViewById(android.R.id.content), "دریافت کننده‌ای یافت نشد!", Snackbar.LENGTH_SHORT);
                            View sbView = snackbar.getView();
                            sbView.setBackgroundColor(Color.RED);
                            TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                            tv.setTypeface(iranYekanBold);
                            snackbar.show();

                        } else if (clientList.size() == 1) {
                            int port = Constants.PORT;
                            mBinder.sendFileList(clientList.get(0), port, fileList);

                        } else {

                            RelativeLayout layout = (RelativeLayout) MainActivity.this.getLayoutInflater().inflate(R.layout.send_choose_dialog_layout, null);
                            ListView listView = (ListView) layout.findViewById(R.id.list_host_choose);
                            final ArrayList<RowItem> ip_s = new ArrayList<RowItem>();
                            final HashMap<String, String> map = new HashMap<>();

                            map.clear();
                            ip_s.clear();
                            ip_s.add(new RowItem("ارسال به آی پی", R.drawable.devices));

                            customListviewAdapter = new CustomListviewAdapter(MainActivity.this, R.layout.host_list_item, ip_s);
                            listView.setAdapter(customListviewAdapter);
                            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    RelativeLayout hostListItem = (RelativeLayout) view;
                                    TextView hostTitle = (TextView) hostListItem.findViewById(R.id.title);
                                    String name = hostTitle.getText().toString();
                                    String ip = map.get(name);
                                    if (ip == null && name.equals("ارسال به آی پی")) {
                                        sendFileByIp(fileList);
                                    } else {
                                        int port = Constants.PORT;
                                        if (mBinder == null) {
                                        }
                                        mBinder.sendFileList(ip, port, fileList);
                                    }
                                    if (alertDialog != null) {
                                        alertDialog.dismiss();
                                        alertDialog = null;
                                    }
                                }
                            });

                            final ProgressBar progressBar = (ProgressBar) layout.findViewById(R.id.loading_clients);
                            final Button refresh = (Button) layout.findViewById(R.id.btn_refresh);
                            refresh.setVisibility(View.INVISIBLE);
                            progressBar.setVisibility(View.VISIBLE);
                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    scanIP(map, ip_s);
                                    try {
                                        Thread.sleep(5000);
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            progressBar.setVisibility(View.GONE);
                                            refresh.setVisibility(View.VISIBLE);
                                        }
                                    });
                                }
                            }).start();

                            showChooseDialog(layout, "انتخاب دریافت کننده");

                            refresh.setTypeface(iranYekanBold);
                            refresh.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (alertDialog != null) {
                                        alertDialog.dismiss();
                                        alertDialog = null;
                                    }
                                    sendFileList(fileList);
                                }
                            });
                        }
                    }
                });
            }
        }).start();

    }

    public void getClientList() {
        RelativeLayout layout = (RelativeLayout) getLayoutInflater().inflate(R.layout.dialog_clients, null);
        ListView listView = (ListView) layout.findViewById(R.id.list_client);

        final ArrayList<String> ip_s = new ArrayList<String>();
        ip_s.clear();

        clientAdapter = new ClientAdapter(getContext(), R.layout.history_item, ip_s);
        listView.setAdapter(clientAdapter);


        final ProgressBar progressBar = (ProgressBar) layout.findViewById(R.id.loading_clients);
        progressBar.setVisibility(View.VISIBLE);
        new Thread(new Runnable() {
            @Override
            public void run() {
                scanClients(ip_s);
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.setVisibility(View.GONE);
                    }
                });
            }
        }).start();


        final AlertDialog.Builder dialog = new AlertDialog.Builder(new ContextThemeWrapper(MainActivity.this, R.style.AppCompatAlertDialogStyle));
        dialog.setView(layout);
        TextView title = (TextView) layout.findViewById(R.id.dialog_client_title);
        TextView empty = (TextView) layout.findViewById(R.id.empty_list_item);
        listView.setEmptyView(empty);
        empty.setTypeface(iranYekanBold);
        title.setTypeface(iranYekanBold);
        dialog.setPositiveButton("لغو", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        final AlertDialog alertDialog = dialog.create();
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                ((Button) alertDialog.getButton(Dialog.BUTTON_POSITIVE)).setTypeface(iranYekanBold, Typeface.NORMAL);

            }
        });
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.show();
    }


    private void scanIP(final HashMap<String, String> map, final ArrayList<RowItem> ip_s) {

        final String address = getCurrIP();
        final String ip_top = address.substring(0, address.lastIndexOf('.'));
        for (int i = 1; i < 255; i += 16) {
            final int w = i;
            new Thread() {
                @Override
                public void run() {
                    try {
                        int len = 0;
                        byte[] data = new byte[8192];
                        for (int i = w; i < w + 16; i++) {

                            try {
                                String s = ip_top + "." + i;

                                if (s.equals(address)) continue;

                                Socket sc = new Socket();
                                sc.connect(new InetSocketAddress(s, Constants.PORT), 250);
                                DataInputStream dis = new DataInputStream(new BufferedInputStream(sc.getInputStream()));
                                String hostName = s;
                                if ((len = dis.read(data)) != -1) {
                                    hostName = new String(data, 0, len, "UTF-8");
                                }
                                sc.close();
                                sendMsg(map, ip_s, hostName, s);

                            } catch (IOException e) {
                                // TODO Auto-generated catch block
                            }
                        }

                    } catch (Exception e) {
                    }
                }
            }.start();
        }
    }

    private void scanClients(final ArrayList<String> ip_s) {
        final String address = getCurrIP();
        final String ip_top = address.substring(0, address.lastIndexOf('.'));
        for (int i = 1; i < 255; i += 16) {
            final int w = i;
            new Thread() {
                @Override
                public void run() {
                    try {
                        int len = 0;
                        byte[] data = new byte[8192];
                        for (int i = w; i < w + 16; i++) {

                            try {
                                String s = ip_top + "." + i;

                                if (s.equals(address)) continue;

                                Socket sc = new Socket();
                                sc.connect(new InetSocketAddress(s, Constants.PORT), 250);
                                DataInputStream dis = new DataInputStream(new BufferedInputStream(sc.getInputStream()));
                                String hostName = s;
                                if ((len = dis.read(data)) != -1) {
                                    hostName = new String(data, 0, len, "UTF-8");
                                }
                                sc.close();
                                sendMsg_(ip_s, hostName, s);

                            } catch (IOException e) {
                                // TODO Auto-generated catch block
                            }
                        }

                    } catch (Exception e) {
                    }
                }
            }.start();
        }
    }

    private void scanClients() {
        clientList.clear();
        final String address = getCurrIP();
        final String ip_top = address.substring(0, address.lastIndexOf('.'));
        for (int i = 1; i < 255; i += 16) {
            final int w = i;
            new Thread() {
                @Override
                public void run() {
                    try {
                        int len = 0;
                        byte[] data = new byte[8192];
                        for (int i = w; i < w + 16; i++) {

                            try {
                                String s = ip_top + "." + i;

                                if (s.equals(address)) continue;

                                Socket sc = new Socket();
                                sc.connect(new InetSocketAddress(s, Constants.PORT), 250);
                                DataInputStream dis = new DataInputStream(new BufferedInputStream(sc.getInputStream()));
                                String hostName = s;
                                if ((len = dis.read(data)) != -1) {
                                    hostName = new String(data, 0, len, "UTF-8");
                                }
                                sc.close();
                                clientList.add(s);

                            } catch (IOException e) {
                                // TODO Auto-generated catch block
                            }
                        }

                    } catch (Exception e) {
                    }
                }
            }.start();
        }
    }

    private void showChooseDialog(RelativeLayout layout, String title) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AppCompatAlertDialogStyle));
        dialog.setView(layout);
        dialog.setPositiveButton("لغو", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        TextView tvTitle = layout.findViewById(R.id.dialog_title);
        tvTitle.setText(title);
        tvTitle.setTypeface(iranYekanBold);
        alertDialog = dialog.create();
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                ((Button) alertDialog.getButton(Dialog.BUTTON_POSITIVE)).setTypeface(iranYekanBold, Typeface.NORMAL);
            }
        });
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.show();
    }

    private String getCurrIP() {
        String ip = "0.0.0.0";

        WifiManager wifiManager = (WifiManager) this.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wifiManager.isWifiEnabled()) {
            ip = TransferUtils.initToIp(wifiManager.getConnectionInfo().getIpAddress());
        } else {
            try {
                Method method = wifiManager.getClass().getMethod("isWifiApEnabled");
                if ((Boolean) method.invoke(wifiManager)) {

                    BufferedReader br = new BufferedReader(new FileReader("/proc/net/arp"));
                    String line = br.readLine();
                    while ((line = br.readLine()) != null) {
                        String[] spilt = line.split(" +");
                        if (spilt != null) {
                            ip = spilt[0].substring(0, spilt[0].lastIndexOf('.')) + "." + 1;
                            break;
                        }
                    }
                    br.close();
                }
            } catch (Exception e) {
            }
        }

        return ip;
    }

    private synchronized void sendMsg(HashMap<String, String> map, ArrayList<RowItem> list, String hostName, String s) throws Exception {

        Message msg = new Message();
        msg.what = 0x100;
        map.put(hostName, s);
        list.add(0, new RowItem(hostName, R.drawable.profile_pic));
        mHandler.sendMessage(msg);
        Thread.sleep(1000);

    }


    private synchronized void sendMsg_(ArrayList<String> list, String hostName, String s) throws Exception {

        Message msg = new Message();
        msg.what = 0x101;
        list.add(0, hostName);
        mHandler.sendMessage(msg);
        Thread.sleep(1000);

    }

    private void sendFileByIp(final ArrayList<String> file_paths) {

        RelativeLayout layout = (RelativeLayout) this.getLayoutInflater().inflate(R.layout.send_file_dialog_layout, null);
        final EditText ed_ip = (EditText) layout.findViewById(R.id.edt_ip);
        ed_ip.setTextColor(getResources().getColor(R.color.text_color));
        WifiManager wifiManager = (WifiManager) this.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wifiManager.isWifiEnabled()) {
            String address = TransferUtils.initToIp(wifiManager.getConnectionInfo().getIpAddress());
            ed_ip.setText(address);
        }

        AlertDialog.Builder dialog = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AppCompatAlertDialogStyle));

        TextView tvTitle = new TextView(getContext());
        tvTitle.setText("لطفا آی‌پی دریافت کننده را وارد کنید...");
        tvTitle.setGravity(Gravity.RIGHT);
        tvTitle.setTypeface(iranYekanBold);
        tvTitle.setTextColor(getResources().getColor(R.color.colorPrimary));
        tvTitle.setTextSize(20);
        tvTitle.setPadding(0, 10, 30, 0);
        dialog.setCustomTitle(tvTitle);
        dialog.setView(layout);

        dialog.setNegativeButton("لغو", null);
        dialog.setPositiveButton("ارسال", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String ip = ed_ip.getText().toString();
                mBinder.sendFileList(ip, Constants.PORT, file_paths);
            }
        });
        AlertDialog d = dialog.create();
        d.setCanceledOnTouchOutside(false);
        d.show();

        Button button1 = (Button) d.getWindow().findViewById(android.R.id.button1);
        Button button2 = (Button) d.getWindow().findViewById(android.R.id.button2);
        button1.setTypeface(iranYekanBold);
        button2.setTypeface(iranYekanBold);
        button1.setTextColor(getResources().getColor(R.color.colorPrimary));
        button2.setTextColor(getResources().getColor(R.color.colorPrimary));
    }

    protected String getRateString(long length) {
        // TODO Auto-generated method stub
        DecimalFormat df = new DecimalFormat("0.0");
        double tem = length;
        tem /= 1024.0;
        if (1024.0 - tem > 0.0000000001) {
            return df.format(tem) + "KB";
        }
        tem /= 1024.0;
        if (1024.0 - tem > 0.0000000001) {
            return df.format(tem) + "MB";
        }
        tem /= 1024.0;
        return df.format(tem) + "GB";

    }

    private void scanWifi(final HashMap<String, HashMap<String, String>> wifiMap, final ArrayList<RowItem> wifiList) {
        new Thread() {
            @Override
            public void run() {
                super.run();
                if (!mWifiAdmin.isWifiOpen()) {
                    mWifiAdmin.openWifi();
                    try {
                        Thread.sleep(2000);
                    } catch (Exception e) {
                    }
                }
                mWifiAdmin.ScanWifiAp();
                try {
                    Thread.sleep(3000);
                } catch (Exception e) {
                }
                List<ScanResult> list = mWifiAdmin.getWifiScanList();
                wifiList.clear();
                wifiMap.clear();
                for (ScanResult sr : list) {
                    int level = sr.level;
                    String isSecure = "FALSE";
                    String Capabilities = sr.capabilities;
                    String ssid = sr.SSID;
                    String origin = TransferUtils.restore(ssid);
                    if (origin.startsWith(Constants.WIFI_AP_NAME)) {
                        String name = origin.substring(Constants.WIFI_AP_NAME.length());
                        if (Capabilities.contains("WPA2") || Capabilities.contains("WPA") || Capabilities.contains("WEP")) {
                            wifiList.add(new RowItem(name, R.drawable.wifi_lock));
                            isSecure = "TRUE";
                        } else {
                            wifiList.add(new RowItem(name, R.drawable.wifi));
                        }
                        HashMap<String, String> value = new HashMap<String, String>();

                        value.put("ssid", ssid);
                        value.put("isSecure", isSecure);
                        value.put("level", Integer.toString(level));
                        wifiMap.put(name, value);
                    } else {
                    }
                }
                if (wifiList.size() == 0) {
                    wifiList.clear();
                    wifiList.add(new RowItem("جستجوی مجدد...", R.drawable.refresh));

                }
                Message msg = new Message();
                msg.what = 0x100;
                mHandler.sendMessage(msg);
            }
        }.start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        connectionStatusOnStart();
        if (isReturnedFromSetting) {
            isReturnedFromSetting = false;
            if (mWifiAdmin.isWifiApOpen()) {
                Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "شبکه با موفقیت ایجاد شد!\n" + " لطفا به دستگاه " + android.os.Build.MODEL + " متصل شوید.", Snackbar.LENGTH_LONG);
                View sbView = snackbar.getView();
                sbView.setBackgroundColor(Color.parseColor("#a4c639"));
                TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");
                tv.setTypeface(iranYekanBold);
                snackbar.show();
                database.historyDao().addHistory(new History(R.mipmap.wireless, android.os.Build.MODEL, System.currentTimeMillis(), HistoryUtils.STATUS_CREATE_NETWORK));

                Log.d("CONFIG", mWifiAdmin.getWifiApConfiguration().toString());


            } else {
                Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "در حال حاضر امکان ایجاد هات اسپات وجود ندارد!", Snackbar.LENGTH_LONG).setAction("تنظیمات", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mWifiAdmin.gotoHotspotSettings();
                    }
                });
                View sbView = snackbar.getView();
                sbView.setBackgroundColor(Color.RED);
                TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                Typeface iranYekanBold = Typeface.createFromAsset(UIUtils.getContext().getAssets(), "fonts/iranyekanwebbold.ttf");
                tv.setTypeface(iranYekanBold);
                TextView btn = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_action);
                btn.setTypeface(iranYekanBold);
                btn.setTextColor(Color.parseColor("#f8a0a0"));
                btn.setTextSize(14);
                snackbar.show();
            }
        }
    }

    public void updateBadge() {
        bottomNavigation.setNotification(UIUtils.fileList.size() + "", 0);
    }

    public void connectionStatusOnStart() {
        if (connectionStatusTitle.getText().equals("")) {
            btnCreateNormalNetwork.setVisibility(View.VISIBLE);
            if (android.os.Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                btnCreateSecureNetwork.setVisibility(View.VISIBLE);
            }
            btnDisconnectNetwork.setVisibility(View.GONE);
            btnJoinNetwork.setVisibility(View.VISIBLE);

            connectionStatusImage.setImageResource(R.drawable.wifi_off);
            connectionStatusTitle.setText("وضعیت اتصال: اتصالی وجود ندارد.");

            if (mWifiAdmin.isWifiApOpen()) {

                btnCreateNormalNetwork.setVisibility(View.GONE);
                btnCreateSecureNetwork.setVisibility(View.GONE);
                btnDisconnectNetwork.setVisibility(View.VISIBLE);
                btnJoinNetwork.setVisibility(View.GONE);

                clientsStatus.setVisibility(View.VISIBLE);

                String origin = TransferUtils.restore(mWifiAdmin.getApSSID());

                if (!mWifiAdmin.isApEncrypted()) {
                    try {
                        connectionStatusImage.setImageResource(R.drawable.hotspot);
                        connectionStatusTitle.setText("وضعیت شبکه: " + origin.substring(4) + " برقرار است.");
                    } catch (Exception e) {
                        clientsStatus.setVisibility(View.GONE);
                    }

                } else {

                    try {
                        connectionStatusImage.setImageResource(R.drawable.hotspot);
                        connectionStatusTitle.setText("وضعیت شبکه: " + origin.substring(4) + " در حالت امن برقرار است.");
                    } catch (Exception e) {
                        clientsStatus.setVisibility(View.GONE);
                    }
                }

            } else {
                SupplicantState supState;
                WifiManager wifiManager = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                WifiInfo wifiInfo = null;
                if (wifiManager != null) {
                    wifiInfo = wifiManager.getConnectionInfo();
                }

                supState = wifiInfo.getSupplicantState();
                String ssid = wifiInfo.getSSID();

                if (supState.equals(SupplicantState.COMPLETED)) {
                    String origin = TransferUtils.restore(ssid.substring(1, ssid.length() - 1));
                    if (origin.startsWith(Constants.WIFI_AP_NAME)) {
                        btnCreateNormalNetwork.setVisibility(View.GONE);
                        btnCreateSecureNetwork.setVisibility(View.GONE);
                        btnDisconnectNetwork.setVisibility(View.VISIBLE);
                        btnJoinNetwork.setVisibility(View.GONE);
                        connectionStatusImage.setImageResource(R.drawable.wifi_on);
                        if (getCurrentNetworkCapabilities()) {
                            try {
                                connectionStatusTitle.setText("وضعیت اتصال: متصل به شبکه‌ی امن " + origin.substring(4));
                            } catch (Exception e) {
                            }

                        } else {
                            try {
                                connectionStatusTitle.setText("وضعیت اتصال: متصل به " + origin.substring(4));
                            } catch (Exception e) {
                            }
                        }
                    }
                }
            }
        }
    }

    public boolean getCurrentNetworkCapabilities() {

        List<ScanResult> list = mWifiAdmin.getWifiScanList();
        for (ScanResult sr : list) {
            String Capabilities = sr.capabilities;
            String ssid = sr.SSID;
            if (ssid.equals(mWifiAdmin.getSSID().substring(1, mWifiAdmin.getSSID().length() - 1))) {

                if (Capabilities.contains("WPA2") || Capabilities.contains("WPA") || Capabilities.contains("WEP")) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        return false;
    }

    public void refreshFragments() {
        FileFragment fileFragment = (FileFragment) getSupportFragmentManager().findFragmentByTag(FragmentFactory.getFragment(0).getTag());
        if (fileFragment != null)
            fileFragment.refresh();

        AppFragment appFragment = (AppFragment) getSupportFragmentManager().findFragmentByTag(FragmentFactory.getFragment(1).getTag());
        if (appFragment != null)
            appFragment.refresh();

        PictureFragment pictureFragment = (PictureFragment) getSupportFragmentManager().findFragmentByTag(FragmentFactory.getFragment(2).getTag());
        if (pictureFragment != null)
            pictureFragment.refresh();

        MusicFragment musicFragment = (MusicFragment) getSupportFragmentManager().findFragmentByTag(FragmentFactory.getFragment(3).getTag());
        if (musicFragment != null)
            musicFragment.refresh();

        VideoFragment videoFragment = (VideoFragment) getSupportFragmentManager().findFragmentByTag(FragmentFactory.getFragment(4).getTag());
        if (videoFragment != null)
            videoFragment.refresh();

        updateBadge();
    }

    public void goToReceivedFiles() {
        ReceiveFragment receiveFragment = (ReceiveFragment) getSupportFragmentManager().findFragmentByTag(FragmentFactory.getFragment(5).getTag());
        TabLayout tabhost = (TabLayout) findViewById(R.id.tabLayout);

        if (tabhost.getSelectedTabPosition() != 5) {
            tabhost.getTabAt(5).select();
        }

        if (receiveFragment != null) {
            receiveFragment.refresh();
        }
    }

    public void fadeOut() {
        Animation fade_out = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_out);
        menuHolder.setVisibility(View.GONE);
        menuHolder.startAnimation(fade_out);
    }

    public void fadeIn() {
        Animation fade_in = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_in);
        menuHolder.setVisibility(View.VISIBLE);
        menuHolder.startAnimation(fade_in);
    }

    class TransferReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String s = intent.getAction();
            Message msg = new Message();
            msg.setData(intent.getExtras());
            switch (s) {
                case Constants.FILE_RECEIVE: {
                    msg.what = 0x102;
                    break;
                }
                case Constants.FILE_RECEIVE_PEOGRESS: {
                    msg.what = 0x103;
                    break;
                }
                case Constants.FILE_RECEIVE_END: {
                    msg.what = 0x104;
                    break;
                }
                case Constants.FILE_RECEIVE_UNSUCCESSFUL: {
                    msg.what = 0x114;
                    break;
                }
                case Constants.FILE_RECEIVE_FIRST_START: {
                    msg.what = 0x116;
                    break;
                }
                case Constants.FILE_RECEIVE_LAST_END: {
                    msg.what = 0x117;
                    break;
                }
                case Constants.FILE_SEND: {
                    msg.what = 0x105;
                    break;
                }
                case Constants.FILE_SEND_NAME: {
                    msg.what = 0x106;
                    break;
                }
                case Constants.FILE_SEND_PEOGRESS: {
                    msg.what = 0x107;
                    break;
                }
                case Constants.FILE_SEND_END: {
                    msg.what = 0x108;
                    break;
                }
                case Constants.FILE_SEND_UNSUCCESSFUL: {
                    msg.what = 0x115;
                    break;
                }
                case Constants.CHANGE_HOST_NAME: {
                    msg.what = 0x109;
                    break;
                }

                case Constants.STATUS_CONNECT: {
                    msg.what = 0x110;
                    break;
                }
                case Constants.STATUS_DISCONNECT: {
                    msg.what = 0x111;
                    break;
                }
                case Constants.STATUS_AP_ON: {
                    Bundle bl_ssid = new Bundle();
                    bl_ssid.putString("ssid", mWifiAdmin.getApSSID());
                    msg.setData(bl_ssid);
                    msg.what = 0x112;
                    break;
                }
                case Constants.STATUS_AUTH_ERROR: {
                    msg.what = 0x113;
                    break;
                }
            }
            mHandler.sendMessage(msg);
        }
    }

    class MainClickEvent implements View.OnClickListener {

        @Override
        public void onClick(final View v) {
            switch (v.getId()) {
                case R.id.join_network:

                    fadeOut();

                    RelativeLayout layout = (RelativeLayout) MainActivity.this.getLayoutInflater().inflate(R.layout.choose_network_dialog_layout, null);
                    ListView listView = (ListView) layout.findViewById(R.id.list_host_choose);
                    final ArrayList<RowItem> wifiList = new ArrayList<>();
                    final HashMap<String, HashMap<String, String>> wifiMap = new HashMap<String, HashMap<String, String>>();

                    wifiList.add(new RowItem("در حال جستجو...", R.drawable.worldwide));
                    customListviewAdapter = new CustomListviewAdapter(MainActivity.this, R.layout.host_list_item, wifiList);
                    listView.setAdapter(customListviewAdapter);
                    Log.d("Wifi List Size", wifiList.size() + "");
                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            RelativeLayout hostListItem = (RelativeLayout) view;
                            TextView hostTitle = (TextView) hostListItem.findViewById(R.id.title);
                            String wifiName = hostTitle.getText().toString();

                            if (wifiName.equals("در حال جستجو...")) {
                                return;
                            } else if (wifiName.equals("جستجوی مجدد...")) {
                                wifiList.clear();
                                wifiList.add(new RowItem("در حال جستجو...", R.drawable.worldwide));
                                Message msg = new Message();
                                msg.what = 0x100;
                                mHandler.sendMessage(msg);
                                scanWifi(wifiMap, wifiList);
                                return;
                            }

                            HashMap map = wifiMap.get(wifiName);
                            String ap = map.get("ssid").toString();
                            String isSecure = map.get("isSecure").toString();
                            int level = Integer.parseInt(map.get("level").toString());

                            if (ap != null) {
                                if (isSecure.equals("TRUE")) {
                                    final String ssid = ap;
                                    MaterialDialog dialog =
                                            new MaterialDialog.Builder(MainActivity.this).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf").titleColor(getResources().getColor(R.color.colorPrimary)).positiveColor(getResources().getColor(R.color.colorPrimary)).negativeColor(getResources().getColor(R.color.colorPrimary)).theme(Theme.LIGHT)
                                                    .title("اتصال به هات‌اسپات موشک").titleGravity(GravityEnum.CENTER)
                                                    .customView(R.layout.dialog_connect_to_wifi, true).cancelable(false)
                                                    .positiveText(R.string.connect)
                                                    .negativeText(R.string.cancel_button_label)
                                                    .onPositive(new MaterialDialog.SingleButtonCallback() {
                                                        @Override
                                                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                            String password = passwordInput.getText().toString();
                                                            mWifiAdmin.connectToSSID(ssid, password, v);
                                                        }
                                                    })
                                                    .onNegative(new MaterialDialog.SingleButtonCallback() {
                                                        @Override
                                                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                            dialog.cancel();
                                                        }
                                                    })
                                                    .build();

                                    positiveAction = dialog.getActionButton(DialogAction.POSITIVE);
                                    //noinspection ConstantConditions
                                    TextView SSID = (TextView) dialog.getCustomView().findViewById(R.id.ssid);
                                    SSID.setText(ap);
                                    TextView signalStrength = (TextView) dialog.getCustomView().findViewById(R.id.strength);
                                    if (level > -50) {
                                        signalStrength.setText("Excellent");
                                    } else if (level < -50 && level > -60) {
                                        signalStrength.setText("Good");

                                    } else if (level < -60 && level > -70) {
                                        signalStrength.setText("Fair");

                                    } else if (level < -70) {
                                        signalStrength.setText("Poor");

                                    }

                                    passwordInput = (EditText) dialog.getCustomView().findViewById(R.id.password);
                                    passwordInput.addTextChangedListener(
                                            new TextWatcher() {
                                                @Override
                                                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                                                }

                                                @Override
                                                public void onTextChanged(CharSequence s, int start, int before, int count) {
                                                    positiveAction.setEnabled(s.toString().trim().length() > 0);
                                                }

                                                @Override
                                                public void afterTextChanged(Editable s) {
                                                }
                                            });

                                    // Toggling the show password CheckBox will mask or unmask the password input EditText
                                    CheckBox checkbox = (CheckBox) dialog.getCustomView().findViewById(R.id.showPassword);
                                    checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                            passwordInput.setInputType(
                                                    !isChecked ? InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_CLASS_TEXT);
                                            passwordInput.setTransformationMethod(
                                                    !isChecked ? PasswordTransformationMethod.getInstance() : null);
                                        }
                                    });

                                    TextView signalStrengthLabel = (TextView) dialog.getCustomView().findViewById(R.id.signalStrengthLabel);
                                    TextView securityLabel = (TextView) dialog.getCustomView().findViewById(R.id.securityLabel);
                                    TextView passwordLabel = (TextView) dialog.getCustomView().findViewById(R.id.passwordLabel);
                                    TextView SSIDLabel = (TextView) dialog.getCustomView().findViewById(R.id.ssidLabel);

                                    signalStrengthLabel.setTypeface(iranYekanBold);
                                    securityLabel.setTypeface(iranYekanBold);
                                    passwordLabel.setTypeface(iranYekanBold);
                                    checkbox.setTypeface(iranYekanBold);
                                    SSIDLabel.setTypeface(iranYekanBold);

                                    int widgetColor = ThemeSingleton.get().widgetColor;
                                    MDTintHelper.setTint(
                                            checkbox, widgetColor == 0 ? ContextCompat.getColor(getContext(), R.color.colorPrimary) : widgetColor);

                                    MDTintHelper.setTint(
                                            passwordInput,
                                            widgetColor == 0 ? ContextCompat.getColor(getContext(), R.color.colorPrimary) : widgetColor);

                                    dialog.show();
                                    positiveAction.setEnabled(false); // disabled by default

                                } else {
                                    mWifiAdmin.connectToSSID(ap, v);
                                }
                            }
                            if (alertDialog != null) {
                                alertDialog.dismiss();
                                alertDialog = null;
                            }
                        }
                    });
                    scanWifi(wifiMap, wifiList);
                    showChooseDialog(layout, "شبکه‌ی مورد نظر را انتخاب کنید");
                    break;
                case R.id.create_normal_network:

                    if (mWifiAdmin.isWifiApOpen()) {

                        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "در حال حاضر شبکه برقرار است، در صورت تمایل به ادامه ابتدا شبکه‌ی فعلی را قطع کنید!", Snackbar.LENGTH_SHORT);
                        View sbView = snackbar.getView();
                        sbView.setBackgroundColor(Color.RED);
                        TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                        tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                        tv.setTypeface(iranYekanBold);
                        snackbar.show();

                    } else {

                        fadeOut();

                        LogUtils.s("Normal Hotspot Open......");
                        final String ap_name = TransferUtils.convert(Constants.WIFI_AP_NAME + android.os.Build.MODEL);
                        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                            MaterialDialog dialog =
                                    new MaterialDialog.Builder(MainActivity.this).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf").theme(Theme.LIGHT)
                                            .title("ایجاد شبکه").titleGravity(GravityEnum.CENTER).titleColor(getResources().getColor(R.color.colorPrimary)).positiveColor(getResources().getColor(R.color.colorPrimary)).negativeColor(getResources().getColor(R.color.colorPrimary))
                                            .content("آیا مایل به ایجاد شبکه هستید؟ در صورت تایید به تنظیمات هدایت شده و با لمس سوییچ هات‌اسپات نسبت به ایجاد شبکه اقدام فرمایید. در صورت تمایل می‌توانید با انتخاب رمز اقدام به ایجاد شبکه‌ی امن کنید. ").contentGravity(GravityEnum.CENTER).cancelable(false)
                                            .positiveText("بله")
                                            .negativeText("خیر")
                                            .onPositive(new MaterialDialog.SingleButtonCallback() {
                                                @Override
                                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                    mWifiAdmin.openHotspotActivity(ap_name);
                                                    isReturnedFromSetting = true;
                                                }
                                            }).onNegative(new MaterialDialog.SingleButtonCallback() {
                                        @Override
                                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                            dialog.cancel();

                                        }
                                    }).build();
                            dialog.show();


                        } else {
                            mWifiConfiguration = mWifiAdmin.setConfigWifiAp(ap_name, Constants.WIFI_AP_PSWD, WifiAdmin.NO_PASSWORD);
                            mWifiAdmin.openWifiAp(mWifiConfiguration, v);
                            Log.d("Config", mWifiConfiguration.toString());
                        }
                    }
                    break;

                case R.id.create_secure_network:

                    if (mWifiAdmin.isWifiApOpen()) {

                        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "در حال حاضر شبکه برقرار است، در صورت تمایل به ادامه ابتدا شبکه‌ی فعلی را قطع کنید!", Snackbar.LENGTH_SHORT);
                        View sbView = snackbar.getView();
                        sbView.setBackgroundColor(Color.RED);
                        TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                        tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                        tv.setTypeface(iranYekanBold);
                        snackbar.show();
                    } else {

                        fadeOut();

                        LogUtils.s("Secure Hotspot Open......");
                        final String secure_ap_name = TransferUtils.convert(Constants.WIFI_AP_NAME + android.os.Build.MODEL);
                        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
                        String key = sharedPreferences.getString("preSharedKey", "");
                        if (key.equals("") && android.os.Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                            Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "لطفا کلیدی برای اتصال و رمزنگاری از قسمت تنظیمات انتخاب کنید!", Snackbar.LENGTH_LONG).setAction("تنظیمات", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent intent = new Intent(getContext(), SettingActivity.class);
                                    startActivity(intent);
                                }
                            });
                            View sbView = snackbar.getView();
                            sbView.setBackgroundColor(Color.RED);
                            TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                            tv.setTypeface(iranYekanBold);
                            TextView btn = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_action);
                            btn.setTypeface(iranYekanBold);
                            btn.setTextColor(Color.parseColor("#f8a0a0"));
                            btn.setTextSize(14);
                            snackbar.show();
                        } else {
                            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                MaterialDialog dialog =
                                        new MaterialDialog.Builder(MainActivity.this).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf").theme(Theme.LIGHT)
                                                .title("ایجاد شبکه").titleGravity(GravityEnum.CENTER).titleColor(getResources().getColor(R.color.colorPrimary)).positiveColor(getResources().getColor(R.color.colorPrimary)).negativeColor(getResources().getColor(R.color.colorPrimary))
                                                .content("آیا مایل به ایجاد شبکه امن هستید؟ در صورت تایید به تنظیمات هدایت شده و لازم است ابتدا یک رمز عبور برای شبکه انتخاب کرده و سپس با لمس سوییچ هات‌اسپات نسبت به ایجاد شبکه اقدام فرمایید. ").contentGravity(GravityEnum.CENTER).cancelable(false)
                                                .positiveText("بله")
                                                .negativeText("خیر")
                                                .onPositive(new MaterialDialog.SingleButtonCallback() {
                                                    @Override
                                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                        mWifiAdmin.openHotspotActivity(secure_ap_name);
                                                        isReturnedFromSetting = true;

                                                    }
                                                }).onNegative(new MaterialDialog.SingleButtonCallback() {
                                            @Override
                                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                dialog.cancel();

                                            }
                                        }).build();
                                dialog.show();

                            } else {
                                mWifiConfiguration = mWifiAdmin.setConfigWifiAp(secure_ap_name, key, WifiAdmin.WPA_PASSWORD);
                                mWifiAdmin.openWifiAp(mWifiConfiguration, v);
                            }
                        }
                    }
                    break;

                case R.id.disconnect_network:
                    if (mWifiAdmin.isWifiApOpen()) {
                        mWifiAdmin.closeWifiAp();
                        mWifiAdmin.setDefaultAP();
                    } else if (mWifiAdmin.isConnect()) {
                        mWifiAdmin.disconnectFromNetwork();
                    } else {
                        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "هیچ شبکه‌ای فعال نیست و اتصال به شبکه نیز وجود ندارد!", Snackbar.LENGTH_SHORT);
                        View sbView = snackbar.getView();
                        sbView.setBackgroundColor(Color.RED);
                        TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                        tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                        tv.setTypeface(iranYekanBold);
                        snackbar.show();
                    }
                    fadeOut();
                    break;

                default:
                    break;
            }
        }
    }
}
