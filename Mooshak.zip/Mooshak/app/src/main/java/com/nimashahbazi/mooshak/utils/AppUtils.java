package com.nimashahbazi.mooshak.utils;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;

import com.nimashahbazi.mooshak.entity.AppInfo;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by nimashahbazi on 10/26/17.
 */

public class AppUtils {
    private static PackageManager pManager;


    public static List<AppInfo> getAppInfos(Context context) {
        pManager = (PackageManager) context.getPackageManager();
        List<AppInfo> appInfos = new ArrayList<AppInfo>();
        AppInfo appInfo = null;

        List<PackageInfo> paklist = pManager.getInstalledPackages(0);
        for (int i = 0; i < paklist.size(); i++) {
            PackageInfo pak = (PackageInfo) paklist.get(i);
            if ((pak.applicationInfo.flags & pak.applicationInfo.FLAG_SYSTEM) <= 0) {
                String title = pak.applicationInfo.loadLabel(pManager).toString();
                String path = pak.applicationInfo.publicSourceDir;
                File file = new File(pak.applicationInfo.publicSourceDir);
                String size = null;
                long Filesize = getFolderSize(file) / 1024;
                if (Filesize >= 1024)
                    size = Filesize / 1024 + " Mb";
                else
                    size = Filesize + " Kb";

                Drawable icon = pak.applicationInfo.loadIcon(context.getPackageManager());

                String packageName = pak.packageName;

                appInfo = new AppInfo(title, path, size, icon, packageName);
                appInfos.add(appInfo);
            }
        }

        return appInfos;
    }

    public static long getFolderSize(File f) {
        long size = 0;
        if (f.isDirectory()) {
            for (File file : f.listFiles()) {
                size += getFolderSize(file);
            }
        } else {
            size = f.length();
        }
        return size;
    }

}
