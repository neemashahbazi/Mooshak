package com.nimashahbazi.mooshak.net;

import android.util.Log;

import org.apache.commons.io.FilenameUtils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Properties;


public class ReceiveThread extends TransferSocket implements Runnable {

    public final static String mSplit;

    static {
        Properties p = System.getProperties();
        mSplit = p.getProperty("file.separator");
    }

    private Socket mSocket;
    private DataInputStream mDis;
    private DataOutputStream mDos;
    private String mPath;
    private int mTotalNum;
    private int mNum;

    public ReceiveThread(Socket mSocket, String path, String host) throws IOException {
        super();
        this.mHostName = host;
        this.mSocket = mSocket;
        this.mPath = path;
        this.mThread = new Thread(this);
        init();
    }

    private void init() throws IOException {

        mDis = new DataInputStream(new BufferedInputStream(mSocket.getInputStream()));
        mDos = new DataOutputStream(new BufferedOutputStream(mSocket.getOutputStream()));

        isEnd = false;

        data = new byte[8192];
        len = 0;

        mTransferLenght = 0;
        mFileLenght = 0;

        mIp = mSocket.getInetAddress().getHostAddress();

        mDos.write(mHostName.getBytes("UTF-8"));
        mDos.flush();

        mNum = mDis.readInt();
        mTotalNum = mDis.readInt();

        mFileLenght = mDis.readLong();

        len = mDis.read(data);
        mFileName = new String(data, 0, len, "UTF-8");
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub
        File file = null;
        DataOutputStream fos = null;

        try {
            mDos.write(1);
            mDos.flush();

            file = createFile();
            fos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)));

            new CountRate().start();

            while ((len = mDis.read(data)) != -1) {
                fos.write(data, 0, len);
                mTransferLenght += len;
            }
            fos.flush();

        } catch (IOException e) {
            isEnd = true;
            System.out.println("Interrupted");

        } finally {
            try {
                if (mSocket != null) {
                    mSocket.close();
                }
                if (fos != null) {
                    fos.close();
                }
                isEnd = true;
                System.out.println("Finish");
                if (file != null && file.isFile() && file.exists() && mFileLenght != mTransferLenght) {
                    System.out.println("Delete " + file.getAbsolutePath() + " " + file.delete());
                }

            } catch (IOException e) {

            }
        }
    }

    public int getFileNum() {
        return mNum;
    }

    public int getTotalNum() {
        return mTotalNum;
    }

    private File createFile() {

        File file = new File(mPath);
        if (!file.exists()) {
            file.mkdir();
        }

        String sb = mPath + mSplit + mFileName;
        file = new File(sb);

        String firstExtension = FilenameUtils.getExtension(mFileName);
        int i = 0;
        String path = null;
        int firstIndex = sb.lastIndexOf(".");
        String middlePath = sb.substring(0, firstIndex);
        String secondExtension = FilenameUtils.getExtension(middlePath);
        int secondIndex = middlePath.lastIndexOf(".");
        if (secondIndex > 0) {
            path = sb.substring(0, secondIndex);
        } else {
            path = sb.substring(0, firstIndex);
        }
        Log.d("Path", firstExtension + "   " + secondExtension + "   " + path);

        while (file.exists()) {
            i++;
            if (secondExtension.equals(""))
                file = new File(path + "_" + i + "." + firstExtension);

            else
                file = new File(path + "_" + i + "." + secondExtension + "." + firstExtension);
        }
        try {
            file.createNewFile();
        } catch (Exception e) {

        }
        return file;
    }

    public void close() {
        try {
            this.mSocket.close();
        } catch (IOException e) {

        }
    }

    public String getPath() {
        return mPath;
    }

    public long getReceiveRate() {
        return getRate();
    }

    private class CountRate extends Thread {


        public CountRate() {
            // TODO Auto-generated constructor stub
        }

        @Override
        public void run() {
            // TODO Auto-generated method stub
            super.run();

            long preTime;
            long currTime;
            long timeDiff;
            long preLenght;
            long currLenght;

            preLenght = mTransferLenght;
            preTime = System.currentTimeMillis();
            while (mTransferLenght < mFileLenght && !isEnd) {
                currTime = System.currentTimeMillis();
                currLenght = mTransferLenght;
                timeDiff = currTime - preTime;
                if (timeDiff != 0) {
                    mCurrRate = (long) ((double) (mTransferLenght - preLenght) * 1000.0 / (double) timeDiff);
                } else {
                    mCurrRate = 0;
                }
                preLenght = currLenght;
                preTime = currTime;
                try {
                    Thread.sleep(500);
                } catch (Exception e) {
                }
            }
            mCurrRate = 0;
        }

    }

}