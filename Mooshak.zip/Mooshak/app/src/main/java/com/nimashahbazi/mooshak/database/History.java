package com.nimashahbazi.mooshak.database;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

/**
 * Created by nimashahbazi on 11/8/17.
 */
@Entity
public class History {

    @PrimaryKey(autoGenerate = true)
    long id;

    private int imageId;
    private String title;
    private long timestamp;
    private int status;

    public History(int imageId, String title, long timestamp, int status) {
        this.title = title;
        this.imageId = imageId;
        this.timestamp = timestamp;
        this.status = status;
    }

    public int getImageId() {
        return imageId;
    }

    public String getTitle() {
        return title;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public int getStatus() {
        return status;
    }


}
