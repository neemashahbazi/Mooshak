package com.nimashahbazi.mooshak.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.SwitchCompat;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.GravityEnum;
import com.afollestad.materialdialogs.MaterialDialog;
import com.afollestad.materialdialogs.Theme;
import com.afollestad.materialdialogs.internal.MDTintHelper;
import com.afollestad.materialdialogs.internal.ThemeSingleton;
import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.base.BaseActivity;
import com.nimashahbazi.mooshak.conf.Constants;
import com.nimashahbazi.mooshak.database.HistoryDatabase;

import java.io.File;

public class SettingActivity extends BaseActivity {

    TextView password;
    TextView username;
    Typeface iranYekanBold;
    SharedPreferences sharedPreferences;
    private CompoundButton.OnCheckedChangeListener switchButtonListener;
    private EditText passwordInput;
    private EditText usernameInput;
    private Toolbar mToolbar;
    private View positiveAction;
    private HistoryDatabase database;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        database = HistoryDatabase.getDatabase(getApplicationContext());
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        TextView passwordRequired = (TextView) findViewById(R.id.password_required);
        SwitchCompat switchButton = (SwitchCompat) findViewById(R.id.switch_button);
        TextView passwordChange = (TextView) findViewById(R.id.password_change);
        password = (TextView) findViewById(R.id.password);
        TextView usernameChange = (TextView) findViewById(R.id.username_change);
        username = (TextView) findViewById(R.id.username);
        TextView clearHistory = (TextView) findViewById(R.id.clear_history);
        final LinearLayout btnPasswordChange = (LinearLayout) findViewById(R.id.btn_password_change);
        LinearLayout btnUsernameChange = (LinearLayout) findViewById(R.id.btn_username_change);
        LinearLayout btnClearHistoy = (LinearLayout) findViewById(R.id.btn_clear_history);
        TextView changeHotspotPassword = (TextView) findViewById(R.id.change_hotspot_password);
        LinearLayout btnchangeHotspotPassword = (LinearLayout) findViewById(R.id.btn_change_hotspot_password);
        final String passwordLable = sharedPreferences.getString("password", "");
        final String passwordRequestLable = sharedPreferences.getString("passwordRequest", "");
        iranYekanBold = Typeface.createFromAsset(getAssets(), "fonts/iranyekanwebbold.ttf");
        changeHotspotPassword.setTypeface(iranYekanBold);
        passwordRequired.setTypeface(iranYekanBold);
        passwordChange.setTypeface(iranYekanBold);
        password.setTypeface(iranYekanBold);
        usernameChange.setTypeface(iranYekanBold);
        clearHistory.setTypeface(iranYekanBold);
        username.setTypeface(iranYekanBold);
        username.setText(getLastHostName());
        final RelativeLayout passwordChangeBorder = (RelativeLayout) findViewById(R.id.password_change_border);
        mToolbar = (Toolbar) findViewById(R.id.setting_toolbar);
        mToolbar.setTitle("تنظیمات");
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TextView mTitle = (TextView) mToolbar.findViewById(R.id.toolbar_title);
        mTitle.setTypeface(iranYekanBold);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        if (passwordRequestLable.equals("1")) {
            password.setText("");
            for (int i = 0; i < passwordLable.length(); i++) {
                password.append("*");
            }
            switchButton.setChecked(true);
        } else if (!passwordRequestLable.equals("1")) {
            btnPasswordChange.setVisibility(View.GONE);
            passwordChangeBorder.setVisibility(View.GONE);
        }

        switchButtonListener = new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPreferences.Editor editor = sharedPreferences.edit();

                if (isChecked) {
                    editor.putString("passwordRequest", "1");
                    editor.commit();
                    Intent mainIntent = new Intent(SettingActivity.this, PasswordActivity.class);
                    SettingActivity.this.startActivity(mainIntent);
                    SettingActivity.this.finish();
                }
                if (!isChecked) {
                    editor.putString("passwordRequest", "0");
                    editor.putString("password", "");
                    editor.commit();
                    btnPasswordChange.setVisibility(View.GONE);
                    passwordChangeBorder.setVisibility(View.GONE);
                }
            }
        };

        switchButton.setOnCheckedChangeListener(switchButtonListener);

        btnchangeHotspotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MaterialDialog dialog =
                        new MaterialDialog.Builder(SettingActivity.this).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf").theme(Theme.LIGHT)
                                .title("تغییر کلید رمزنگاری و اتصال").titleGravity(GravityEnum.CENTER).titleColor(getResources().getColor(R.color.colorPrimary)).positiveColor(getResources().getColor(R.color.colorPrimary)).negativeColor(getResources().getColor(R.color.colorPrimary))
                                .customView(R.layout.dialog_change_key, true).cancelable(false)
                                .positiveText(R.string.btn_apply)
                                .negativeText(R.string.cancel_button_label)
                                .onPositive(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {

                                        SharedPreferences.Editor editor = sharedPreferences.edit();
                                        String password;
                                        password = passwordInput.getText().toString();
                                        if ((!password.isEmpty()) && (password.length() > 7) && (password.length() < 63)) {
                                            editor.putString("preSharedKey", password);
                                            editor.commit();
                                            Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "کلید رمزنگاری و اتصال با موفقیت تغییر یافت!", Snackbar.LENGTH_SHORT);
                                            View sbView = snackbar.getView();
                                            sbView.setBackgroundColor(Color.parseColor("#a4c639"));
                                            TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                                            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                                            tv.setTypeface(iranYekanBold);
                                            snackbar.show();
                                        }
                                    }
                                })
                                .onNegative(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                        dialog.cancel();
                                    }
                                })
                                .build();

                positiveAction = dialog.getActionButton(DialogAction.POSITIVE);
                passwordInput = (EditText) dialog.getCustomView().findViewById(R.id.password);
                passwordInput.setTypeface(iranYekanBold);
                passwordInput.addTextChangedListener(
                        new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                                positiveAction.setEnabled(s.toString().trim().length() > 7);
                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                            }
                        });

                CheckBox checkbox = (CheckBox) dialog.getCustomView().findViewById(R.id.showPassword);
                checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        passwordInput.setInputType(
                                !isChecked ? InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_CLASS_TEXT);
                        passwordInput.setTransformationMethod(
                                !isChecked ? PasswordTransformationMethod.getInstance() : null);
                    }
                });


                TextView passwordLabel = (TextView) dialog.getCustomView().findViewById(R.id.passwordLabel);


                passwordLabel.setTypeface(iranYekanBold);
                checkbox.setTypeface(iranYekanBold);

                int widgetColor = ThemeSingleton.get().widgetColor;
                MDTintHelper.setTint(
                        checkbox, widgetColor == 0 ? ContextCompat.getColor(SettingActivity.this, R.color.colorPrimary) : widgetColor);

                MDTintHelper.setTint(
                        passwordInput,
                        widgetColor == 0 ? ContextCompat.getColor(SettingActivity.this, R.color.colorPrimary) : widgetColor);

                dialog.show();
                positiveAction.setEnabled(false); // disabled by default


            }
        });

        btnPasswordChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MaterialDialog dialog =
                        new MaterialDialog.Builder(SettingActivity.this).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf").theme(Theme.LIGHT)
                                .title("تغییر رمز عبور").titleGravity(GravityEnum.CENTER).titleColor(getResources().getColor(R.color.colorPrimary)).positiveColor(getResources().getColor(R.color.colorPrimary)).negativeColor(getResources().getColor(R.color.colorPrimary))
                                .customView(R.layout.dialog_change_password, true).cancelable(false)
                                .positiveText(R.string.btn_apply)
                                .negativeText(R.string.cancel_button_label)
                                .onPositive(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {

                                        SharedPreferences.Editor editor = sharedPreferences.edit();
                                        String password_;
                                        password_ = passwordInput.getText().toString();
                                        if (!password_.isEmpty()) {
                                            editor.putString("password", password_);
                                            editor.putString("passwordRequest", "1");
                                            editor.commit();
                                            Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "رمز عبور با موفقیت تغییر یافت!", Snackbar.LENGTH_SHORT);
                                            View sbView = snackbar.getView();
                                            sbView.setBackgroundColor(Color.parseColor("#a4c639"));
                                            TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                                            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                                            tv.setTypeface(iranYekanBold);
                                            snackbar.show();
                                            password.setText("");
                                            for (int i = 0; i < password_.length(); i++) {
                                                password.append("*");
                                            }
                                        }
                                    }
                                })
                                .onNegative(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                        dialog.cancel();
                                    }
                                })
                                .build();

                positiveAction = dialog.getActionButton(DialogAction.POSITIVE);
                passwordInput = (EditText) dialog.getCustomView().findViewById(R.id.password);
                passwordInput.setTypeface(iranYekanBold);
                passwordInput.addTextChangedListener(
                        new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                                positiveAction.setEnabled(s.toString().trim().length() > 0);
                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                            }
                        });

                CheckBox checkbox = (CheckBox) dialog.getCustomView().findViewById(R.id.showPassword);
                checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        passwordInput.setInputType(
                                !isChecked ? InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_CLASS_TEXT);
                        passwordInput.setTransformationMethod(
                                !isChecked ? PasswordTransformationMethod.getInstance() : null);
                    }
                });


                TextView passwordLabel = (TextView) dialog.getCustomView().findViewById(R.id.passwordLabel);


                passwordLabel.setTypeface(iranYekanBold);
                checkbox.setTypeface(iranYekanBold);

                int widgetColor = ThemeSingleton.get().widgetColor;
                MDTintHelper.setTint(
                        checkbox, widgetColor == 0 ? ContextCompat.getColor(SettingActivity.this, R.color.colorPrimary) : widgetColor);

                MDTintHelper.setTint(
                        passwordInput,
                        widgetColor == 0 ? ContextCompat.getColor(SettingActivity.this, R.color.colorPrimary) : widgetColor);

                dialog.show();
                positiveAction.setEnabled(false); // disabled by default
            }
        });
        btnUsernameChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MaterialDialog dialog =
                        new MaterialDialog.Builder(SettingActivity.this).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf").theme(Theme.LIGHT)
                                .title("تغییر نام کاربری").titleGravity(GravityEnum.CENTER).titleColor(getResources().getColor(R.color.colorPrimary)).positiveColor(getResources().getColor(R.color.colorPrimary)).negativeColor(getResources().getColor(R.color.colorPrimary))
                                .customView(R.layout.dialog_change_username, true).cancelable(false)
                                .positiveText(R.string.btn_apply)
                                .negativeText(R.string.cancel_button_label)
                                .onPositive(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                        SharedPreferences.Editor editor = sharedPreferences.edit();
                                        final String username_;
                                        username_ = usernameInput.getText().toString();
                                        if (username_.matches("^[a-zA-Z0-9.]+$")) {
                                            if (!username_.isEmpty()) {
                                                mBinder.setHostName(username_);
                                                username.setText(username_);
                                                Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "نام کاربری با موفقیت تغییر یافت!", Snackbar.LENGTH_SHORT);
                                                View sbView = snackbar.getView();
                                                sbView.setBackgroundColor(Color.parseColor("#a4c639"));
                                                TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                                                tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                                                tv.setTypeface(iranYekanBold);
                                                snackbar.show();
                                            }
                                        } else {
                                            Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "نام کاربری تنها می‌تواند شامل اعداد و کاراکتر‌های لاتین باشد!", Snackbar.LENGTH_SHORT);
                                            View sbView = snackbar.getView();
                                            sbView.setBackgroundColor(Color.RED);
                                            TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                                            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                                            tv.setTypeface(iranYekanBold);
                                            snackbar.show();
                                        }
                                    }

                                })
                                .onNegative(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                        dialog.cancel();
                                    }
                                })
                                .build();

                positiveAction = dialog.getActionButton(DialogAction.POSITIVE);
                usernameInput = (EditText) dialog.getCustomView().findViewById(R.id.username);
                usernameInput.setText(getLastHostName());
                usernameInput.setTypeface(iranYekanBold);
                usernameInput.addTextChangedListener(
                        new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                                positiveAction.setEnabled(s.toString().trim().length() > 0);
                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                            }
                        });


                TextView usernameLabel = (TextView) dialog.getCustomView().findViewById(R.id.usernameLabel);


                usernameLabel.setTypeface(iranYekanBold);

                int widgetColor = ThemeSingleton.get().widgetColor;

                MDTintHelper.setTint(
                        usernameInput,
                        widgetColor == 0 ? ContextCompat.getColor(SettingActivity.this, R.color.colorPrimary) : widgetColor);

                dialog.show();
                positiveAction.setEnabled(false); // disabled by default


            }
        });

        btnClearHistoy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                MaterialDialog dialog =
                        new MaterialDialog.Builder(SettingActivity.this).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf").theme(Theme.LIGHT)
                                .title("پاک کردن تاریخچه‌ی انتقالات").titleGravity(GravityEnum.CENTER).titleColor(getResources().getColor(R.color.colorPrimary)).positiveColor(getResources().getColor(R.color.colorPrimary)).negativeColor(getResources().getColor(R.color.colorPrimary))
                                .content("آیا مایل به پاک کردن تاریخچه‌ی دریافت‌ها هستید؟").contentGravity(GravityEnum.CENTER).cancelable(false)
                                .positiveText("بله")
                                .negativeText("خیر")
                                .onPositive(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {

                                        database.historyDao().removeAllHistory();
                                        final File dirDownload = new File(Environment.getExternalStoragePublicDirectory("Mooshak").toString());
                                        File[] fileListDownload = dirDownload.listFiles();
                                        for (int i = 0; i < fileListDownload.length; i++) {
                                            deleteRecursive(fileListDownload[i]);
                                        }
                                        final File dirEncrypted = new File(Environment.getExternalStoragePublicDirectory("Android/data/" + getApplicationContext().getPackageName() + "/Files/Encrypted").toString());
                                        File[] fileListEncrypted = dirEncrypted.listFiles();
                                        for (int i = 0; i < fileListEncrypted.length; i++) {
                                            deleteRecursive(fileListEncrypted[i]);
                                        }
                                        final File dirCompressed = new File(Environment.getExternalStoragePublicDirectory("Android/data/" + getApplicationContext().getPackageName() + "/Files/Compressed").toString());
                                        File[] fileListCompressed = dirCompressed.listFiles();
                                        for (int i = 0; i < fileListCompressed.length; i++) {
                                            deleteRecursive(fileListCompressed[i]);
                                        }
                                        dialog.dismiss();

                                        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "فایل‌های دریافتی با موفقیت حذف شدند!", Snackbar.LENGTH_SHORT);
                                        View sbView = snackbar.getView();
                                        sbView.setBackgroundColor(Color.parseColor("#a4c639"));
                                        TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                                        tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                                        tv.setTypeface(iranYekanBold);
                                        snackbar.show();

                                    }
                                }).onNegative(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                dialog.cancel();

                            }
                        }).build();
                dialog.show();

            }
        });
    }

    @Override
    protected void initView() {

    }

    void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory())
            for (File child : fileOrDirectory.listFiles())
                deleteRecursive(child);

        fileOrDirectory.delete();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;

            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private String getLastHostName() {
        String hostName = android.os.Build.MODEL + "-" + android.os.Build.VERSION.RELEASE;
        try {
            SharedPreferences sp = getApplicationContext().getSharedPreferences(Constants.PROPERTIES_FILE_NAME, Context.MODE_PRIVATE);
            hostName = sp.getString("host_name", android.os.Build.MODEL + "-" + android.os.Build.VERSION.RELEASE);
        } catch (Exception e) {
        }
        return hostName;
    }

    @Override
    protected void initActionBar() {
        super.initActionBar();
    }
}
