package com.nimashahbazi.mooshak.base;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.afollestad.materialdialogs.GravityEnum;
import com.afollestad.materialdialogs.MaterialDialog;
import com.afollestad.materialdialogs.Theme;
import com.nimashahbazi.mooshak.MainActivity;
import com.nimashahbazi.mooshak.R;
import com.nimashahbazi.mooshak.activity.SettingActivity;
import com.nimashahbazi.mooshak.control.ISendFiles;
import com.nimashahbazi.mooshak.utils.UIUtils;
import com.rockaport.alice.Alice;
import com.rockaport.alice.AliceContext;
import com.rockaport.alice.AliceContextBuilder;

import org.apache.commons.io.FilenameUtils;
import org.zeroturnaround.zip.ZipUtil;

import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;


public abstract class BaseFragment extends Fragment {

    static {

        try {
            System.loadLibrary("Mooshak");

        } catch (UnsatisfiedLinkError use) {
            Log.e("JNI", "WARNING: Could not load native library");
        }
    }

    public ISendFiles mSendFile;
    public Typeface iranYekanBold;
    MaterialDialog pd;
    ArrayList<String> fileList = new ArrayList<>();
    String key;
    SharedPreferences sharedPreferences;
    Alice alice;
    private Menu menu;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        init();
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        iranYekanBold = Typeface.createFromAsset(getActivity().getAssets(), "fonts/iranyekanwebbold.ttf");
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(UIUtils.getContext());
        key = sharedPreferences.getString("preSharedKey", "");
        AliceContext aliceContext = new AliceContextBuilder()
                .setAlgorithm(AliceContext.Algorithm.AES)
                .setMode(AliceContext.Mode.CTR)
                .setIvLength(16)
                .setPbkdf(AliceContext.Pbkdf.NONE)
                .build();
        alice = new Alice(aliceContext);


    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        this.menu = menu;
        boolean isSecure = sharedPreferences.getBoolean("isSecure", false);
        if (isSecure)
            menu.getItem(0).setIcon(ContextCompat.getDrawable(UIUtils.getContext(), R.drawable.lock));
        else
            menu.getItem(0).setIcon(ContextCompat.getDrawable(UIUtils.getContext(), R.drawable.unlock));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.action_send:
                if (UIUtils.fileList.isEmpty()) {
                    Snackbar snackbar = Snackbar.make(getActivity().findViewById(android.R.id.content), "لطفا فایلی را برای ارسال انتخاب کنید!", Snackbar.LENGTH_SHORT);
                    View sbView = snackbar.getView();
                    sbView.setBackgroundColor(Color.RED);
                    TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                    tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                    tv.setTypeface(iranYekanBold);
                    snackbar.show();

                } else {
                    fileList.removeAll(fileList);
                    final boolean isSecure = sharedPreferences.getBoolean("isSecure", false);
                    if (!isSecure) {
                        pd = new MaterialDialog.Builder(getActivity()).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf").titleGravity(GravityEnum.CENTER).theme(Theme.LIGHT).titleColor(getResources().getColor(R.color.colorPrimary))
                                .title("آماده سازی فایل‌ها برای ارسال")
                                .content("لطفا منتظر بمانید...")
                                .progress(true, 0).cancelable(false)
                                .show();

                        new Thread(new Runnable() {
                            @Override
                            public void run() {

                                for (String path : UIUtils.fileList) {
                                    if (new File(path).isDirectory()) {
                                        fileList.add(compressFolder(new File(path)));
                                    } else {
                                        fileList.add(path);
                                    }
                                }

                                for (String file : fileList)
                                    Log.d("File List", file);

                                getActivity().runOnUiThread(new Runnable() {
                                    public void run() {
                                        pd.dismiss();
                                        mSendFile.sendFileList(fileList);
                                    }
                                });
                            }
                        }).start();

                    } else {
                        pd = new MaterialDialog.Builder(getActivity()).typeface("iranyekanwebbold.ttf", "iranyekanwebbold.ttf").titleGravity(GravityEnum.CENTER).theme(Theme.LIGHT).titleColor(getResources().getColor(R.color.colorPrimary))
                                .title("در حال رمزنگاری فایل‌ها")
                                .content("لطفا منتظر بمانید...")
                                .progress(true, 0).cancelable(false)
                                .show();

                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                for (String path : UIUtils.fileList) {
                                    String output = Environment.getExternalStoragePublicDirectory("Android/data/" + UIUtils.getContext().getPackageName() + "/Files/Encrypted").toString() + "/" + new File(path).getName() + ".encr";

                                    String firstExtension = FilenameUtils.getExtension(output);
                                    int i = 0;
                                    String path_ = null;
                                    int firstIndex = output.lastIndexOf(".");
                                    String middlePath = output.substring(0, firstIndex);
                                    String secondExtension = FilenameUtils.getExtension(middlePath);
                                    int secondIndex = middlePath.lastIndexOf(".");
                                    path_ = output.substring(0, secondIndex);
                                    Log.d("Path", firstExtension + "   " + secondExtension + "   " + path_);

                                    while (new File(output).exists()) {
                                        i++;
                                        output = path_ + "_" + i + "." + secondExtension + "." + firstExtension;
                                    }

                                    if (new File(path).isDirectory()) {
                                        output = Environment.getExternalStoragePublicDirectory("Android/data/" + UIUtils.getContext().getPackageName() + "/Files/Encrypted").toString() + "/" + new File(path).getName() + ".dir.encr";
                                        Log.d("PATH", path);
                                        Log.d("OUTPUT", output);
                                        try {
                                            alice.encrypt(new File(compressFolder(new File(path))), new File(output), key.toCharArray());
                                        } catch (GeneralSecurityException | IOException e) {
                                            e.printStackTrace();
                                        }
                                        fileList.add(output);
                                    } else {
                                        Log.d("PATH", path);
                                        Log.d("OUTPUT", output);
                                        char[] chars = key.toCharArray();
                                        try {
                                            alice.encrypt(new File(path), new File(output), chars);
                                        } catch (GeneralSecurityException | IOException e) {
                                            e.printStackTrace();
                                        }

                                        fileList.add(output);
                                    }
                                }

                                for (String file : fileList)
                                    Log.d("Encrypted File List", file);

                                getActivity().runOnUiThread(new Runnable() {
                                    public void run() {
                                        pd.dismiss();
                                        mSendFile.sendFileList(fileList);
                                    }
                                });
                            }
                        }).start();
                    }
                }


                return true;

            case R.id.action_secure:
                boolean isSecure = sharedPreferences.getBoolean("isSecure", false);
                if (isSecure) {
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putBoolean("isSecure", false);
                    editor.commit();
                    menu.getItem(0).setIcon(ContextCompat.getDrawable(UIUtils.getContext(), R.drawable.unlock));
                    Snackbar snackbar = Snackbar.make(getActivity().findViewById(android.R.id.content), "حالت ارسال عادی فعال شد!", Snackbar.LENGTH_SHORT);
                    View sbView = snackbar.getView();
                    sbView.setBackgroundColor(Color.parseColor("#a4c639"));
                    TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                    tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                    tv.setTypeface(iranYekanBold);
                    snackbar.show();

                } else {
                    if (key.equals("")) {
                        Snackbar snackbar = Snackbar.make(getActivity().findViewById(android.R.id.content), "لطفا کلیدی برای اتصال و رمزنگاری از قسمت تنظیمات انتخاب کنید!", Snackbar.LENGTH_SHORT).setAction("تنظیمات", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent intent = new Intent(getContext(), SettingActivity.class);
                                startActivity(intent);
                            }
                        });
                        View sbView = snackbar.getView();
                        sbView.setBackgroundColor(Color.RED);
                        TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                        tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                        tv.setTypeface(iranYekanBold);
                        TextView btn = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_action);
                        btn.setTypeface(iranYekanBold);
                        btn.setTextColor(Color.parseColor("#f8a0a0"));
                        btn.setTextSize(14);
                        snackbar.show();
                    } else {
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putBoolean("isSecure", true);
                        editor.commit();
                        menu.getItem(0).setIcon(ContextCompat.getDrawable(UIUtils.getContext(), R.drawable.lock));
                        Snackbar snackbar = Snackbar.make(getActivity().findViewById(android.R.id.content), "حالت ارسال امن فعال شد!", Snackbar.LENGTH_SHORT);
                        View sbView = snackbar.getView();
                        sbView.setBackgroundColor(Color.parseColor("#a4c639"));
                        TextView tv = (TextView) (snackbar.getView()).findViewById(android.support.design.R.id.snackbar_text);
                        tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                        tv.setTypeface(iranYekanBold);
                        snackbar.show();
                    }
                }

            default:
                break;
        }
        return false;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return initView(inflater, container, savedInstanceState);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        initData();
        initListener();
        super.onActivityCreated(savedInstanceState);
    }

    public abstract View initView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState);


    public void init() {
        // TODO
        mSendFile = (ISendFiles) getActivity();
    }

    public void initData() {
        // TODO
    }

    public void initListener() {
        // TODO
    }

    public String compressFolder(File file) {
        String directory = Environment.getExternalStoragePublicDirectory("Android/data/" + UIUtils.getContext().getPackageName() + "/Files/Compressed/" + file.getName() + ".dir").toString();

        int i = 0;
        int index = directory.lastIndexOf(".");
        String path = directory.substring(0, index);
        String extension = FilenameUtils.getExtension(directory);

        while (new File(directory).exists()) {
            i++;
            directory = path + "_" + i + "." + extension;
        }

        ZipUtil.pack(file, new File(directory));
        Log.d("Mooshak", "Folder Compressed!");
        return directory;
    }

    public native int encrypt(String encryptionKey, String inputFile, String outputFile);

    public void updateBadge() {
        ((MainActivity) getActivity()).updateBadge();
    }

    @Override
    public void onResume() {
        super.onResume();
        key = sharedPreferences.getString("preSharedKey", "");
    }
}
