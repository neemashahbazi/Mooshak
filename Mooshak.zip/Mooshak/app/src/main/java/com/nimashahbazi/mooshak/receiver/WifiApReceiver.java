package com.nimashahbazi.mooshak.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.nimashahbazi.mooshak.conf.Constants;
import com.nimashahbazi.mooshak.net.WifiAdmin;
import com.nimashahbazi.mooshak.utils.LogUtils;

public class WifiApReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        WifiAdmin mWifiAdmin = new WifiAdmin(context);

        String action = intent.getAction();
        if ("android.net.wifi.WIFI_AP_STATE_CHANGED".equals(action)) {
            if (mWifiAdmin.isWifiApOpen()) {
                LogUtils.s("Hotspot On");
                Intent mintent = new Intent();
                mintent.setAction(Constants.STATUS_AP_ON);
                context.sendBroadcast(mintent);

            } else {
                LogUtils.s("Hotspot Off");
                Intent mintent = new Intent();
                mintent.setAction(Constants.STATUS_DISCONNECT);
                context.sendBroadcast(mintent);
            }
        } else if ("android.net.wifi.WIFI_STATE_CHANGED".equals(action)) {
            if (mWifiAdmin.isWifiOpen()) {
                LogUtils.s("Wifi On");

            } else {
                LogUtils.s("Wifi Off");
                Intent mintent = new Intent();
                mintent.setAction(Constants.STATUS_DISCONNECT);
                context.sendBroadcast(mintent);
            }
        }

    }

}
